import re, sys
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.oxml.ns import qn

SRC = r"C:\Users\31905\Desktop\房东该死-不管大小.md"
DST = r"C:\Users\31905\Desktop\房东该死-不管大小.docx"

doc = Document()

# 设置正文默认字体（中文宋体 + 西文 Times New Roman）
style = doc.styles["Normal"]
style.font.name = "Times New Roman"
style.font.size = Pt(12)
style.element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")

def set_cjk(run, name="宋体"):
    run.font.name = "Times New Roman"
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = rpr.makeelement(qn("w:rFonts"), {})
        rpr.append(rfonts)
    rfonts.set(qn("w:eastAsia"), name)

with open(SRC, encoding="utf-8") as f:
    lines = f.read().split("\n")

in_block = False
for raw in lines:
    line = raw.rstrip()
    if not line.strip():
        continue
    if line.startswith("# "):
        # 标题
        p = doc.add_paragraph()
        p.alignment = 1  # 居中
        run = p.add_run(line[2:].strip())
        run.bold = True
        run.font.size = Pt(18)
        set_cjk(run, "微软雅黑")
        p.space_after = Pt(12)
        continue
    # 正文段落
    p = doc.add_paragraph()
    run = p.add_run(line)
    run.font.size = Pt(12)
    set_cjk(run)
    p.paragraph_format.line_spacing = 1.5
    p.paragraph_format.space_after = Pt(6)

doc.save(DST)
print("SAVED:", DST)
