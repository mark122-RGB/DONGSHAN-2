# -*- coding: utf-8 -*-
"""gate_check.py — v2.5 三维裁判（生成期约束的可回读检查）

写完、验收前跑：python scripts/gate_check.py 稿件.md

三个裁判 + 一个弱信号：
  裁判 1 · 起手式：首段 60 字命中八种真人起手式之一；命中平铺禁用词强提示
  裁判 2 · 在场的人：单声×在场双信号（言说=0 且 场景=0 → 零在场+单声）。高在场语域 FAIL；--register keyzheng（评论/分析/科普）降 HINT 并 redirect 到离场判断（v2.5 去卡兹克化：在场不作硬门）
  裁判 3 · 骨架同构：连续 3 段同类型收尾 = 骨架匀速
  弱信号 · 感官密度：每 800 字 <1 处身体感 → 提示（不 FAIL）

理论依据：references/linguistics-foundation.md（Halliday 人际元功能 /
Benveniste 主观性 / Mukarovsky 前景化 / Labov 评议）。
标定纪律：verify_gate.py 在 48 真人 + 15 AI 上验证区分度（register=all 路径），
误伤 ≤4/48 才作 FAIL，否则降为提示级。keyzheng 路径按 SELFDOUBT/SEMVAR 先例作
agent 级（语料无低在场子集，非新标定阈值）。
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

VERSION = "2.5.1"

# ---------- 惰性 import（避免循环依赖，无 jieba 也可跑） ----------
_cp = None
_dp = None


def _check_prose():
    global _cp
    if _cp is None:
        import check_prose as cp
        _cp = cp
    return _cp


def _discourse():
    global _dp
    if _dp is None:
        import discourse_profile as dp
        _dp = dp
    return _dp


# ---------- 裁判 1 · 起手式 ----------

OPENERS = {
    "抠字眼": ("最想抠", "这个字", "微妙的", "用词", "这两个字"),
    "捋原话": ("捋", "原话", "复述", "先看他说", "他说的是"),
    "戳私心": ("私心", "真正目的", "嘴上说", "图什么", "打的算盘"),
    "设问": None,  # 特判：前 20 字含 ?
    "影射联想": ("想到", "像极了", "脑子里蹦出", "让我想起", "让我想起", "联想到"),
    "身份": None,  # 特判：第一人称 + 时间经历
    "概念框架": ("本质", "同一种", "核心是", "说到底", "说白了"),
    "反问连击": None,  # 特判：前两句都以 ? 结尾
}
FLAT_OPENERS = ("近日", "在当今", "随着", "这话最近", "近年来", "在当下", "随着时代")

FIRST_PERSON = ("我", "我们")
TIME_MARKS = ("年", "岁", "个月", "年的时候", "那一年", "当年")


def _check_opener(first_para: str) -> dict:
    head = first_para.strip()[:60]
    hits = []
    for name, terms in OPENERS.items():
        if terms is None:
            continue
        if any(t in head for t in terms):
            hits.append(name)
    # 设问特判
    if "？" in head[:20] or "?" in head[:20]:
        hits.append("设问")
    # 身份特判：第一人称 + 时间/经历标记
    if any(p in head for p in FIRST_PERSON) and any(t in head for t in TIME_MARKS):
        hits.append("身份")
    # 反问连击特判：首句与次句都以 ? 收尾
    sents = re.split(r"[。！？；\n]", head)
    q_sents = [s for s in sents if s.strip().endswith(("？", "?"))]
    if len(q_sents) >= 2 and len(sents) >= 2:
        hits.append("反问连击")
    flat = [w for w in FLAT_OPENERS if w in head]
    # 标定（48 真人 + 15 AI）：平铺词首段命中 真人 0/48 vs AI 14/15（绝对空白）→ 作硬门 FAIL
    return {
        "pass": len(hits) > 0,
        "openers": list(dict.fromkeys(hits)),
        "flat_fail": len(flat) > 0,
        "flat": flat,
        "head": head,
    }


# ---------- 裁判 2 · 在场的人（单声×在场双信号） ----------

SAY_VERBS = (
    "说", "认为", "指出", "强调", "承认", "表示", "宣称", "声称", "写道",
    "坦言", "强调说", "解释", "回应", "反驳", "抱怨", "感慨", "提醒",
)
SCENE_WORDS = (
    "办公室", "会议室", "酒店", "窗口", "柜台", "工地", "门店", "店里", "楼下",
    "车间", "走廊", "宿舍", "出租屋", "工位", "机房", "仓库", "马路", "地铁",
    "火车", "医院", "法院", "学校", "教室", "工厂", "车间", "医院", "病房",
    "值班室", "餐厅", "饭馆", "便利店",
)
ACT_VERBS = (
    "做", "干", "建", "写", "开", "住", "签", "搬", "睡", "付", "管", "修",
    "站", "坐", "跑", "翻", "擦", "卖", "租", "买", "辞", "换", "带", "跟着",
    "扛", "推", "打", "拿", "交", "收", "算",
)


def _check_presence(prose: str, han: int, register: str = "all") -> dict:
    say = sum(prose.count(w) for w in SAY_VERBS)
    scene = sum(prose.count(w) for w in SCENE_WORDS)
    act = sum(prose.count(w) for w in ACT_VERBS)
    say_per_k = say * 1000 / max(1, han)
    scene_per_k = scene * 1000 / max(1, han)
    act_per_k = act * 1000 / max(1, han)
    # 标定（48 真人 + 15 AI，register="all" 路径）：
    #   强档（言说=0 且 场景=0）: 误伤 0/48 + 抓力 13/15
    #   中档（场景<0.5 且 动作<10）: 误伤 0/48 + 抓力 13/15
    #   两档任一触发 → 高在场语域 FAIL（纯单声零在场 / 有引用但无在场）
    fail_strong = say == 0 and scene == 0 and han >= 400
    fail_mid = scene_per_k < 0.5 and act_per_k < 10 and han >= 400
    # v2.5：低在场语域（keyzheng：评论/分析/科普/历史叙事）在场不作硬门 → 降 HINT
    low_presence = register == "keyzheng"
    return {
        "fail": fail_strong or fail_mid,
        "fail_strong": fail_strong,
        "fail_mid": fail_mid,
        "low_presence": low_presence,
        "say_per_k": round(say_per_k, 2),
        "scene_per_k": round(scene_per_k, 2),
        "act_per_k": round(act_per_k, 2),
    }


# ---------- 裁判 3 · 骨架同构 ----------

JUDGMENT_TAILS = ("是", "意味着", "说明", "就在于", "才是", "没有", "不会", "恰恰")
FACT_MARKS = ("据", "202", "19", "20", "年", "万", "亿", "%", "美元", "元", "人", "家", "所")


def _tail_type(sent: str) -> str:
    sent = sent.strip()
    if not sent:
        return None
    if sent.endswith(("？", "?")):
        return "问句"
    # 动作收尾：末句以动词短语开头（"走出/推开/翻出" 类）
    act_leads = ("走出", "推开", "翻出", "搬进", "签下", "关掉", "拿起", "放下", "回到", "离开")
    if any(sent.startswith(w) for w in act_leads):
        return "动作"
    if any(sent.endswith(w) for w in JUDGMENT_TAILS) or "是" in sent[-8:]:
        return "判断"
    if any(m in sent for m in FACT_MARKS):
        return "事实"
    return "判断"  # 默认按判断处理（保守）


def _check_skeleton(paras: list[str]) -> dict:
    if len(paras) < 6:
        return {"skip": True, "reason": "段数 <6，短稿跳过"}
    types = []
    for p in paras:
        # 末句 = 最后一句完整句（按标点切）
        sents = [s for s in re.split(r"[。！？；\n]", p.strip()) if s.strip()]
        if not sents:
            types.append(None)
            continue
        types.append(_tail_type(sents[-1]))
    # 标定结论：连续 3 段同类型收尾真人触发 75%（无区分度）；连续 4 段也 79%——
    # 收尾类型多样性不是有效信号，降为 HINT（提示级）。骨架匀速靠 agent 通读 + 双评委。
    runs = []
    for i in range(len(types) - 3):
        if types[i] and types[i] == types[i + 1] == types[i + 2] == types[i + 3]:
            runs.append((i + 1, i + 4, types[i]))
    return {"skip": False, "types": types, "runs": runs[:3]}


# ---------- 弱信号 · 感官密度 ----------

BODY_WORDS = (
    "睡", "住", "手", "汗", "窗", "灯", "味", "声", "冷", "热", "低头", "抬头",
    "烟", "咖啡", "贴着", "烫", "凉", "红", "黑", "灰", "响", "静", "疼", "累",
    "饿", "堵", "挤", "晃", "抖", "攥", "捏", "摸", "闻", "听",
)


def _sensory_hint(prose: str, han: int) -> dict:
    if han < 400:
        return {"hint": False}
    n = sum(prose.count(w) for w in BODY_WORDS)
    per_800 = n / max(1, han) * 800
    return {"hint": per_800 < 1.0, "per_800": round(per_800, 2)}


# ---------- 主入口 ----------

def check(text: str, register: str = "all") -> dict:
    cp = _check_prose()
    prose = cp.mask_non_prose(text)
    han = cp.han_count(prose)
    # 过滤 Markdown 标题行（# 开头）与 <20 字段落
    paras = [p.strip() for p in re.split(r"\n\s*\n", text.strip())
             if len(p.strip()) >= 10 and not p.strip().startswith("#")]

    opener = _check_opener(paras[0] if paras else "")
    presence = _check_presence(prose, han, register)
    skeleton = _check_skeleton(paras)
    sensory = _sensory_hint(prose, han)

    results = []

    # 裁判 1：平铺禁用词 = FAIL（绝对空白）；未命中八式 = HINT
    if opener["flat_fail"]:
        results.append({
            "judge": "起手式", "status": "FAIL",
            "detail": f"首段命中平铺禁用词 {opener['flat']}（真人语料 0/48 使用）——平铺开场是 AI 特征，选一种真人起手式重写首段",
        })
    elif opener["pass"]:
        results.append({"judge": "起手式", "status": "PASS", "detail": "命中：" + "/".join(opener["openers"])})
    else:
        results.append({
            "judge": "起手式", "status": "HINT",
            "detail": f"首段未命中八种起手式（{opener['head'][:24]}…）——真人语料仅 19% 如此，参考 zhihu-keyzheng-style.md 八式之一重写首段",
        })

    # 裁判 2（register="all" 双档过线 0/48+13/15，高在场语域作硬门）
    if presence["fail"]:
        tag = "纯单声+零在场" if presence["fail_strong"] else "有引用但无在场"
        stats = f"言说 {presence['say_per_k']}/千字、场景 {presence['scene_per_k']}/千字、动作 {presence['act_per_k']}/千字"
        if presence["low_presence"]:
            # v2.5：低在场语域（keyzheng）在场不作硬门——降 HINT，redirect 到主观印记载体
            results.append({
                "judge": "在场的人", "status": "HINT",
                "detail": f"{tag}：{stats}。低在场语域（评论/分析/科普/历史叙事）在场主观性不作硬门——改查主观印记载体（A 在场/B 离场/C 纪实任一）是否落地，见 references/human-voice.md 三载体。三者皆无才回炉。",
            })
        else:
            results.append({
                "judge": "在场的人", "status": "FAIL",
                "detail": f"{tag}：{stats}——读者跟着概念走，不跟着人走；补主观印记载体（A 在场/B 离场/C 纪实任一），见 references/human-voice.md",
            })
    else:
        results.append({
            "judge": "在场的人", "status": "PASS",
            "detail": f"言说 {presence['say_per_k']}/千字、场景 {presence['scene_per_k']}/千字、动作 {presence['act_per_k']}/千字",
        })

    # 裁判 3（标定无区分度，降为 HINT）
    if skeleton.get("skip"):
        results.append({"judge": "骨架同构", "status": "SKIP", "detail": skeleton["reason"]})
    elif skeleton["runs"]:
        runs_note = "；".join(f"段{p[0]}-{p[1]}连续 {p[2]} 收尾" for p in skeleton["runs"])
        results.append({
            "judge": "骨架同构", "status": "HINT",
            "detail": f"{runs_note}——连续 4 段同类型收尾（提示级：真人亦常见，仅提醒检查骨架是否匀速，通读时确认）",
        })
    else:
        results.append({"judge": "骨架同构", "status": "PASS", "detail": "段落收尾有分化"})

    # 弱信号
    if sensory["hint"]:
        results.append({
            "judge": "感官密度", "status": "HINT",
            "detail": f"全文概念化（身体感 {sensory['per_800']}/800 字）——回材料里找 1 处看得见摸得着的细节，别编",
        })

    return {
        "version": VERSION,
        "register": register,
        "total_han": han,
        "n_paras": len(paras),
        "results": results,
    }


def main() -> int:
    import argparse
    import json

    ap = argparse.ArgumentParser(description="三维裁判（v2.5）：起手式/在场的人/骨架同构 + 感官弱信号；--register keyzheng 降在场为 HINT")
    ap.add_argument("input", help="稿件路径")
    ap.add_argument("--register", choices=["all", "formal", "fiction", "keyzheng"], default="all",
                    help="语域；keyzheng=评论/分析/科普（低在场），在场的人降为 HINT")
    ap.add_argument("--scenario", help="场景名（公众号/通用/键政/时评/小说/散文/口播），映射到 register，优先于 --register")
    ap.add_argument("--json", action="store_true", help="输出 JSON（默认）")
    args = ap.parse_args()

    register = args.register
    if args.scenario:
        dp = _discourse()
        fn = getattr(dp, "scenario_to_register", None)
        if fn:
            mapped = fn(args.scenario)
            # discourse 用 general，gate_check 统一为 all（两者都高在场）
            register = "all" if mapped == "general" else mapped

    text = Path(args.input).read_text(encoding="utf-8")
    report = check(text, register=register)
    if args.json or True:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
