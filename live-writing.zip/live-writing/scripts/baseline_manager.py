#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""baseline_manager.py — 话语层基线管理（v2.0）。

--build  ：重算 48 篇真人语料各话语特征的 register 分组分位数 → data/baselines/general.json
--diff   ：单篇稿件与基线比对，输出偏离维度

register 推断（来源粗分，非严格标注）：
  essay_*/fic_* → fiction；zhihu_* → keyzheng；其余（net163_/sohu_/qq_/cnblogs/csdn/...）→ general

用法：
  python scripts/baseline_manager.py --build
  python scripts/baseline_manager.py --diff 稿件.md --register general
"""
from __future__ import annotations

import argparse
import json
import statistics
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
import discourse_profile as dp  # noqa: E402

BASELINE_PATH = ROOT / "data" / "baselines" / "general.json"

REGISTER_PATTERNS = [
    ("fiction", ("essay_", "fic_")),
    ("keyzheng", ("zhihu_",)),
    ("general", ()),  # 兜底
]


def infer_register(name: str) -> str:
    for reg, prefixes in REGISTER_PATTERNS:
        if any(name.startswith(p) for p in prefixes):
            return reg
    return "general"


def build_scenarios(features_out: dict) -> dict:
    """从 register_dimensions 各 register 的五维 P25/P50/P90 生成场景坐标段（v2.1）。

    全部取自 features_out，不手抄（防 deep_check 数字漂移）。formal 场景无语料，留 v2.2。
    """
    scenarios = {}
    reg_dims = features_out.get("register_dimensions", {})
    for scenario, reg in dp.SCENARIO_REGISTER.items():
        dists = reg_dims.get(reg, {})
        dims = {}
        for dim in dp.SCENARIO_DIMS:
            d = dists.get(dim)
            if d and "p25" in d:
                dims[dim] = {"p25": d["p25"], "p50": d["p50"], "p90": d["p90"]}
        note = "default 通用按公众号走" if reg == "all" else f"register={reg}"
        if reg == "keyzheng":
            note += "（键政低叙事正常，agent 否决）"
        scenarios[scenario] = {"register": reg, "note": note, "dimensions": dims}
    return scenarios


def build() -> int:
    corpus = sorted((ROOT / "evals" / "corpus").glob("*.md"))
    by_reg: dict[str, list] = {"all": []}
    for f in corpus:
        text = f.read_text(encoding="utf-8")
        prose = dp.cp.mask_non_prose(text)
        han = dp.cp.han_count(prose)
        sents = dp._sentences(text)
        if han < 400:
            continue
        reg = infer_register(f.stem)
        by_reg.setdefault(reg, [])
        row = {"name": f.stem, "register": reg}
        for name, fn in dp.FEATURE_FUNCS.items():
            try:
                row[name] = fn(sents, prose, han)
            except Exception:
                row[name] = {}
        by_reg["all"].append(row)
        by_reg[reg].append(row)

    # 组装分位数
    features_out: dict = {}
    for fname in dp.FEATURE_FUNCS:
        features_out[fname] = {}
        for reg, rows in by_reg.items():
            if not rows:
                continue
            keys = set()
            for r in rows:
                if isinstance(r.get(fname), dict):
                    keys |= {k for k, v in r[fname].items()
                             if isinstance(v, (int, float)) and not isinstance(v, bool)
                             and not k.startswith("n_")}
            reg_out = {}
            for key in sorted(keys):
                vals = [r[fname][key] for r in rows if isinstance(r.get(fname), dict) and key in r[fname]]
                if len(vals) < 3:
                    continue
                v = sorted(vals)
                reg_out[key] = {
                    "p25": round(v[max(0, int(len(v) * 0.25) - 1)], 3),
                    "p50": round(v[min(len(v) - 1, int(len(v) * 0.50))], 3),
                    "p90": round(v[min(len(v) - 1, int(len(v) * 0.90))], 3),
                    "n": len(v),
                }
            features_out[fname][reg] = reg_out

    baseline = {
        "version": dp.VERSION,
        "source": "实测 48 篇真人 2026-08-12 evals/corpus/（samples=48 重算，register 按文件名来源推断）",
        "ai_reference": "15 篇 corpus_ai/ 仅对比不入库",
        "registers": {k: list(v.keys()) for k, v in features_out.get(list(features_out.keys())[0] or "", {}).items()},
        "features": features_out,
        "scenarios": build_scenarios(features_out),
    }
    # registers 修正：从 features 里提取真实分组
    regs = set()
    for fname, fdata in features_out.items():
        regs |= set(fdata.keys())
    baseline["registers"] = sorted(regs)
    BASELINE_PATH.parent.mkdir(parents=True, exist_ok=True)
    BASELINE_PATH.write_text(json.dumps(baseline, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"基线已写入 {BASELINE_PATH}")
    print(f"register 分组: {baseline['registers']}")
    n = len(by_reg["all"])
    print(f"样本: {n} 篇")
    return 0


def diff(args) -> int:
    text = Path(args.diff).read_text(encoding="utf-8")
    baseline = json.loads(BASELINE_PATH.read_text(encoding="utf-8"))
    profile = dp.build_profile(text, baseline, args.register)
    print(json.dumps({"features": profile["features"], "deviations": profile["deviations"]},
                     ensure_ascii=False, indent=2))
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="话语层基线管理")
    ap.add_argument("--build", action="store_true", help="重算基线")
    ap.add_argument("--diff", metavar="稿件路径", help="单篇比对（需先 --build 生成基线）")
    ap.add_argument("--register", default="all", choices=["all", "general", "fiction", "keyzheng"])
    args = ap.parse_args()
    if args.build:
        return build()
    if args.diff:
        return diff(args)
    ap.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())
