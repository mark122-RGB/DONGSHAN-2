#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""discourse_profile.py — 话语特征分析器（v2.0 话语特征层）。

从「规则-违规」升级为「特征-基线」：输出结构化话语特征画像（JSON），
供 Agent 第 3 步通读归因时按偏离维度定位问题段落，不再盲扫全文。

六个语言学方向（本次 5 个，RST 走 references/rst-checklist.md）：
  1. 信息结构 Theme-Rheme : thematic_progression / zero_anaphora_rate / topic_chain_length
  2. 向心理论 Centering    : centering_transitions
  4. 语域多维 Register MDA : register_dimensions（五维评分）
  5. 立场与介入 Stance     : stance_profile（五类密度 + 一句话画像）
  6. 已知度层级 Givenness  : referential_form_sequence / subject_repetition_rate

重要定位声明：
- 本脚本输出【特征画像】，不是 pass/fail 判决。deviations 只列 red 偏离供定位。
- 基于简化中文处理（句首段正则 + 单点词性开关，不完整解析），
  所有数值供定位参考，Agent 有否决权。
- 无 jieba 时自动降级（正则近似），画像仍可输出但精度下降。

用法：
  python scripts/discourse_profile.py 稿件.md [--baseline data/baselines/general.json] [--register general] [--json]
"""
from __future__ import annotations

import argparse
import json
import re
import statistics
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import check_prose as cp  # noqa: E402

VERSION = "2.1.0"

# ---------------- 共享工具 ----------------

SENT_RE = re.compile(r"[^。！？!?\n]+[。！？!?]")
HEAD_RE = re.compile(r"^([^，。！？!?、；;：\n]{2,12})")


def _sentences(text: str) -> list[str]:
    """句切分（复用 check_prose 掩码后，取 ≥4 汉字句）。"""
    prose = cp.mask_non_prose(text)
    return [s.strip() for s in SENT_RE.findall(prose) if cp.han_count(s) >= 4]


def _head(s: str) -> str:
    """句首段：句首 ≤12 字至首个逗号前，不做词性消歧。"""
    m = HEAD_RE.match(s.strip())
    return m.group(1) if m else s.strip()[:12]


def _head_core(s: str) -> str:
    """句首核心词：jieba 取句首段首个 n/r 词性词；无则去停用词取 1-4 字。"""
    head = _head(s)
    if cp.HAS_JIEBA:
        words, flags = cp._seg_cached(head)
        for w, f in zip(words, flags):
            if w and f[0] in ("n", "r") and w not in cp.STOPWORDS:
                return w
    for w in re.findall(r"[\u4e00-\u9fff]{2,4}", head):
        if w not in cp.STOPWORDS:
            return w
    return head[:2]


def _mentions(s: str) -> set[str]:
    """句中实体提及集：句首核心词 + 句内前 6 个实词。"""
    out = set()
    head = _head_core(s)
    if head:
        out.add(head)
    for w in cp._content_words(s)[:6]:
        if len(w) >= 2:
            out.add(w)
    return out


# 句首连词（AI 模板标志：首先/其次/同时…）——不再算零形，独立维度 conj_opener_rate
CONJ_LEADS = (
    "首先", "其次", "最后", "一方面", "另一方面", "再者", "另外", "此外", "同时",
    "但是", "然而", "不过", "可是", "然而", "因此", "所以", "于是", "那么", "进而",
    "其实", "实际上", "事实上", "也就是说", "换句话说", "更重要的是", "值得注意的是",
    "可以说", "总的来说", "总之", "综上所述", "由此可见", "如果", "因为", "虽然",
    "尽管", "即使", "即便", "无论", "不管", "要么", "尤其", "特别是", "尤其是",
)
# 介词/引导词开头（真零形：承前省略主语）
ZERO_LEADS = (
    "随着", "面对", "通过", "经过", "基于", "为了", "当", "在", "从", "对", "把",
    "被", "让", "给", "为", "以", "于",
)
EXPLICIT_PRON = ("我们", "你们", "他们", "她们", "它们", "自己", "我", "你", "他", "她", "它")


def _strip_conj(s: str) -> str:
    """剥一层句首连词（含其后标点），返回剩余句首段（≤12 字）。纯连词句返回空串。"""
    t = s.strip()
    for c in sorted(CONJ_LEADS, key=len, reverse=True):
        if t.startswith(c):
            rest = t[len(c):].lstrip("，,、；;：: ")
            return rest[:12] if rest else ""
    return t[:12]


def _starts_with_conj(s: str) -> bool:
    """句首是否连词开头（独立画像维度，AI 模板标志）。"""
    t = s.strip()
    return any(t.startswith(c) for c in sorted(CONJ_LEADS, key=len, reverse=True))


def _has_explicit_subject(s: str) -> bool:
    """是否有显式主语：先剥句首连词，再看剩余句首 2-8 字匹配代词/指示词/名词。

    连词开头不参与零形判定（「首先我们需要…」→ 剥连词后「我们需要」→ 显式主语）；
    介词/引导词开头 → 承前省略（零形）；动词/副词/形容词开头 → 零形。
    """
    z = _strip_conj(s)
    if not z:
        return False  # 纯连词句 → 零形
    # 指示词/代词开头 → 显式
    if z[:2] in EXPLICIT_PRON or z[:1] in ("这", "那"):
        return True
    # 引导词/介词开头 → 零形（承前省略）
    if z[:3] in ZERO_LEADS or z[:2] in ZERO_LEADS:
        return False
    # jieba 单点词性判断
    if cp.HAS_JIEBA:
        words, flags = cp._seg_cached(z)
        if words:
            f0 = flags[0][0]
            if f0 in ("n", "r"):
                return True
            if f0 in ("v", "d", "a", "p", "c", "t"):
                return False
    return True


# ---------------- 特征词表（stance / register）----------------

HEDGE_EXTRA = ("也许", "或许", "可能", "似乎", "大概", "差不多", "按理说", "应该算")
BOOSTER_TERMS = (
    "必须", "一定", "显然", "毫无疑问", "毋庸置疑", "极其", "绝对", "确实",
    "毕竟", "终究", "历来", "早已", "无疑", "关键", "本质", "恰恰", "根本",
)
SELF_MENTION = ("我", "我们", "我自己", "笔者", "我一度", "老实说", "我的")
READER_PRON = ("你", "你们", "大家", "读者", "试想", "让我们", "想想看", "朋友们", "各位")
ATTITUDE_TERMS = ("值得", "可惜", "遗憾", "欣慰", "庆幸", "好在", "无奈", "令人", "痛心", "可惜的是")

NARR_TERMS = ("了", "过", "当时", "那年", "后来", "那天", "那时", "那年", "曾经", "当年")
PRESENT_TERMS = ("现在", "如今", "当下", "目前", "此刻", "今天")
# 注意：不收录一字词（要/得），prose.count("要") 会误计「需要/重要/不要」里的「要」
MODAL_TERMS = ("应该", "应当", "必须", "需要", "不得不", "势必")
CONCESS_TERMS = ("虽然", "尽管", "即使", "哪怕", "即便", "纵然", "无论", "不管")
PARTICLE_TERMS = ("吗", "呢", "吧", "啊", "呀", "嘛", "哦", "哈")


# ---------------- 8 个特征函数 ----------------

def feature_thematic_progression(sents: list[str]) -> dict:
    """主位推进：相邻句对 CONSTANT/LINEAR/NEW 占比。"""
    const = lin = new = 0
    for i in range(len(sents) - 1):
        c1, c2 = _head_core(sents[i]), _head_core(sents[i + 1])
        if not c1 or not c2:
            continue
        if c1 == c2 or c1 in c2 or c2 in c1:
            const += 1
        elif c2 in sents[i][-max(4, len(sents[i]) // 2):]:
            lin += 1
        else:
            new += 1
    total = const + lin + new
    return {
        "constant": round(const / max(1, total), 3),
        "linear": round(lin / max(1, total), 3),
        "new": round(new / max(1, total), 3),
        "n_pairs": total,
    }


def feature_zero_anaphora(sents: list[str]) -> dict:
    """零形回指率：无显式主语句数 ÷ 非对话句数（v2.1：连词开头剔除，单记 conj_opener_rate）。

    AI 每句重写主语 → value 低；真人「他站起来。走出去。」动词开头承前省略 → value 高。
    AI 模板文「首先…其次…同时…」→ conj_opener_rate 高（独立画像维度，最可能升引擎）。
    """
    total = zero = conj = 0
    for s in sents:
        if s.startswith(("“", "「", "『", '"', "'")) or s.startswith(("他说", "她说", "我说")):
            continue  # 引语对话排除
        total += 1
        if _starts_with_conj(s):
            conj += 1  # 连词开头：单独维度，不算零形
        elif not _has_explicit_subject(s):
            zero += 1
    return {
        "value": round(zero / max(1, total), 3),
        "conj_opener_rate": round(conj / max(1, total), 3),
        "n_sents": total,
    }


def feature_topic_chain(sents: list[str]) -> dict:
    """话题链均长：相邻句 core 相同/蕴含的最大连续段平均长度。"""
    cores = [_head_core(s) for s in sents]
    chains = []
    cur = 1
    for i in range(1, len(cores)):
        c1, c2 = cores[i - 1], cores[i]
        if c1 and c2 and (c1 == c2 or c1 in c2 or c2 in c1):
            cur += 1
        else:
            chains.append(cur)
            cur = 1
    chains.append(cur)
    return {"mean": round(sum(chains) / max(1, len(chains)), 2), "n_chains": len(chains)}


def feature_centering(sents: list[str]) -> dict:
    """向心理论（简化近似）：CONTINUE/RETAIN/SMOOTH_SHIFT/ROUGH_SHIFT 占比。"""
    cfs = [_mentions(s) for s in sents]
    trans = {"CONTINUE": 0, "RETAIN": 0, "SMOOTH_SHIFT": 0, "ROUGH_SHIFT": 0}
    prev_cb = None
    for i in range(1, len(sents)):
        cur_cf, prev_cf = cfs[i], cfs[i - 1]
        shared = cur_cf & prev_cf
        head = _head_core(sents[i])
        if not shared:
            trans["ROUGH_SHIFT"] += 1
            prev_cb = None
            continue
        cur_cb = head if head in shared else sorted(shared)[0]
        if head == cur_cb:
            trans["CONTINUE"] += 1
        elif prev_cb == cur_cb:
            trans["RETAIN"] += 1
        else:
            trans["SMOOTH_SHIFT"] += 1
        prev_cb = cur_cb
    total = sum(trans.values())
    return {k: round(v / max(1, total), 3) for k, v in trans.items()}


def feature_stance(prose: str, han: int) -> dict:
    """立场与介入：五类标记密度/千字 + 一句话画像。"""
    # hedge：复用 LW-HEDGE-001 词表（从字典读）+ 补充
    hedge_terms = HEDGE_EXTRA
    d = json.loads(cp.DICT_PATH.read_text(encoding="utf-8"))
    for r in d.get("rules", []):
        if r.get("id") == "LW-HEDGE-001":
            hedge_terms = tuple(r.get("terms", [])) + HEDGE_EXTRA
            break
    counts = {
        "hedge": sum(prose.count(t) for t in hedge_terms),
        "booster": sum(prose.count(t) for t in BOOSTER_TERMS),
        "self_mention": sum(prose.count(t) for t in SELF_MENTION),
        "reader_pronoun": sum(prose.count(t) for t in READER_PRON),
        "attitude": sum(prose.count(t) for t in ATTITUDE_TERMS),
    }
    per_k = {k: round(v * 1000 / max(1, han), 2) for k, v in counts.items()}
    # 一句话画像
    tag = _stance_tag(per_k)
    per_k["tag"] = tag
    return per_k


def _stance_tag(p: dict) -> str:
    """立场画像标签（启发式，供 agent 参考）。"""
    if p["booster"] >= 4 and p["hedge"] >= 4:
        return "虚张声势：既不敢断言又强行断言（hedge×booster 双高）"
    if p["booster"] >= 4 and p["self_mention"] <= 1 and p["reader_pronoun"] >= 1:
        return "AI 学者腔：高确定性 + 零自我 + 中读者介入"
    if p["self_mention"] >= 8:
        return "自我在场强：第一人称密度高"
    if p["reader_pronoun"] >= 4:
        return "拉近距离型：读者代词多，口语对话感强"
    return "立场平衡：无明显单极特征"


def feature_register_dims(prose: str, han: int) -> dict:
    """语域多维（MDA 简化五维，per-1000 值，画像级不重复报警）。"""
    narr = (sum(prose.count(t) for t in NARR_TERMS) - sum(prose.count(t) for t in PRESENT_TERMS)) * 1000 / max(1, han)
    pron_k = sum(prose.count(t) for t in ("我", "你", "他", "她", "我们", "你们", "他们", "她们"))
    invol = (pron_k + sum(prose.count(t) for t in PARTICLE_TERMS)) * 1000 / max(1, han)
    words = cp._content_words(prose)
    shell = sum(1 for w in words if w in cp.ABSTRACT_SHELL) / max(1, len(words))
    abstra = (shell * 1000 + sum(prose.count(t) for t in ("进行", "实施", "作出", "给予"))) / max(1, han) * 100
    persu = (sum(prose.count(t) for t in MODAL_TERMS)
             + sum(prose.count(t) for t in BOOSTER_TERMS)
             + sum(prose.count(t) for t in CONCESS_TERMS)) * 1000 / max(1, han)
    entity_k = len(re.findall(r"\d+|[A-Z][A-Za-z]+|[\u4e00-\u9fff]{2,4}(?:大学|法院|公司|医院|局|部|院|中心)", prose)) * 1000 / max(1, han)
    info = entity_k - shell * 1000
    return {
        "narrativity": round(max(0, narr), 2),
        "involvedness": round(invol, 2),
        "abstractness": round(max(0, abstra), 2),
        "persuasiveness": round(persu, 2),
        "informativity": round(info, 2),
    }


def feature_referential_form(sents: list[str]) -> dict:
    """已知度层级：高频实体指称降级率（v2.1 重构：全名→短名→代词/省略四级）。

    真人「妈妈…她…（省略）」→ degrade_rate 高；AI「数字化转型…数字化转型」→ value(全名重复率) 高。
    """
    # 统计出现 ≥2 次的 2-6 字实词（阈值降到 2，短文也能出实体）
    freq: dict[str, int] = {}
    for s in sents:
        for w in cp._content_words(s):
            if 2 <= len(w) <= 6:
                freq[w] = freq.get(w, 0) + 1
    hot = {w for w, c in freq.items() if c >= 2}
    if not hot:
        return {"value": 0.0, "degrade_rate": 0.0, "n_entities": 0, "n_pairs": 0}

    def mention(s: str, w: str) -> str | None:
        """指称形态：全名/短名/代词。全词在句→full；前缀子串在句→short；句有代词→pron。"""
        if w in s:
            return "full"
        for i in range(len(w) - 1, 1, -1):
            if w[:i] in s:
                return "short"
        return "pron" if any(p in s for p in EXPLICIT_PRON) else None

    pairs = full = degraded = 0
    prev: dict[str, int] = {}  # w -> 上次出现句下标
    for i, s in enumerate(sents):
        for w in hot:
            f = mention(s, w)
            if f and w in prev:
                pairs += 1
                if f == "full":
                    full += 1
                else:
                    degraded += 1
            if f:
                prev[w] = i
    return {
        "value": round(full / max(1, pairs), 3),           # 全名重复率（AI 高）
        "degrade_rate": round(degraded / max(1, pairs), 3),  # 降级率：短名/代词/省略（真人高）
        "n_entities": len(hot),
        "n_pairs": pairs,
    }


def _is_noun_head(w: str) -> bool:
    """句首核心词是否为名词（非代词）：jieba 词性 n*；无 jieba 兜底按非代词词表判。"""
    if cp.HAS_JIEBA:
        words, flags = cp._seg_cached(w)
        if words:
            return flags[0][0] == "n"
    return w not in EXPLICIT_PRON and not w.startswith(("这", "那"))


def feature_subject_rep(sents: list[str]) -> dict:
    """主语明写率：显式主语相邻句对中「core 相同且后句仍显式写主语」占比。AI 高。

    v2.1：依赖 _has_explicit_subject 修复（先剥连词）；新增 noun_repeat_rate 维度——
    名词主语反复明写（AI「妈妈…妈妈…妈妈」），比 value 更抗真人代词（「妈妈…她…」）干扰。
    """
    pairs = rep = noun_rep = 0
    for i in range(len(sents) - 1):
        c1, c2 = _head_core(sents[i]), _head_core(sents[i + 1])
        if not c1 or not c2:
            continue
        if c1 == c2 or c1 in c2 or c2 in c1:
            pairs += 1
            if _has_explicit_subject(sents[i + 1]):
                rep += 1
                if _is_noun_head(c2):
                    noun_rep += 1
    return {
        "value": round(rep / max(1, pairs), 3),
        "noun_repeat_rate": round(noun_rep / max(1, pairs), 3),
        "n_pairs": pairs,
    }


# ---------------- 场景 ↔ register 映射（v2.1 场景坐标 baseline 化） ----------------

SCENARIO_REGISTER = {
    "公众号/通用": "all",
    "键政/时评": "keyzheng",
    "小说/散文": "fiction",
    "口播": "general",
}
SCENARIO_DIMS = ("narrativity", "involvedness", "abstractness", "persuasiveness", "informativity")


def scenario_to_register(scenario: str) -> str:
    """场景名 → register；未知场景按 all。"""
    return SCENARIO_REGISTER.get(scenario, "all")


# ---------------- 画像聚合 ----------------

FEATURE_FUNCS = {
    "thematic_progression": lambda sents, prose, han: feature_thematic_progression(sents),
    "zero_anaphora_rate": lambda sents, prose, han: feature_zero_anaphora(sents),
    "topic_chain_length": lambda sents, prose, han: feature_topic_chain(sents),
    "centering_transitions": lambda sents, prose, han: feature_centering(sents),
    "stance_profile": lambda sents, prose, han: feature_stance(prose, han),
    "register_dimensions": lambda sents, prose, han: feature_register_dims(prose, han),
    "referential_form_sequence": lambda sents, prose, han: feature_referential_form(sents),
    "subject_repetition_rate": lambda sents, prose, han: feature_subject_rep(sents),
}


def band_of(value: float, p25: float, p90: float) -> str:
    if value < p25:
        return "low"
    if value > p90:
        return "high"
    return "normal"


def build_profile(text: str, baseline: dict | None = None, register: str = "all") -> dict:
    """聚合 8 特征 + 与基线比对（band 三档）+ deviations（red 偏离）。"""
    prose = cp.mask_non_prose(text)
    han = cp.han_count(prose)
    sents = _sentences(text)
    features = {}
    for name, fn in FEATURE_FUNCS.items():
        try:
            features[name] = fn(sents, prose, han)
        except Exception as e:  # 单特征失败不拖垮整体
            features[name] = {"error": str(e)}
    profile = {
        "version": VERSION,
        "register": register,
        "total_han": han,
        "n_sents": len(sents),
        "features": features,
    }
    if baseline:
        profile["deviations"] = _deviations(features, baseline, register, text)
    else:
        profile["deviations"] = []
    return profile


def build_scenario_profile(text: str, baseline: dict | None = None, scenario: str = "公众号/通用") -> dict:
    """场景入口：场景名 → register 后走既有基线比对，profile 补 scenario 字段。"""
    register = scenario_to_register(scenario)
    profile = build_profile(text, baseline, register)
    profile["scenario"] = scenario
    return profile


# 单向特征：只报一个方向的偏离（如劝说性只报「高」——低劝说=键政克制，非 AI 信号）
ONE_WAY_HIGH = {("register_dimensions", "persuasiveness")}


def _deviations(features: dict, baseline: dict, register: str, text: str) -> list[str]:
    """只列 red 偏离（value 超出 register 基线 P25-P90），附行号示例。"""
    devs = []
    feats_bl = baseline.get("features", {})
    for fname, fval in features.items():
        if not isinstance(fval, dict):
            continue
        breg = (feats_bl.get(fname, {}).get(register)
                or feats_bl.get(fname, {}).get("all", {}))
        if not breg:
            continue
        for key, val in fval.items():
            if not isinstance(val, (int, float)) or key.startswith("n_"):
                continue  # 跳过样本量元数据
            dist = breg.get(key)
            if not dist or "p25" not in dist:
                continue
            p25, p90 = dist["p25"], dist["p90"]
            one_way_high = (fname, key) in ONE_WAY_HIGH
            if val < p25 and not one_way_high:
                band = "低"
            elif val > p90:
                band = "高"
            else:
                continue
            sample = _locate(text, fname, key)
            devs.append(f"{fname}.{key}={val} {band}于真人基线（P25 {p25} / P90 {p90}）{sample}")
    return devs[:12]  # 封顶 12 条，控制 token


def _locate(text: str, fname: str, key: str) -> str:
    """返回一个相关行号示例（简化：找含高频名词的第一句所在行）。"""
    for i, line in enumerate(text.splitlines(), 1):
        if cp.han_count(line) >= 10:
            return f"｜示例见第 {i} 行：{line.strip()[:24]}…"
    return ""


# ---------------- CLI ----------------

def main() -> int:
    ap = argparse.ArgumentParser(description="话语特征分析器（v2.1）")
    ap.add_argument("input", help="稿件路径")
    ap.add_argument("--baseline", help="基线 JSON（data/baselines/general.json）")
    ap.add_argument("--register", default="all", choices=["all", "general", "fiction", "keyzheng"])
    ap.add_argument("--scenario", choices=list(SCENARIO_REGISTER.keys()),
                    help="场景名（公众号/通用、键政/时评、小说/散文、口播），映射到 register")
    ap.add_argument("--json", action="store_true", help="输出 JSON（默认）")
    args = ap.parse_args()

    text = Path(args.input).read_text(encoding="utf-8")
    baseline = None
    if args.baseline:
        baseline = json.loads(Path(args.baseline).read_text(encoding="utf-8"))
    if args.scenario:
        profile = build_scenario_profile(text, baseline, args.scenario)
    else:
        profile = build_profile(text, baseline, args.register)
    print(json.dumps(profile, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
