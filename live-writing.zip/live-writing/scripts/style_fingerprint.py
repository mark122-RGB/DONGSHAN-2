#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""活人写作 · 文体计量指纹（live-writing）。

把「风格像不像你」从主观评分变成可计算的距离。用法：

  # 1. 用你的旧文建立文体基线（可传多篇）
  python style_fingerprint.py 旧文1.md 旧文2.md 旧文3.md --save baseline.json

  # 2. 给一篇新稿算与基线的偏离度（0~100，越低越像你）
  python style_fingerprint.py 新稿.md --baseline baseline.json

  # 3. 只看一篇的指纹，不比对
  python style_fingerprint.py 稿件.md

零依赖，仅标准库。所有计算本地完成，语料与基线不出设备。
"""
from __future__ import annotations

import argparse
import json
import math
import re
import sys
from pathlib import Path

HAN = re.compile(r"[一-鿿]")
FUNC_WORDS = [
    "的", "了", "是", "在", "和", "就", "都", "而", "及", "与", "或", "很", "也",
    "还", "但", "因为", "所以", "如果", "虽然", "通过", "对于", "关于", "被", "把",
    "让", "向", "从", "到", "着", "过", "呢", "吗", "吧", "这", "那", "其", "之", "于", "以",
]
CONJUNCTIONS = ["因为", "所以", "但是", "然而", "同时", "此外", "而且", "并且", "因此", "不仅"]
PUNCTS = ["。", "，", "、", "；", "？", "！", "“", "”", "「", "」", "……"]
EPS = 1e-9

# 人味·A 在场维度词表（v2.5：高在场语域用；低在场语域这些维度正常偏低，见 SKILL.md 第6步闸8；与 references/human-voice.md A 载体对应）
# 只统计"安全"的口语/感官/自打断词——避免与字典 hard 禁用词（说白了/说句实话等）冲突。
ORAL_RESIDUE = ["其实", "反正", "说真的", "讲真", "你想想", "得了", "行吧", "算了", "拉倒", "咋回事", "说实话"]
SENSORY_WORDS = ["声音", "脚步声", "气味", "香味", "味道", "闻到", "听到", "摸到", "尝到", "冰凉", "发烫", "昏暗", "刺眼", "沙沙", "哗啦", "咕咚", "温度", "触感", "光线", "嗓子", "嘴唇", "手指", "指尖", "手掌", "汗珠", "疼", "痒", "喘", "粗糙", "温热", "涩", "黏", "腻", "勒手", "硬挺", "磨手", "扎手", "酥麻"]
SELF_INTERRUPT = ["扯远了", "说多了", "回正题", "写到这儿", "写到这里", "说到这儿", "话又说回来", "先放着", "说不好"]


def sentences(text: str):
    return [m.group() for m in re.finditer(r"[^。！？!?\n]+[。！？!?]", text) if len(HAN.findall(m.group())) >= 2]


def epigram_stack_count(text: str, max_han: int = 16) -> int:
    """段末金句堆砌窗口数（与 check_prose 的 LW-RHYTHM-004 同逻辑，独立实现）。
    连续 3 段里 ≥2 段以『短判断句』结尾的滑动窗口计数；真人中位 0、P90≈5。"""
    paras = [p for p in re.split(r"\n\s*\n", text) if len(HAN.findall(p)) >= 8]
    if len(paras) < 8:
        return -1
    flags = []
    for p in paras:
        sents = re.findall(r"[^。！？!?\n]+[。！？!?]", p)
        if not sents:
            flags.append(0)
            continue
        s = sents[-1]
        h = len(HAN.findall(s))
        if 4 <= h <= max_han and (
            re.search(r"(?:不是|是|就是|才是|不过是|无非是|意味着|在于|都)", s)
            or "：" in s or "—" in s
            or re.search(r"[^，。！？]{2,6}，[^，。！？]{2,8}。$", s)
        ):
            flags.append(1)
        else:
            flags.append(0)
    return sum(1 for i in range(len(flags) - 2) if sum(flags[i:i + 3]) >= 2)


def fingerprint(text: str) -> dict:
    han = HAN.findall(text)
    total_han = len(han)
    if total_han == 0:
        raise ValueError("没有检测到汉字")
    sents = sentences(text)
    sent_lens = [len(HAN.findall(s)) for s in sents]
    mean_len = sum(sent_lens) / max(1, len(sent_lens))
    var = sum((v - mean_len) ** 2 for v in sent_lens) / max(1, len(sent_lens))
    cv = (var ** 0.5) / mean_len if mean_len else 0.0

    # 型例比（汉字去重 / 总字数）
    ttr = len(set(han)) / total_han

    # 虚词频率（每千字）
    func = {}
    for w in FUNC_WORDS:
        c = text.count(w)
        if c:
            func[w] = round(c * 1000 / total_han, 3)

    # 连词密度（每千字）
    conj = sum(text.count(w) for w in CONJUNCTIONS) * 1000 / total_han

    # 标点占比
    punct_total = sum(text.count(p) for p in PUNCTS) or 1
    punct = {p: round(text.count(p) / punct_total, 4) for p in PUNCTS if text.count(p)}

    # 平均段长
    paras = [p for p in re.split(r"\n\s*\n", text) if len(HAN.findall(p)) >= 4]
    para_len = sum(len(HAN.findall(p)) for p in paras) / max(1, len(paras))
    para_lens = [len(HAN.findall(p)) for p in paras]
    para_contrast = max(para_lens) / min(para_lens) if len(paras) >= 4 and min(para_lens) > 0 else -1.0

    # 人味·A 在场维度（每千字密度；高在场语域用；真人语料基线见 corpus_baseline.json）
    def per_k(words):
        return sum(text.count(w) for w in words) * 1000 / total_han

    oral_residue = per_k(ORAL_RESIDUE)
    sensory = per_k(SENSORY_WORDS)
    self_interrupt = per_k(SELF_INTERRUPT)

    # 段末金句堆砌窗口（<8 段短文返回 -1，平均时排除）
    epi = epigram_stack_count(text)

    return {
        "han": total_han,
        "sent_count": len(sents),
        "sent_len_mean": round(mean_len, 3),
        "sent_len_cv": round(cv, 4),
        "ttr": round(ttr, 4),
        "conj_per_1000": round(conj, 3),
        "para_len_mean": round(para_len, 2),
        "para_contrast": round(para_contrast, 2),
        "oral_residue": round(oral_residue, 3),
        "sensory_detail": round(sensory, 3),
        "self_interrupt": round(self_interrupt, 3),
        "epigram_stack": epi,
        "func": func,
        "punct": punct,
    }


def average_fps(fps: list[dict]) -> dict:
    keys = ["sent_len_mean", "sent_len_cv", "ttr", "conj_per_1000", "para_len_mean", "para_contrast", "oral_residue", "sensory_detail", "self_interrupt", "epigram_stack"]
    valid = [f for f in fps if f["epigram_stack"] >= 0]
    base = {k: sum(f[k] for f in (valid if k == "epigram_stack" else fps)) / len(valid if k == "epigram_stack" else fps) for k in keys}
    func_words = sorted({w for f in fps for w in f["func"]})
    base["func"] = {w: sum(f["func"].get(w, 0.0) for f in fps) / len(fps) for w in func_words}
    puncts = sorted({p for f in fps for p in f["punct"]})
    base["punct"] = {p: sum(f["punct"].get(p, 0.0) for f in fps) / len(fps) for p in puncts}
    base["han"] = sum(f["han"] for f in fps)
    base["samples"] = len(fps)
    return base


def cosine_dist(a: dict, b: dict) -> float:
    words = set(a) | set(b)
    if not words:
        return 0.0
    dot = sum(a.get(w, 0.0) * b.get(w, 0.0) for w in words)
    na = math.sqrt(sum(a.get(w, 0.0) ** 2 for w in words))
    nb = math.sqrt(sum(b.get(w, 0.0) ** 2 for w in words))
    if na < EPS or nb < EPS:
        return 0.0
    return 1.0 - dot / (na * nb)


def distance(fp: dict, base: dict) -> dict:
    """算稿件与基线的偏离度（0-100，越小越像基线）。

    阈值依据（2026-08-09 真人 40 篇实测）：真人每篇 vs 群体基线的偏离度
    中位 18.6、P75 21.6、P90 24.7、最大 31.1。因此偏离度 <25 落在真人 P90 内，
    可视为"仍在真人正常波动范围"；>31 则超过真人最大偏离，明显异常。
    """
    scalar_keys = ["sent_len_mean", "sent_len_cv", "ttr", "conj_per_1000", "para_len_mean", "para_contrast", "oral_residue", "sensory_detail", "self_interrupt", "epigram_stack"]
    rel_diffs = {k: min(2.0, abs(fp[k] - base[k]) / (abs(base[k]) + EPS)) for k in scalar_keys if fp[k] >= 0 and base[k] >= 0}
    scalar = sum(rel_diffs.values()) / max(1, len(rel_diffs))  # 0..~1
    func_d = cosine_dist(fp["func"], base["func"])
    punct_d = cosine_dist(fp["punct"], base["punct"])
    total = 0.5 * func_d + 0.25 * punct_d + 0.25 * min(1.0, scalar)
    return {
        "偏离度": round(total * 100, 1),
        "虚词距离": round(func_d * 100, 1),
        "标点距离": round(punct_d * 100, 1),
        "句法标量偏离": {k: round(v * 100, 1) for k, v in rel_diffs.items()},
    }


def read(path: str) -> str:
    return Path(path).read_text(encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser(description="活人写作 · 文体计量指纹")
    ap.add_argument("files", nargs="+", help="一篇或多篇 Markdown/文本")
    ap.add_argument("--save", help="把多篇平均成基线保存到该 JSON")
    ap.add_argument("--baseline", help="读取基线 JSON，给首篇稿件算偏离度")
    args = ap.parse_args()

    try:
        fps = [fingerprint(read(p)) for p in args.files]
    except (OSError, UnicodeError, ValueError) as e:
        print(f"读取失败。{e}", file=sys.stderr)
        return 2

    if args.save:
        base = average_fps(fps)
        Path(args.save).write_text(json.dumps(base, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"已用 {len(fps)} 篇建立文体基线 → {args.save}")
        print(f"基线句长均值 {base['sent_len_mean']} 字 / 变异系数 {base['sent_len_cv']} / 型例比 {base['ttr']}")
        return 0

    if args.baseline:
        try:
            base = json.loads(Path(args.baseline).read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as e:
            print(f"读取基线失败。{e}", file=sys.stderr)
            return 2
        d = distance(fps[0], base)
        print(f"与作者基线（{base.get('samples', '?')} 篇样本）比对：")
        print(f"  综合偏离度 {d['偏离度']} / 100（越低越像作者本人；建议 < 25 视为贴合）")
        print(f"  虚词距离 {d['虚词距离']}｜标点距离 {d['标点距离']}")
        print("  句法标量偏离（%）：")
        for k, v in d["句法标量偏离"].items():
            print(f"    {k}: {v}")
        return 0

    fp = fps[0]
    print(f"汉字 {fp['han']}｜句子 {fp['sent_count']}")
    print(f"句长均值 {fp['sent_len_mean']} 字｜变异系数 {fp['sent_len_cv']}")
    print(f"型例比 {fp['ttr']}｜连词密度 {fp['conj_per_1000']}/千字｜平均段长 {fp['para_len_mean']} 字")
    top = sorted(fp["func"].items(), key=lambda kv: -kv[1])[:8]
    print("高频虚词（每千字）：" + "、".join(f"{w}{c}" for w, c in top))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
