#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把 live-writing 输出的 md 时评转成 .docx（中文排版：宋体正文/黑体标题/首行缩进）。"""
import re
import sys
from pathlib import Path

from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn


def set_font(run, name_cn, size, bold=False):
    run.font.name = "Times New Roman"
    run.font.size = Pt(size)
    run.font.bold = bold
    r = run._element.rPr.rFonts
    r.set(qn("w:eastAsia"), name_cn)


def md_to_docx(src: Path, dst: Path):
    doc = Document()
    # 页面：A4 默认即可
    for line in src.read_text(encoding="utf-8").splitlines():
        line = line.rstrip()
        if not line.strip():
            continue
        # 标题
        if line.startswith("# "):
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            set_font(p.add_run(line[2:].strip()), "黑体", 18, bold=True)
            p.paragraph_format.space_after = Pt(18)
        elif line.startswith("## "):
            p = doc.add_paragraph()
            set_font(p.add_run(line[3:].strip()), "黑体", 14, bold=True)
            p.paragraph_format.space_before = Pt(12)
            p.paragraph_format.space_after = Pt(6)
        else:
            p = doc.add_paragraph()
            p.paragraph_format.first_line_indent = Cm(0.74)  # 两字符
            p.paragraph_format.line_spacing = 1.5
            set_font(p.add_run(line.strip()), "宋体", 12)
    doc.save(dst)
    print(f"已生成: {dst}")


if __name__ == "__main__":
    src = Path(r"C:\Users\31905\.workbuddy\skills\live-writing\outputs\韩杰医生案时评-第三版-结果归责.md")
    dst = Path(r"C:\Users\31905\Desktop\韩杰医生案时评-第三版-结果归责.docx")
    md_to_docx(src, dst)
