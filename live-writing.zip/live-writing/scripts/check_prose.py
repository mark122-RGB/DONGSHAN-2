#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""活人写作 · 确定性检查器（live-writing）。

读取 rules/move-dictionary.json，把写明的中文硬禁令与模型化形状跑出来。
只报警，不自动改文。输出按「需要修改 / 需要人工判断」分层，每条带
规则 ID、名称、Grice 准则与污染类别（Linter 式，便于逐条接受/拒绝）。

用法：
    python check_prose.py 稿件.md
    python check_prose.py -            # 从标准输入读
    python check_prose.py 稿件.md --register formal   # 启用 formal 语域规则
"""
from __future__ import annotations

import argparse
import collections
import functools
import json
import math
import re
import sys
from dataclasses import dataclass
from pathlib import Path

HERE = Path(__file__).resolve().parent
DICT_PATH = HERE.parent / "rules" / "move-dictionary.json"

# v1.10.0：jieba 分词（可选依赖）。无 jieba 时 HAS_JIEBA=False，
# 语义类引擎（话题链/段落语义重复/低信息密度）静默跳过，其余引擎照常。
# v1.10.1：jieba.analyse（TF-IDF 关键词）为可选子依赖，无则 HAS_JA=False。
try:
    import jieba
    import jieba.posseg as pseg

    jieba.setLogLevel(60)  # 关掉初始化日志
    jieba.initialize()
    HAS_JIEBA = True
    try:
        import jieba.analyse as ja

        HAS_JA = True
    except ImportError:
        ja = None
        HAS_JA = False
except ImportError:
    jieba = None
    pseg = None
    ja = None
    HAS_JIEBA = False
    HAS_JA = False

HAN_RE = re.compile(r"[一-鿿]")
QUOTE_HEADS = ("「", "『", "“", "‘", '"')

# LW-PUNCT-001 冒号豁免（2026-08-11 键政语域降噪，48 篇真人语料实测形态归类）
# 言说/转述引导：真人写「妻告诉我：」「说了一句：」「明确告诉你：」「父亲发来短信：」，
# 动词与冒号之间常隔宾语或补语，旧正则要求动词紧贴冒号，导致大量漏豁免。
# 放宽为「动词 + 0~8 个非句读字符」；提示词类（总结/承认/关键在于）刻意不入表，
# 它们由 LW-PUNCT-002（hard）专管，两条规则独立生效互不干扰。
SPEECH_LEAD_RE = re.compile(
    r"(?:说|问|答|告诉|回应|劝|提醒|心想|记得|回忆|写道|写着|写|提到|提起|表示|强调|吼|"
    r"喃喃|感叹|明白|想|讲|讲述|重复|念叨|嘱咐|坦言|直言|回复|留言|短信|微信|消息|邮件|信件|纸条|"
    r"懂得|领悟|意识到|发现|念头|预料|反应)"
    r"[^。！？；，,、\n]{0,8}$"
)
# 编号小标题：1.身份性质：／阶段 3：／第二步：——排版性标签，非行文冒号
NUM_LABEL_RE = re.compile(
    r"(?:^|[\s。；;])(?:\d+[.、]|[一二三四五六七八九十]+[、.]|阶段\s*\d+|第\s*[一二三四五六七八九十\d]+\s*[章节步条点])"
    r"\s*[^\n。！？，,]{0,8}$"
)
# 列举开头：冒号后紧跟「第一／首先／一是／1.」一类枚举引导
ENUM_HEAD_RE = re.compile(r"^\s*(?:第[一二三四五六七八九十\d]+[，,、]|首先|一是|其一|\d+[.、）)]|[（(]\d+[）)])")
# 元数据／栏目标签：来源、声明、参考资料一类排版性冒号，非行文标点
META_LABEL_RE = re.compile(
    r"(?:来源|出处|参考资料|参考文献|特别声明|免责声明|版权声明|声明|编辑|作者|原标题|"
    r"摘要|关键词|注明来源|联系地址|联系方式|收录于|专栏|转载自|图片来源|原文链接)$"
)


def han_count(text: str) -> int:
    return len(HAN_RE.findall(text))


def line_number(text: str, pos: int) -> int:
    return text.count("\n", 0, pos) + 1


def excerpt(value: str, width: int = 56) -> str:
    value = re.sub(r"\s+", " ", value).strip()
    return value if len(value) <= width else value[: width - 1] + "…"


def mask_non_prose(text: str) -> str:
    """屏蔽 frontmatter、代码、行内码、链接、网址、HTML 标签，保留字符位置。"""

    def mask(m: re.Match) -> str:
        return "".join("\n" if c == "\n" else " " for c in m.group())

    patterns = (
        re.compile(r"\A---\s*\n.*?\n---\s*(?:\n|\Z)", re.DOTALL),
        re.compile(r"```.*?```", re.DOTALL),
        re.compile(r"`[^`\n]*`"),
        re.compile(r"\]\([^\n)]*\)"),
        re.compile(r"https?://[^\s)>]+"),
        re.compile(r"<[^>\n]+>"),
    )
    out = text
    for p in patterns:
        out = p.sub(mask, out)
    return out


def non_overlapping_terms(text: str, terms):
    matches, occupied = [], []
    for term in sorted(terms, key=len, reverse=True):
        for m in re.finditer(re.escape(term), text):
            s, e = m.span()
            if any(s < oe and e > os_ for os_, oe in occupied):
                continue
            matches.append((s, term))
            occupied.append((s, e))
    return sorted(matches)


@dataclass
class Paragraph:
    position: int
    text: str
    han: int
    sentences: int


def prose_paragraphs(text: str):
    paras, cursor = [], 0
    for block in re.split(r"\n\s*\n", text):
        pos = text.find(block, cursor)
        cursor = max(pos + len(block), cursor)
        clean = re.sub(r"[>*_`]", "", block).strip()
        if not clean or clean.startswith(("#", "http", "![", "```")):
            continue
        if re.match(r"^(?:[-+*]|\d+[.、])\s", clean):
            continue
        count = han_count(clean)
        if count < 4:
            continue
        sentences = max(1, len(re.findall(r"[。！？!?]", clean)))
        paras.append(Paragraph(pos, clean, count, sentences))
    return paras


# ---- engine 规则实现（结构 / 统计）----

def eng_epigram_stacking(text, rule, params):
    """段末金句堆砌：连续段落都以「短判断句」结尾 → AI 的『每段一金句』节奏。
    真人也会写金句，但通常是零星点缀；连续 3 段里 ≥2 段末是短判断句，出现
    超过阈值次（真人 P90≈5 窗口）即提醒。warn 级弱信号，语义层兜底。"""
    paras = [p for p in re.split(r"\n\s*\n", text) if han_count(p) >= 8]
    if len(paras) < params["min_paras"]:
        return []
    flags = []
    for p in paras:
        sents = re.findall(r"[^。！？!?\n]+[。！？!?]", p)
        if not sents:
            flags.append(0)
            continue
        s = sents[-1]
        h = han_count(s)
        if 4 <= h <= params["max_han"] and (
            re.search(r"(?:不是|是|就是|才是|不过是|无非是|意味着|在于|都)", s)
            or "：" in s or "—" in s
            or re.search(r"[^，。！？]{2,6}，[^，。！？]{2,8}。$", s)
        ):
            flags.append(1)
        else:
            flags.append(0)
    wins = sum(1 for i in range(len(flags) - 2) if sum(flags[i:i + 3]) >= 2)
    thr = params["window_threshold"]
    if wins > thr:
        return [f"连续段落以短判断句结尾出现 {wins} 次（真人语料 P90≈{thr}），段末金句堆砌成节奏了，改平几段：删判断词、把结论揉回叙述。"]
    return []


def eng_ending_epigram(text, rule, params):
    """结尾金句收束：最后一非空段的段末句是短判断句。
    真人 35 篇实测只有 3% 这样收尾——AI 害怕结尾平淡，总想落在可截图的句子上。
    人味结尾不负责总结，只负责停下来。"""
    paras = [p for p in re.split(r"\n\s*\n", text) if han_count(p) >= 8]
    if not paras:
        return []
    last = paras[-1]
    sents = re.findall(r"[^。！？!?\n]+[。！？!?]", last)
    if not sents:
        return []
    s = sents[-1]
    h = han_count(s)
    if 4 <= h <= params["max_han"] and (
        re.search(r"(?:不是|是|就是|才是|不过是|无非是|意味着|在于|都)", s)
        or "：" in s or "—" in s
    ):
        return [f"结尾落在短判断句上（真人 35 篇仅 3% 这样收尾）：『{excerpt(s, 40)}』。结尾不负责总结，只负责停下来——删掉这句，或换成动作/对话/一句没说完的话。"]
    return []


def eng_para_metronome(text, rule, params):
    """段落节拍器：段落长度变异系数过低 → 段落像节拍器不像肺。
    真人 35 篇段落 CV 中位 0.54、P25 0.47；AI 把每段控制在相近字数。"""
    paras = [p for p in re.split(r"\n\s*\n", text) if han_count(p) >= 8]
    if len(paras) < params["min_paras"]:
        return []
    lens = [han_count(p) for p in paras]
    m = sum(lens) / len(lens)
    if m == 0:
        return []
    var = sum((x - m) ** 2 for x in lens) / len(lens)
    cv = (var ** 0.5) / m
    thr = params["cv_threshold"]
    if cv < thr:
        return [f"段落长度变异系数 {cv:.2f}（真人中位 0.54、P25 0.47）——段落像节拍器。至少把一段拉长到 200 字深写、一段压成一行快过，制造落差。"]
    return []


def eng_parallelism_density(text, rule, params):
    """排比堆叠：紧邻三连同构小句（句首/句尾共享 2 字）的组密度。
    真人 35 篇 P90 = 0.59 组/千字；AI 排比堆叠是修辞多动症。"""
    total = han_count(text)
    if total < params["min_han"]:
        return []
    clauses = [c.strip() for c in re.split(r"[，、；,;]", text) if han_count(c) >= 2]
    groups = 0
    i = 0
    while i <= len(clauses) - 3:
        a, b, c = clauses[i], clauses[i + 1], clauses[i + 2]
        a2, b2, c2 = a[:2], b[:2], c[:2]
        ae, be, ce = a[-2:], b[-2:], c[-2:]
        if (a2 == b2 == c2 and re.match(r"[\u4e00-\u9fff]", a2)) or (
            ae == be == ce and re.match(r"[\u4e00-\u9fff]", ae)
        ):
            groups += 1
            i += 3
        else:
            i += 1
    per_k = groups * 1000 / total
    thr = params["per_thousand"]
    if per_k > thr:
        return [f"同构三连排比组密度 {per_k:.1f}/千字（真人 P90 0.59）——排比堆叠。留一组，其余破掉：第三个元素变短/变口语/换句式。"]
    return []


def eng_sentence_length_cv(text, rule, params):
    lengths = [han_count(m.group()) for m in re.finditer(r"[^。！？!?\n]+[。！？!?]", text)
               if han_count(m.group()) >= 4]
    if len(lengths) < params["min_sentences"]:
        return []
    mean = sum(lengths) / len(lengths)
    if mean == 0:
        return []
    var = sum((v - mean) ** 2 for v in lengths) / len(lengths)
    cv = (var ** 0.5) / mean
    if cv < params["cv_threshold"]:
        return [f"全文 {len(lengths)} 句长度过于接近（变异系数 {cv:.2f}），放开几句、压短几句。"]
    return []


def eng_conjunction_density(text, rule, params):
    total = han_count(text)
    if total < params["min_han"]:
        return []
    hits = non_overlapping_terms(text, rule.get("terms", []))
    per_k = len(hits) * 1000 / total
    if per_k > params["per_thousand"]:
        top = collections.Counter(t for _, t in hits).most_common(4)
        detail = "、".join(f"{t} {c} 次" for t, c in top)
        return [f"连词密度每千字 {int(per_k)} 个（{detail}），中文靠语序相接，删掉一半试试。"]
    return []


def eng_anaphora_runs(text, rule, params):
    """句首 / 句尾同构排比检测。
    - 句首同构：从句开头两字相同（含「能不能X？能不能Y？」疑问排比，因为？也参与切分）。
    - 句尾同构：「X很重要，Y很重要，Z很重要」这类重复落在句尾的排比。
    """
    minimum = params["minimum"]
    out = []
    for sent in re.finditer(r"[^。！？!?\n]+(?:[。！？!?]|$)", text):
        clauses = [c.strip() for c in re.split(r"[，、；,;？！!?]", sent.group()) if han_count(c) >= 3]
        if len(clauses) < minimum:
            continue
        # 句首同构
        run = 1
        for prev, cur in zip(clauses, clauses[1:]):
            if prev[:2] == cur[:2] and re.match(r"[一-鿿]{2}", cur):
                run += 1
                if run >= minimum:
                    out.append(f"第 {line_number(text, sent.start())} 行三连以上句首同构：“{excerpt(sent.group(), 40)}”。留两项，第三项换说法或删。")
                    break
            else:
                run = 1
        # 句尾同构
        trun = 1
        for prev, cur in zip(clauses, clauses[1:]):
            if prev[-2:] == cur[-2:] and re.match(r"[一-鿿]{2}", prev[-2:]):
                trun += 1
                if trun >= minimum:
                    out.append(f"第 {line_number(text, sent.start())} 行三连以上句尾同构：“{excerpt(sent.group(), 40)}”。留两项，第三项换说法或删。")
                    break
            else:
                trun = 1
    return out[:4]


def eng_lyric_density(text, rule, params):
    hits = non_overlapping_terms(text, rule.get("terms", []))
    if len(hits) >= params["min_hits"]:
        samples = "、".join(dict.fromkeys(t for _, t in hits))
        return [f"模型抒情词 {len(hits)} 处（{samples}）。写具体事物保留，给抽象概念穿衣服删掉。"]
    return []


def eng_metaphor_cluster(text, rule, params):
    fields = rule.get("metaphor_fields", {})
    hits = []
    for field, words in fields.items():
        for w in words:
            for m in re.finditer(re.escape(w), text):
                hits.append((m.start(), field, w))
    hits.sort()
    distance = params["distance"]
    min_fields = params["min_fields"]
    for i, (start, _, _) in enumerate(hits):
        window = [h for h in hits[i:] if h[0] - start <= distance]
        flds = {h[1] for h in window}
        if len(flds) >= min_fields:
            samples = "、".join(dict.fromkeys(h[2] for h in window))
            return [f"{distance}字内出现 {len(flds)} 套借喻（{'、'.join(sorted(flds))}，例：{samples}）。先全部还原成本义。"]
    return []


def eng_left_branch(text, rule, params):
    pats = [re.compile(p, re.MULTILINE) for p in rule.get("patterns", [])]
    hits = [m for p in pats for m in p.finditer(text)]
    limit = max(params["min"], han_count(text) // params["divisor"])
    if len(hits) > limit:
        samples = "；".join(f"第 {line_number(text, m.start())} 行“{excerpt(m.group(), 36)}”" for m in hits[:3])
        return [f"长前置成分 {len(hits)} 处，主干来得太晚。{samples}"]
    return []


def eng_heavy_de(text, rule, params):
    dense = []
    for m in re.finditer(r"[^。！？!?\n]+(?:[。！？!?]|$)", text):
        v = m.group()
        if han_count(v) >= params["min_han"] and v.count("的") >= params["min_de"]:
            dense.append(m)
    limit = max(params["min"], han_count(text) // params["divisor"])
    if len(dense) > limit:
        samples = "；".join(f"第 {line_number(text, m.start())} 行“{excerpt(m.group(), 36)}”" for m in dense[:3])
        return [f"{len(dense)} 个长句含四个以上「的」，先交代人和动作。{samples}"]
    return []


def eng_bracket_highlights(text, rule, params):
    hits = list(re.finditer(r"[「『][^」』\n]{1,6}[」』]", text))
    limit = max(params["min"], han_count(text) // params["divisor"])
    if len(hits) > limit:
        samples = "、".join(dict.fromkeys(m.group() for m in hits[:6]))
        return [f"「」括起短语 {len(hits)} 处（{samples}），太密是在批量造金句。"]
    return []


def eng_short_streak(text, rule, params):
    paras = prose_paragraphs(text)
    out = []
    if len(paras) >= params["para_min"]:
        one = sum(p.sentences <= 1 for p in paras)
        if one / len(paras) >= params["ratio"]:
            out.append(f"{one / len(paras):.0%} 的段落只有一句话，可能形成统一短段鼓点。")
    streak = []
    for p in paras:
        if p.han <= 24 and p.sentences <= 1:
            streak.append(p)
            if len(streak) >= params["limit"]:
                out.append(f"第 {line_number(text, streak[0].position)} 行起连续 {len(streak)} 个短促单句段，检查是否在排队喊结论。")
                break
        else:
            streak = []
    return out


def eng_soft_marker_density(text, rule, params):
    hits = non_overlapping_terms(text, rule.get("terms", []))
    limit = max(params["min"], han_count(text) // params["divisor"])
    if len(hits) > limit:
        samples = "、".join(dict.fromkeys(t for _, t in hits))
        return [f"洞察路标 {len(hits)} 处，提醒线 {limit} 处。重点检查 {samples}。"]
    return []


def eng_repeated_opener(text, rule, params):
    paras = prose_paragraphs(text)
    counts = collections.Counter()
    firstpos = {}
    for p in paras:
        v = p.text.lstrip("“‘\"（(")
        for op in rule.get("terms", []):
            if v.startswith(op):
                counts[op] += 1
                firstpos.setdefault(op, p.position)
                break
    repeated = [(o, c) for o, c in counts.items() if c >= params["min_count"]]
    if repeated:
        detail = "、".join(f"{o} {c} 次" for o, c in repeated)
        fp = min(firstpos[o] for o, _ in repeated)
        return [f"段落开场重复，第 {line_number(text, fp)} 行附近起：{detail}。换进入段落的方式。"]
    return []


def eng_hedge_density(text, rule, params):
    """hedging 密度：可以说/某种程度上/在一定程度上… 不确定的语气词堆叠。"""
    total = han_count(text)
    if total < params["min_han"]:
        return []
    hits = non_overlapping_terms(text, rule.get("terms", []))
    per_k = len(hits) * 1000 / total
    if per_k > params["per_thousand"]:
        samples = "、".join(dict.fromkeys(t for _, t in hits))
        return [f"hedging 密度每千字 {per_k:.1f} 个（{samples}），不确定的语气太多，删一半试试。"]
    return []


def eng_numbered_list(text, rule, params):
    """编号列举当结构：「第一，…第二，…第三，…」/「一是…二是…三是…」。"""
    marks = [m.start() for m in re.finditer(r"(?:第一|第二|第三|第四|第五|其一|其二|其三|其四|一是|二是|三是|四是)[，、]", text)]
    if len(marks) >= params["min"]:
        first_line = line_number(text, marks[0])
        return [f"第 {first_line} 行起出现 {len(marks)} 个编号标记（第一/第二/其一/一是…），检查是否在用编号当文章结构——分类不是文章，每项之间要有推进。正式文书合法列举除外。"]
    return []


def eng_tail_density(text, rule, params):
    """句末语气词泛滥：罢了/而已…"""
    total = han_count(text)
    if total < params["min_han"]:
        return []
    hits = non_overlapping_terms(text, rule.get("terms", []))
    per_k = len(hits) * 1000 / total
    if per_k > params["per_thousand"]:
        samples = "、".join(dict.fromkeys(t for _, t in hits))
        return [f"句末语气词（{samples}）每千字 {per_k:.1f} 个，泛滥会让语气显得造作；口语体除外。"]
    return []


def eng_entity_density(text, rule, params):
    """实体密度：数字/机构/中文人名/时间/英文专名合计每千字信号数，低于提醒线说明材料门禁可能被绕过。

    2026-08-10 修复：新增中文人名识别（常见姓氏 + 2 字名），此前只数数字/机构/英文，
    键政特稿里的人名（韩杰/杜仕林）全被漏掉导致误报「实体密度偏低」。"""
    total = han_count(text)
    if total < params["min_han"]:
        return []
    nums = len(re.findall(r"[0-9]+(?:[.．][0-9]+)?", text))
    units = len(re.findall(r"(?:年|月|日|岁|万|亿|元|%)", text))
    orgs = len(re.findall(r"(?:大学|医院|公司|集团|研究院|研究所|中心|局|委|省|市|县|镇|银行|法院|学校|工厂|部队)", text))
    en = len(re.findall(r"[A-Za-z]{2,}", text))
    # 中文人名：强姓氏 + 1-2 字名。用「多义性低」的强姓氏（排除何/任/林/高/石/田/方/万/郭/严/程/史
    # 等高频多义字——"严重/任何/因此/过程/历史"都会误伤），且名首字排除常见虚词（不一的是在有了可为也还等）。
    # 2026-08-10 修复：此前不数人名导致键政/特稿误报「实体密度偏低」。
    strong_surnames = "韩杜邓曹郑冯吕袁蒋蔡潘谭廖龚邢沈钟董陶贺孔邵贾魏卢薛罗姚苏叶谢梁宋许赵吴周徐孙马朱胡黄杨陈刘张李王"
    stop_first = "不一的是在有了可为也还都这对那"
    names = len(re.findall(
        rf"(?:[{strong_surnames}])[^{stop_first}][\u4e00-\u9fff]?",
        text))
    signals = nums + units + orgs + en + names
    per_k = signals * 1000 / total
    if per_k < params["per_thousand"]:
        return [f"实体密度每千字 {per_k:.1f} 个信号（数字/时间单位/机构/中文人名/英文专名合计），低于提醒线 {params['per_thousand']}。全文少见具体的人、数字、时间地点，材料门禁可能被绕过——回到第 1 步核材料。"]
    return []


def eng_punct_density(text, rule, params, register="all"):
    """标点密度总闸：破折号/冒号密度超真人 P95 即聚合告警。

    真人语料 40 篇实测（2026-08-09）：破折号（其余）中位 0.1/千字、P90 2.6、P95 5.6；
    （散文/小说）中位 2.0/千字、P90 7.2、P95 7.5——散文/小说天然多用破折号（引语/插入/停顿），
    fiction register 下阈值放宽到 7.5；冒号中位 1.4/千字、P90 3.1~8.0，阈值保持 8.0。
    单处标点都可豁免（见 LW-PUNCT-001），但密度超限说明在拿标点表演「节奏断裂」——这是本引擎要抓的聚合信号。"""
    total = han_count(text)
    if total < params["min_han"]:
        return []
    out = []
    dash_per_k_lim = params["dash_per_k_fiction" if register == "fiction" else "dash_per_k"]
    dash = len(re.findall(r"[—–]", text))
    if dash:
        per_k = dash * 1000 / total
        if per_k > dash_per_k_lim:
            ref = "散文/小说 P95 7.5" if register == "fiction" else "真人 P95 5.6"
            out.append(f"破折号密度 {per_k:.1f}/千字，{dash} 处（{ref}）——标点过载。破折号全篇 3-6 处封顶，其余改逗号/句号/括号。")
    colon = len(re.findall(r"[：:]", text))
    if colon:
        per_k = colon * 1000 / total
        if per_k > params["colon_per_k"]:
            out.append(f"冒号密度 {per_k:.1f}/千字，{colon} 处（真人 P90 6.5、P95 8.6）——过载。保留解释/引文/言说动词冒号，提示性的一律改逗号。")
    return out


def _pivot_patterns():
    """从字典动态读取 PIVOT-001/002 的 patterns，保持单一真相源。"""
    d = json.loads(Path(DICT_PATH).read_text(encoding="utf-8"))
    pats = []
    for r in d.get("rules", []):
        if r.get("id") in ("LW-PIVOT-001", "LW-PIVOT-002"):
            pats.extend(r.get("patterns", []))
    return [re.compile(p) for p in pats]


def eng_pivot_density(text, rule, params):
    """翻案变体密度总闸：PIVOT 家族（不是X而是Y/看似X实则Y…）堆叠密度。

    真人语料 35 篇实测（2026-08-08）：PIVOT 家族中位 0、P90 0.8/千字、P95 1.2/千字。
    单处命中常是「澄清误解」的正当对比（PIVOT-002 warn 豁免），但密度超限说明
    在堆叠同一种对比句式——单看合理，整体是节奏问题。"""
    total = han_count(text)
    if total < params["min_han"]:
        return []
    pats = _pivot_patterns()
    hits = sum(len(p.findall(text)) for p in pats)
    per_k = hits * 1000 / total
    if per_k > params["per_k"]:
        return [f"翻案变体密度 {per_k:.1f}/千字，{hits} 处（真人 P90 0.8、P95 1.2）——「不是X而是Y/看似X实则Y」对比句式堆叠。多数改正面陈述，留 1-2 处最有力的澄清。"]
    return []


# ---- v1.9.0 变异度引擎（语言学/翻译学/认知科学回溯，见 references/variability-profile.md）----

# 名物化：动词虚化（进行/实施/作出 + 双音动词）——CMU PNAS 2025 实测 LLM 名物化率 1.5-2 倍于人类
NOMIN_VERBS = ("进行", "实施", "作出", "给予", "加以", "予以", "开展", "实现", "获得", "提供")


def eng_nomin_density(text, rule, params):
    total = han_count(text)
    if total < params["min_han"]:
        return []
    hits = []
    for v in NOMIN_VERBS:
        for m in re.finditer(v + r"[^\n，。！？]{1,4}(?:化|性|度|力|水平|工作|建设|改革|调整|管理|服务|支持|提升|改善|优化)", text):
            hits.append(m.group())
    if not hits:
        return []
    per_k = len(hits) * 1000 / total
    if per_k > params["per_thousand"]:
        samples = "、".join(dict.fromkeys(hits[:4]))
        return [f"名物化结构每千字 {per_k:.1f} 个（{samples}）——「进行/实施/作出+动词」把动作变成名词，真人直接写动作。拆回动词：把「进行优化」改成「优化」。"]
    return []


# 显化度：连接副词 + 解释性冒号 + 总结语 联合密度（翻译学 explicitation，Koppel & Ordan ACL 2011）
EXPLICIT_TERMS = ("此外", "然而", "与此同时", "值得注意的是", "总而言之", "综上所述", "因此", "从而",
                  "进而", "同时", "不仅", "而且", "一方面", "另一方面", "首先", "其次", "再次", "最后",
                  "换句话说", "也就是说", "这意味", "由此可见", "不难发现", "需要指出", "必须强调")


def _explain_colons(text: str) -> int:
    """解释性冒号计数：与 LW-PUNCT-001 共享真人豁免（引语/言说转述/时间/
    元数据/书名号/编号标签），只统计真正「解释/展开」的冒号，避免把真人
    的「他说：」引语误算成显化连接。"""
    n = 0
    for m in re.finditer(r"[：:]", text):
        before = text[max(0, m.start() - 12): m.start()]
        after = text[m.end(): m.end() + 30]
        if after.lstrip()[:1] in QUOTE_HEADS:
            continue
        if SPEECH_LEAD_RE.search(before):
            continue
        if META_LABEL_RE.search(before):
            continue
        if NUM_LABEL_RE.search(before):
            continue
        if re.search(r"\d{1,2}[:：]\d{1,2}", text[max(0, m.start() - 2): m.end() + 2]):
            continue
        lb = text.rfind("《", max(0, m.start() - 30), m.start())
        if lb != -1 and "》" not in text[lb: m.start()] and "》" in text[m.end(): m.end() + 30]:
            continue
        n += 1
    return n


def eng_explicit_density(text, rule, params):
    total = han_count(text)
    if total < params["min_han"]:
        return []
    hits = non_overlapping_terms(text, EXPLICIT_TERMS)
    colon_explain = _explain_colons(text)
    combined = len(hits) + colon_explain
    per_k = combined * 1000 / total
    if per_k > params["per_thousand"]:
        top = collections.Counter(t for _, t in hits).most_common(5)
        detail = "、".join(f"{t}×{c}" for t, c in top)
        return [f"显化连接每千字 {per_k:.1f} 处（连词 {len(hits)} + 解释冒号 {colon_explain}，{detail}）——逻辑关系铺得太满。真人让读者自己推，删一半连接词，冒号改逗号。"]
    return []


# 细节具体度 / 自我质疑 / 语义多样 / 比喻词多样 / 音节节奏：v1.9.0 标定未过，
# 以 agent 规则落地（LW-DETAIL-001 / LW-SELFDOUBT-001 / LW-SEMVAR-001 /
# LW-METVAR-001 / LW-RHYTHM-008，由模型执行，见 variability-profile.md 标定记录）。
# 引擎函数已删除——保留未注册函数 = dead code，且会误导后续维护者以为生效。


# 段落呼吸感：段落长度落差 + 段落内信息密度不均——真人段落像肺，AI 段落像切好的蛋糕
def eng_breath(text, rule, params):
    paras = [p for p in re.split(r"\n\s*\n", text) if han_count(p) >= 8]
    if len(paras) < params["min_paras"]:
        return []
    lens = [han_count(p) for p in paras]
    m = sum(lens) / len(lens)
    if m == 0:
        return []
    var = sum((x - m) ** 2 for x in lens) / len(lens)
    cv = (var ** 0.5) / m
    max_min = max(lens) / min(lens) if min(lens) > 0 else 0
    if cv < params["cv_threshold"] and max_min < params["max_min_ratio"]:
        return [f"段落长度变异系数 {cv:.2f}、最长/最短段比 {max_min:.1f}（真人 P25 CV≈0.47、对比度更高）——段落像切好的蛋糕。把一段拉长深写（200 字+），一段压成一行快过。"]

    return []


# ---- v1.10.0 语义引擎（需 jieba；无 jieba 时静默跳过）----

# 中文 50 虚词（过滤用）：助词/介词/连词/代词/数词/量词/语气词/方位词/副词
STOPWORDS = {
    "的", "了", "是", "在", "我", "你", "他", "她", "它", "我们", "你们", "他们", "她们",
    "这", "那", "这", "那", "有", "和", "与", "及", "或", "也", "都", "就", "而", "但",
    "是", "不", "很", "对", "从", "到", "把", "被", "让", "给", "为", "以", "于", "之",
    "其", "此", "如", "与", "并", "又", "再", "还", "才", "便", "则", "虽", "然", "如果",
    "因为", "所以", "但是", "而且", "以及", "一个", "一种", "这些", "那些", "这样", "那样",
    "什么", "怎么", "如何", "为什么", "已经", "正在", "将要", "可以", "应该", "能够", "必须",
}


@functools.lru_cache(maxsize=256)
def _seg_cached(text: str):
    """jieba 分词缓存（引擎共享，避免重复分词）。返回 (词表, 词性表)。"""
    if not HAS_JIEBA:
        return [], []
    words, flags = [], []
    for w, f in pseg.cut(text):
        words.append(w)
        flags.append(f)
    return tuple(words), tuple(flags)


def _content_words(text: str):
    """返回实词列表（过滤停用词/单字/标点/纯数字）。"""
    words, flags = _seg_cached(text)
    out = []
    for w, f in zip(words, flags):
        if len(w) < 2 or w in STOPWORDS:
            continue
        if f[0] in ("n", "v", "a", "d") and f not in ("d",):  # 名词/动词/形容词（d 副词降权）
            out.append(w)
    return out


# 话题链断裂 / 段落语义重复：2026-08-12 标定未过，不脚本化。
# - LW-CHAIN（话题链/主语漂移）：真人 48 篇 P90=33.7/千字，AI 15 篇均值 19.4——
#   分布重叠无区分（中文口语/网名混入导致 jieba 主语识别噪声大），转 agent 规则。
# - LW-SEMVAR-002（段落语义重复）：真人相邻段关键词重叠峰值 P90=1.0，AI 样本 0/15 触发——
#   词表 Jaccard 抓不到语义级绕圈（v1.9.0 相邻句版同样失败），转 agent 规则。
# 教训：词汇级特征对中文 AI 味无区分度，语义绕圈只能靠模型通读判断（见 variability-profile.md）。

# 抽象壳词：AI 高频空泛词（语义稀释信号）。2026-08-12 标定：
# 真人 48 篇 P10=0.001/P50=0.014/P90=0.041；AI 15 篇 P10=0.157/P50=0.223/P90=0.248
# ——AI 抽象词占比约为真人 6 倍，分布几乎不重叠（强区分度）。
ABSTRACT_SHELL = {
    "问题", "意义", "价值", "方式", "方面", "发展", "建设", "提升", "实现", "推动",
    "促进", "加强", "提高", "重要", "关键", "需要", "应该", "必须", "社会", "时代",
    "未来", "目标", "战略", "体系", "机制", "能力", "水平", "过程", "作用", "影响",
    "关注", "重视", "思考", "深入", "不断", "持续", "长期", "共同", "努力", "积极",
    "进一步", "全面", "系统", "有效", "切实", "科学", "合理", "充分", "基本", "根本",
    "主要", "核心", "重大", "显著", "明显", "大力", "着力", "积极", "主动", "自觉",
}


def eng_infoden(text, rule, params):
    """低信息密度（抽象壳词占比）：AI 注水稿靠抽象词撑场面，真人靠具体事实。
    借鉴 SAE-XAI（2025）「低信息密度」+ 翻译学 simplification。"""
    if not HAS_JIEBA:
        return []
    total = han_count(text)
    if total < params["min_han"]:
        return []
    words = _content_words(text)
    if len(words) < 40:
        return []
    hit = sum(1 for w in words if w in ABSTRACT_SHELL)
    ratio = hit / len(words)
    if ratio > params["shell_ratio"]:
        return [f"抽象壳词占比 {ratio:.2f}（> {params['shell_ratio']}，真人 P90 0.04）——满篇「问题/意义/发展/提升」空泛词，没有具体的人、数、事实。每段至少塞进一件前文没有的具体事实，删空泛总结句。"]
    return []


def eng_keyabs(text, rule, params):
    """关键词抽象度（v1.10.1 语义引擎）：jieba.analyse TF-IDF 提取 top 关键词，
    看关键词区里抽象壳词占比——真人关键词落在具体名词上（书店/老周/卷帘门），
    AI 注水稿连关键词区都是「问题/发展/提升」。
    与 INFODEN 互补：INFODEN 测全文抽象词占比，KEYABS 测「最核心的 15 个词」的抽象度。
    标定：真人 48 篇 max=0.133、AI 15 篇 min=0.200，阈值 0.15 → 0 误伤 + 15/15 抓力。
    边界：主题具体型 AI 稿（关键词是主题词，如法考/考生）不触发——交给 TEMPLATE 等规则。"""
    if not HAS_JA:
        return []
    total = han_count(text)
    if total < params["min_han"]:
        return []
    prose = mask_non_prose(text)
    tags = ja.extract_tags(prose, topK=params.get("top_n", 15))
    if not tags:
        return []
    hit = sum(1 for w in tags if w in ABSTRACT_SHELL)
    ratio = hit / len(tags)
    if ratio >= params["shell_ratio"]:
        return [f"关键词抽象度 {ratio:.2f}（top{len(tags)} 关键词里 {hit} 个是「问题/意义/发展/提升」类空泛词，真人 48 篇最高 0.13）——连最核心的词都是正确的空话。回到材料门禁：先想清楚这篇具体在讲哪个人、哪件事，再动笔。"]
    return []


def eng_persuasiveness(text, rule, params):
    """劝说性标记密度（v2.0 话语层引擎）：情态/强化/让步词过密——AI 在使劲说服。
    词表（字典 terms）：应该/必须/显然/虽然/即使/关键/本质 等劝说性标记。
    标定：真人 48 篇 P10=5.86/P25=8.36/P50=11.10/P90=15.59/max=33.15；
    AI 15 篇 min=17.32/P50=27.31。阈值 17 → 误伤 3/48（均为观点强烈的真人稿，
    agent 可否决）+ 抓力 15/15；交付稿（教育/韩杰/同济）实测 7.8-8.9 安全。
    与 LW-EXPLICIT-001（连接显化）分工：EXPLICIT 抓连接层，PERSU 抓情态劝说层。"""
    total = han_count(text)
    if total < params["min_han"]:
        return []
    terms = tuple(rule.get("terms", ()))
    if not terms:
        return []
    hits = non_overlapping_terms(text, terms)
    per_k = len(hits) * 1000 / total
    if per_k > params["per_thousand"]:
        return [f"劝说性标记密度 {per_k:.1f}/千字（> {params['per_thousand']}，真人 P90 4.9）——情态/强化/让步词过密（应该/必须/显然/虽然/关键…），像在使劲说服读者。删一半这类词，让论证和事实自己说话。"]
    return []


def eng_conj_opener(text, rule, params):
    """句首连词占比（v2.1 话语层引擎）：AI 模板文「首先…其次…同时…」连词开头成瘾。

    依赖 discourse_profile 的零形回指特征（v2.1 重构：连词开头从零形判定中拆出，
    单记 conj_opener_rate）。惰性 import 避免与 discourse_profile 的 check_prose 循环引用。

    标定：真人 48 篇 P90=0.14，AI 15 篇 P10=0.231。阈值 0.15 → 误伤 1/48 + 抓力 15/15。
    边界：正式文体（公文/论文）句首连词是刚需，此规则在 formal 场景由 agent 否决。
    """
    total = han_count(text)
    if total < params["min_han"]:
        return []
    try:
        import discourse_profile as dp  # 惰性：避免循环引用
    except ImportError:
        return []
    sents = dp._sentences(text)
    res = dp.feature_zero_anaphora(sents)
    n = res.get("n_sents", 0)
    if n < params["min_sents"]:
        return []
    rate = res["conj_opener_rate"]
    if rate > params["ratio_threshold"]:
        return [f"句首连词占比 {rate:.2f}（> {params['ratio_threshold']}，真人 P90 0.14）——「首先/其次/同时/此外…」连词开头太多，是 AI 模板的排比骨架。改成动词开头或直接承前省略主语，让句子自己往前走。"]
    return []


def eng_referential_repeat(text, rule, params):
    """高频实体全名重复率（v2.1 话语层引擎）：AI 反复用全称重写同一实体，
    真人会降级为短名/代词/省略。

    依赖 discourse_profile 的指称序列特征（v2.1 重构：四级指称 full/short/pron/零形）。
    惰性 import 避免与 discourse_profile 的 check_prose 循环引用。

    标定：真人 48 篇 P90=0.17，AI 15 篇 P10=0.27。阈值 0.22 → 误伤 3/48 + 抓力 15/15。
    （degrade_rate 与 value 是同一信号的两面：degrade≈1-value，只升 value，避免重复报警。）
    边界：高频实体对全文是主题词（全文都在讲它）时，agent 可否决。
    """
    total = han_count(text)
    if total < params["min_han"]:
        return []
    try:
        import discourse_profile as dp  # 惰性：避免循环引用
    except ImportError:
        return []
    sents = dp._sentences(text)
    res = dp.feature_referential_form(sents)
    pairs = res.get("n_pairs", 0)
    if pairs < params["min_pairs"]:
        return []
    value = res["value"]
    if value > params["full_repeat_threshold"]:
        return [f"高频实体全名重复率 {value:.2f}（> {params['full_repeat_threshold']}，真人 P90 0.17）——同一个词反复用全称重写（数字化转型…数字化转型），真人会降级成短名/代词/省略。第二次出现起改用「它/这/省略」。"]
    return []


def eng_freq_redline(text, rule, params):
    """频次红线（v2.3 吸收）：程式化词（总而言之/众所周知/赋能/助力…）总密度超限。

    来源：外部 v3.2 借 de-ai-polish 的思路，但在本语料上重新标定（先标定再进字典纪律）。
    标定：真人 48 篇 P50=0.00/P90=0.75，AI 15 篇 P50=8.57/P90=11.16，10 倍绝对空白。
    阈值 2.0/千字 → 误伤 0/48 + 抓力 15/15（AI min 8.6 远高于阈值）。
    与 LW-JARGON-001/002（黑话逐词查）分工：JARGON 查单个黑话词，FREQ 查「程式化词总密度」——
    AI 注水稿每个词都不算高频，但程式化词总量爆表，正是「正确的空话」堆出来的。
    """
    total = han_count(text)
    if total < params["min_han"]:
        return []
    terms = tuple(rule.get("terms", ()))
    if not terms:
        return []
    prose = mask_non_prose(text)
    hits = non_overlapping_terms(prose, terms)
    per_k = len(hits) * 1000 / total
    if per_k > params["per_thousand"]:
        top = collections.Counter(t for _, t in hits).most_common(4)
        detail = "、".join(f"{t} {c} 次" for t, c in top)
        return [f"程式化词密度每千字 {int(per_k)} 个（{detail}，真人 P90 0.75）——「总而言之/众所周知/赋能/助力」这类套话堆出来的正确空话。每段删掉一半这类词，让具体的人和事自己说话。"]
    return []


ENGINES = {
    "sentence_length_cv": eng_sentence_length_cv,
    "conjunction_density": eng_conjunction_density,
    "anaphora_runs": eng_anaphora_runs,
    "lyric_density": eng_lyric_density,
    "metaphor_cluster": eng_metaphor_cluster,
    "left_branch": eng_left_branch,
    "heavy_de": eng_heavy_de,
    "bracket_highlights": eng_bracket_highlights,
    "short_streak": eng_short_streak,
    "soft_marker_density": eng_soft_marker_density,
    "repeated_opener": eng_repeated_opener,
    "hedge_density": eng_hedge_density,
    "numbered_list": eng_numbered_list,
    "tail_density": eng_tail_density,
    "entity_density": eng_entity_density,
    "punct_density": eng_punct_density,
    "pivot_density": eng_pivot_density,
    "epigram_stacking": eng_epigram_stacking,
    "ending_epigram": eng_ending_epigram,
    "para_metronome": eng_para_metronome,
    "parallelism_density": eng_parallelism_density,
    "nomin_density": eng_nomin_density,
    "explicit_density": eng_explicit_density,
    "breath": eng_breath,
    "infoden": eng_infoden,
    "keyabs": eng_keyabs,
    "persuasiveness": eng_persuasiveness,
    "conj_opener": eng_conj_opener,
    "referential_repeat": eng_referential_repeat,
    "freq_redline": eng_freq_redline,
}

# 每个引擎必需的 params 键。字典（move-dictionary.json）是唯一真相源：
# 任何键缺失都直接报错退出，绝不静默使用代码里的 fallback 默认值（曾与字典漂移）。
REQUIRED_PARAMS = {
    "sentence_length_cv": ["cv_threshold", "min_sentences"],
    "conjunction_density": ["min_han", "per_thousand"],
    "anaphora_runs": ["minimum"],
    "lyric_density": ["min_hits"],
    "metaphor_cluster": ["distance", "min_fields"],
    "left_branch": ["min", "divisor"],
    "heavy_de": ["min_han", "min_de", "divisor", "min"],
    "bracket_highlights": ["min", "divisor"],
    "short_streak": ["limit", "para_min", "ratio"],
    "soft_marker_density": ["min", "divisor"],
    "repeated_opener": ["min_count"],
    "hedge_density": ["min_han", "per_thousand"],
    "numbered_list": ["min"],
    "tail_density": ["min_han", "per_thousand"],
    "entity_density": ["min_han", "per_thousand"],
    "punct_density": ["min_han", "dash_per_k", "colon_per_k", "dash_per_k_fiction"],
    "pivot_density": ["min_han", "per_k"],
    "epigram_stacking": ["min_paras", "max_han", "window_threshold"],
    "ending_epigram": ["max_han"],
    "para_metronome": ["min_paras", "cv_threshold"],
    "parallelism_density": ["min_han", "per_thousand"],
    "nomin_density": ["min_han", "per_thousand"],
    "explicit_density": ["min_han", "per_thousand"],
    "breath": ["min_paras", "cv_threshold", "max_min_ratio"],
    "infoden": ["min_han", "shell_ratio"],
    "keyabs": ["min_han", "shell_ratio"],
    "persuasiveness": ["min_han", "per_thousand"],
    "conj_opener": ["min_han", "min_sents", "ratio_threshold"],
    "referential_repeat": ["min_han", "min_pairs", "full_repeat_threshold"],
    "freq_redline": ["min_han", "per_thousand"],
}


def validate_engine_params(dictionary) -> list[str]:
    """校验所有 engine 规则的 params 是否含必需键。缺则返回缺失清单（非空即退出）。"""
    missing = []
    for rule in dictionary.get("rules", []):
        if rule.get("kind") != "engine":
            continue
        params = rule.get("params", {})
        for key in REQUIRED_PARAMS.get(rule.get("engine"), []):
            if key not in params:
                missing.append(f"{rule.get('id')} · {rule.get('name')}：缺引擎参数 {key}")
    return missing


def run_rule(rule, prose, full_text, register):
    """返回 (failures, warnings) 两条消息列表。"""
    sev = rule.get("severity", "warn")
    registers = rule.get("registers", ["all"])
    # 含 "all" 的规则任何语域都跑；["formal"] 只在 formal 跑。
    # 写成显式条件，避免 ["all","formal"] 被误判为 formal-only。
    if "all" not in registers and (register != "formal" or "formal" not in registers):
        return [], []

    def push(msg):
        tagged = f"[{rule['id']} · {rule['name']} | {rule['grice']}/{rule['category']}] {msg}"
        (failures if sev == "hard" else warnings).append(tagged)

    failures, warnings = [], []
    kind = rule.get("kind")
    params = rule.get("params", {})

    if kind == "literal":
        for pos, term in non_overlapping_terms(prose, rule.get("terms", [])):
            push(f"第 {line_number(full_text, pos)} 行命中「{term}」。")
    elif kind == "regex":
        for p in rule.get("patterns", []):
            for m in re.finditer(p, prose):
                push(f"第 {line_number(full_text, m.start())} 行：“{excerpt(m.group(), 44)}”。")
    elif kind == "punct":
        # 2026-08-11 键政降噪重构：旧实现把每处「已豁免」也 append 成一条 warn，
        # 键政/长文天然高频冒号（引语、法条、数据、列举），实测 48 篇真人语料刷出 239 条，
        # 真正需要人辨的信号被淹没。现分三档处理：
        #   ① 机械格式（URL/时间/Markdown 标题）→ 静默跳过，零判断价值
        #   ② 可识别的真人高频用法 → 归类计数，末尾聚合成一行
        #   ③ 其余 → 逐条 warn，这才是需要人辨语境的
        exempt: dict[str, list[int]] = {}

        def mark_exempt(cat: str, pos: int) -> None:
            exempt.setdefault(cat, []).append(line_number(full_text, pos))

        for sym in rule.get("terms", []):
            for m in re.finditer(re.escape(sym), prose):
                if sym in ("：", ":"):
                    before = prose[max(0, m.start() - 12): m.start()]
                    after = prose[m.end(): m.end() + 30]
                    # ① 机械格式，静默跳过
                    # URL/协议：https：// 、ftp: 、(id：keyandajiang)
                    if after[:2] == "//" or re.search(r"(?:https?|ftp|www|\bid)\s*$", before, re.I):
                        continue
                    # 时间格式 12：00 / 9:30
                    if re.search(r"\d{1,2}[:：]\d{1,2}", prose[max(0, m.start() - 2): m.end() + 2]):
                        continue
                    # Markdown 标题行内的冒号是排版，不是行文标点
                    line_start = prose.rfind("\n", 0, m.start()) + 1
                    if prose[line_start: line_start + 1] == "#":
                        continue
                    # 书名／作品名内部的冒号（《倩女幽魂3：道道道》）——属专名，非作者用标点
                    lb = prose.rfind("《", max(0, m.start() - 30), m.start())
                    if lb != -1 and "》" not in prose[lb: m.start()] and "》" in prose[m.end(): m.end() + 30]:
                        continue
                    # ② 可识别的真人高频用法，聚合
                    if register == "formal" and re.search(
                            r"(如下|以下|规定|判决|公告|条例|办法|细则|意见|通知|报告)$", before):
                        mark_exempt("法定文书格式", m.start())
                        continue
                    if after.lstrip()[:1] in QUOTE_HEADS:
                        mark_exempt("引出原话", m.start())
                        continue
                    if SPEECH_LEAD_RE.search(before):
                        mark_exempt("言说/转述", m.start())
                        continue
                    if META_LABEL_RE.search(before):
                        mark_exempt("元数据标签", m.start())
                        continue
                    if NUM_LABEL_RE.search(before):
                        mark_exempt("编号小标题", m.start())
                        continue
                    # 列举冒号：后接顿号／逗号并列，或「第一…」「一是…」式枚举引导
                    seg = re.split(r"[。！？\n]", after, maxsplit=1)[0]
                    if (seg.count("、") >= 2 or seg.count("，") >= 2
                            or ENUM_HEAD_RE.match(seg)
                            or len(re.findall(r"(?:一种|一是|二是|有的|其一|首先|第一)", seg)) >= 2):
                        mark_exempt("列举", m.start())
                        continue
                elif sym in ("—", "–"):
                    # 成对插入语破折号（——……——），同句内另一个破折号配对
                    seg = prose[m.end(): m.end() + 60]
                    seg = re.split(r"[\n。！？]", seg, maxsplit=1)[0]
                    if "—" in seg or "–" in seg:
                        mark_exempt("成对插入语破折号", m.start())
                        continue
                    # 年份/数字标签破折号（2011年的生活状态——收入好了一些…）
                    before = prose[max(0, m.start() - 10): m.start()]
                    if re.search(r"(?:\d{2,4}年|\d+月|\d+日|^#)", before):
                        continue
                # ③ 其余：逐条报，需要人辨语境
                push(f"第 {line_number(full_text, m.start())} 行出现禁用标点「{sym}」。")

        if exempt:
            total = sum(len(v) for v in exempt.values())
            detail = "｜".join(f"{k}×{len(v)}" for k, v in exempt.items())
            shown = sorted({ln for v in exempt.values() for ln in v})[:12]
            more = "…" if len(shown) < len({ln for v in exempt.values() for ln in v}) else ""
            warnings.append(
                f"[{rule['id']} · {rule['name']} | {rule['grice']}/{rule['category']}] "
                f"另有 {total} 处标点属真人高频用法，已自动豁免（{detail}），"
                f"见第 {'、'.join(map(str, shown))}{more} 行——"
                f"若其中混有「提示词+断言」式冒号（对照 LW-PUNCT-002）请自行改掉。")
    elif kind == "engine":
        fn = ENGINES.get(rule.get("engine"))
        if fn:
            import inspect
            sig = inspect.signature(fn)
            if len(sig.parameters) >= 4:
                for msg in fn(prose, rule, params, register):
                    push(msg)
            else:
                for msg in fn(prose, rule, params):
                    push(msg)
    # kind == "agent" 不在脚本范围，由模型通读执行
    return failures, warnings


def main() -> int:
    ap = argparse.ArgumentParser(description="活人写作 · 中文成稿检查器")
    ap.add_argument("path", help="Markdown/文本路径，用 - 从标准输入读")
    ap.add_argument("--register", default="all", choices=["all", "formal", "fiction"],
                    help="formal 时启用正式语域规则；fiction 时跳过实体密度（虚构文体本无真实实体）")
    ap.add_argument("--dict", default=str(DICT_PATH), help="字典路径")
    args = ap.parse_args()

    try:
        text = sys.stdin.read() if args.path == "-" else Path(args.path).read_text(encoding="utf-8")
    except (OSError, UnicodeError) as e:
        print(f"无法读取稿件。{e}", file=sys.stderr)
        return 2
    try:
        dictionary = json.loads(Path(args.dict).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        print(f"无法读取字典。{e}", file=sys.stderr)
        return 2

    missing = validate_engine_params(dictionary)
    if missing:
        print("字典参数缺失（字典是唯一真相源，缺参即拒绝运行，不静默用代码默认值）：", file=sys.stderr)
        for m in missing:
            print(f"  - {m}", file=sys.stderr)
        return 2

    prose = mask_non_prose(text)
    total = han_count(prose)
    if total == 0:
        print("没有检测到汉字。", file=sys.stderr)
        return 2

    failures, warnings = [], []
    for rule in dictionary.get("rules", []):
        if rule.get("kind") == "agent":
            continue
        # 虚构文体跳过实体密度（小说本无真实实体，LW-MATERIAL-002 对 fiction 系统性误报）
        if args.register == "fiction" and rule.get("id") == "LW-MATERIAL-002":
            continue
        f, w = run_rule(rule, prose, text, args.register)
        # 虚构文体把翻案腔降为提醒（"不是你打我，而是……"在对话/叙述中是正常表达，不宜 hard 阻断）
        if args.register == "fiction" and rule.get("id") in ("LW-PIVOT-001", "LW-PIVOT-002"):
            w.extend(f)
            f = []
        failures.extend(f)
        warnings.extend(w)

    print(f"汉字数 {total}｜语域 {args.register}｜规则 {len(dictionary.get('rules', []))} 条")
    print(f"需要修改 {len(failures)}｜需要人工判断 {len(warnings)}")

    if failures:
        print("\n需要修改（命中硬规则，不能交稿）")
        for i, item in enumerate(failures, 1):
            print(f"{i:>2}. {item}")
    if warnings:
        print("\n需要人工判断（结合语境，回到材料与说话位置）")
        for i, item in enumerate(warnings, 1):
            print(f"{i:>2}. {item}")
    if not failures and not warnings:
        print("\n未发现这份检查器覆盖的问题。")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
