#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""diff_check.py — 自动漏网句发现（v2.3 自进化闭环）。

对比预检稿与最终稿，找出「规则没报但用户改了」的句子 = 漏网句（false negatives）。
漏网句自动聚类，≥5 条相似模式 → 建议新规则草案。

流程：
  1. 对比 pre_check.md 和 final.md，找出被改过的句子
  2. 跑现有规则检查这些被改的句子
  3. 规则没报但用户改了 = 漏网句
  4. 漏网句按关键词聚类，≥5 条相似 → 建议新规则
  5. 结果写入 evals/false_negatives.json（自动维护）

用法：
  python scripts/diff_check.py pre_check.md final.md
  python scripts/diff_check.py pre_check.md final.md --json
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
import check_prose as cp  # noqa: E402

FALSE_NEG_PATH = ROOT / "evals" / "false_negatives.json"


def split_sentences(text: str) -> list[str]:
    """按句号/问号/感叹号/换行分句。"""
    sents = re.split(r"[。！？!?\n]+", text)
    return [s.strip() for s in sents if s.strip() and len(s.strip()) > 5]


def find_changed(pre: str, final: str) -> list[str]:
    """找被改过的句子：final 里没有、pre 里有的句子（删/改都算）。"""
    pre_sents = set(split_sentences(pre))
    final_sents = set(split_sentences(final))
    return [s for s in pre_sents if s not in final_sents]


def rule_fires(sent: str) -> bool:
    """该句子是否被现有规则报过。简化：跑 check_prose 看有没有任何命中。

    逐句跑完整引擎太重，这里用轻量判断：构造单句文本跑 check_prose，
    有 warn/hard 输出即视为"规则报过"。
    """
    d = json.loads(cp.DICT_PATH.read_text(encoding="utf-8"))
    prose = cp.mask_non_prose(sent)
    for rule in d.get("rules", []):
        try:
            fails, warns = cp.run_rule(rule, prose, sent, "all")
        except Exception:
            continue
        if fails or warns:
            return True
    return False


def cluster(sents: list[str]) -> list[dict]:
    """按关键词聚类：取每句 top 特征词（2-4 字，跳过停用词），共享词的句子归一组。"""
    groups: dict[str, list[str]] = defaultdict(list)
    for s in sents:
        words = [w for w in cp._content_words(s) if 2 <= len(w) <= 4][:5]
        key = tuple(sorted(set(words))[:3])  # top 3 词做组键
        groups[str(key)].append(s)
    out = []
    for key, items in groups.items():
        if len(items) >= 5:
            out.append({"pattern_words": key, "count": len(items), "samples": items[:5]})
    out.sort(key=lambda g: -g["count"])
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description="自动漏网句发现")
    ap.add_argument("pre", help="预检稿路径")
    ap.add_argument("final", help="最终稿路径")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    pre = Path(args.pre).read_text(encoding="utf-8")
    final = Path(args.final).read_text(encoding="utf-8")

    changed = find_changed(pre, final)
    if not changed:
        print("无被改句子，无法发现漏网句")
        return 0

    # 被改的句子里，规则没报过的 = 漏网句
    missed = [s for s in changed if not rule_fires(s)]
    if not missed:
        print(f"被改 {len(changed)} 句，全部被规则覆盖，无漏网句")
        return 0

    # 读取已有 false_negatives
    existing = []
    if FALSE_NEG_PATH.exists():
        existing = json.loads(FALSE_NEG_PATH.read_text(encoding="utf-8"))
    seen = {s["text"] for s in existing}

    new_entries = [s for s in missed if s not in seen]
    for s in new_entries:
        existing.append({
            "text": s,
            "added": datetime.now().isoformat(timespec="minutes"),
            "note": "diff_check 自动发现：规则未报但被改",
        })

    FALSE_NEG_PATH.write_text(json.dumps(existing, ensure_ascii=False, indent=2), encoding="utf-8")

    clusters = cluster(new_entries)
    result = {
        "changed": len(changed),
        "missed": len(missed),
        "new_entries": len(new_entries),
        "clusters_ge5": clusters,
        "false_negatives_path": str(FALSE_NEG_PATH),
    }
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"被改 {len(changed)} 句 | 规则没报的漏网句 {len(missed)} | 新增 {len(new_entries)}")
        for c in clusters:
            print(f"[聚类] {c['pattern_words']} × {c['count']} 条 → 建议新规则")
        for s in missed[:5]:
            print(f"  · {s[:50]}")
        print(f"已写入 {FALSE_NEG_PATH}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
