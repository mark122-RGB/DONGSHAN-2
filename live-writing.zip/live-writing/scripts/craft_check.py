#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""文章质量体检（craft.md 清单的可量化项）。

craft.md 是正面标准，本脚本把它可量化的部分变成体检报告：
- 标题：字数是否在 8-20 黄金区间
- 开头钩子：第一段是否有钩子元素（问句/数字/引语/场景）
- 详略：段落长度变异系数（真人中位 0.52，太均匀 = 详略失当）
- 并列段首：段首用"第一/首先/此外"等并列标记的占比（真人中位 0，高 = 目录式结构）
- 叙事锚点：人称密度（真人中位 27.7/千字，低 = 通篇概念缺具体的人）
- 结尾：结尾段长度（真人中位 47 字，过短 = 结尾没干活）

输出是体检报告不是告警：每项给数值 + 真人参照 + 提示，agent 结合全文判断。
用法：python scripts/craft_check.py 稿件.md
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

HAN = re.compile(r"[一-鿿]")
PARA_SPLIT = re.compile(r"\n\s*\n")

# 真人 35 篇语料实测（2026-08-08）
REF = {
    "para_cv": {"med": 0.52, "low": 0.41},          # 低于 low = 段落太均匀
    "marker_ratio": 0.02,                            # 并列段首占比 P75；>0.10 = 目录式
    "people_per_k": {"med": 27.7, "low": 21.7},      # 人称密度，低于 low = 缺人
    "last_para": {"med": 47, "low": 13},             # 结尾段长，低于 low = 结尾没干活
}


def han_count(t: str) -> int:
    return len(HAN.findall(t))


def craft_check(text: str, register: str = "all") -> list[str]:
    total = han_count(text)
    if total == 0:
        raise ValueError("没有检测到汉字")
    out = []

    # 1. 标题
    title_line = next((l.strip().lstrip("# ").strip() for l in text.splitlines()
                       if l.strip().startswith("#") and not l.strip().startswith("##")), "")
    if title_line:
        tlen = han_count(title_line)
        if tlen < 8:
            out.append(f"标题仅 {tlen} 字，偏短——具体 > 抽象，试着把核心判断写进标题（15 字左右黄金区间）。")
        elif tlen > 20:
            out.append(f"标题 {tlen} 字，偏长——15 字左右黄金区间，删掉可有可无的定语。")
        if not re.search(r"[0-9]|[。？！]|“|「|，|\"|'", title_line) and tlen >= 8:
            out.append(f"标题偏平（'{title_line}'）——没有数字/反问/引语/标点制造张力，试试反常事实或冲突式标题。")

    # 2. 开头钩子（第一段）
    paras = [p for p in PARA_SPLIT.split(text) if han_count(p) >= 4]
    if paras:
        first = paras[0]
        hook = False
        if "？" in first or "?" in first:
            hook = True
        elif re.search(r"[0-9]", first):
            hook = True
        elif "“" in first or "「" in first or '"' in first:
            hook = True
        elif han_count(first) <= 80:
            hook = True  # 极短首段 = 有意为之的切入
        if not hook:
            out.append(f"开头第一段（{han_count(first)} 字）没有明显钩子——没有问句/数字/引语/极短切入。读者第一段读完心里得冒出一个必须被回答的问题，没有就重写开头。")

    # 3. 段落详略（长度 CV）
    paras8 = [p for p in paras if han_count(p) >= 8]
    if len(paras8) >= 4:
        lens = [han_count(p) for p in paras8]
        m = sum(lens) / len(lens)
        cv = (sum((x - m) ** 2 for x in lens) / len(lens)) ** 0.5 / m if m else 0
        if cv < REF["para_cv"]["low"]:
            out.append(f"段落长度变异系数 {cv:.2f}（真人中位 {REF['para_cv']['med']:.2f}、P25 {REF['para_cv']['low']:.2f}）——段落体量太均匀，详略失当。冲突/关键转折细写，背景/过渡一句带过。")

    # 4. 并列段首（目录式结构信号）
    markers = ["第一", "第二", "第三", "首先", "其次", "此外", "另一方面", "同时", "再者", "其一", "其二"]
    if len(paras8) >= 4:
        marked = sum(1 for p in paras8 if any(p.lstrip().startswith(mk) for mk in markers))
        ratio = marked / len(paras8)
        if ratio > 0.10:
            out.append(f"{marked}/{len(paras8)} 段以并列标记开头（{ratio:.0%}，真人 P75 仅 2%）——目录式结构信号。并列是目录的变体，试单点衍生：每段回答上一段的为什么/所以。")

    # 5. 叙事锚点（人称密度）——v2.5 去在场化：低在场语域不强制具体的人
    people = len(re.findall(r"[他她我你]", text))
    per_k = people * 1000 / total
    if per_k < REF["people_per_k"]["low"]:
        if register == "keyzheng":
            out.append(f"人称密度 {per_k:.0f}/千字——低在场语域（评论/分析/科普/历史叙事）正常偏低，不强制具体的人。改查主观印记载体是否落地：B 离场（非对称判断+特异性选取）或 C 纪实（事实特异性+时序诚实），见 references/human-voice.md 三载体。三者皆无才回炉。")
        else:
            out.append(f"人称密度 {per_k:.0f}/千字（真人中位 {REF['people_per_k']['med']:.0f}、P25 {REF['people_per_k']['low']:.0f}）——通篇可能缺具体的人。走 A 在场载体时补一个具体可感的人；若本篇走 B 离场或 C 纪实载体，不强制具体的人，改查非对称判断/事实特异性是否落地。注意：密度达标≠有具体的人，泛指'他/你'也算密度，需人工确认。")

    # 6. 结尾段
    if paras:
        last = paras[-1]
        last_len = han_count(last)
        if last_len < REF["last_para"]["low"]:
            out.append(f"结尾段仅 {last_len} 字（真人中位 {REF['last_para']['med']}、P25 {REF['last_para']['low']}）——结尾可能没干活。检查：删掉结尾文章还完整吗？完整 = 结尾没干活，换成动作/画面/一句没说完的话。")

    return out


def main() -> int:
    ap = argparse.ArgumentParser(description="文章质量体检（craft.md 可量化项；v2.5 加 --register 语域化）")
    ap.add_argument("path", help="Markdown/文本路径，用 - 从标准输入读")
    ap.add_argument("--register", choices=["all", "formal", "fiction", "keyzheng"], default="all",
                    help="语域；keyzheng=评论/分析/科普（低在场），人称密度提示走低在场版")
    args = ap.parse_args()

    try:
        text = sys.stdin.read() if args.path == "-" else Path(args.path).read_text(encoding="utf-8")
    except (OSError, UnicodeError) as e:
        print(f"无法读取稿件。{e}", file=sys.stderr)
        return 2

    try:
        items = craft_check(text, register=args.register)
    except ValueError as e:
        print(e, file=sys.stderr)
        return 2

    total = han_count(text)
    print(f"汉字数 {total}｜文章质量体检（craft 可量化项）")
    print(f"需要关注 {len(items)} 项")
    if items:
        print("\n体检提示（结合全文判断，不是硬性告警）：")
        for i, item in enumerate(items, 1):
            print(f" {i}. {item}")
        print("\n说明：其余 craft 项（立意/论证/叙事深度/结尾是否总结）需人工通读判断。")
    else:
        print("\n体检通过：标题、开头钩子、段落详略、结构、叙事锚点、结尾均落在真人范围内。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
