#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""一键全检：check_prose（负向）+ craft_check（正向质量）+ 可选 fingerprint（人味）。

产品经理视角：用户不需要记 3 个脚本，一个入口出三份报告。
用法：
  python scripts/full_check.py 稿件.md
  python scripts/full_check.py 稿件.md --register fiction   # 虚构文体（跳过实体密度、PIVOT 降级）
  python scripts/full_check.py 稿件.md --fingerprint 基线.json   # 额外跑人味指纹+偏离度
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def run(cmd: list[str]) -> tuple[int, str]:
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8")
    return r.returncode, (r.stdout + r.stderr).strip()


def main() -> int:
    ap = argparse.ArgumentParser(description="活人写作 · 一键全检")
    ap.add_argument("path", help="稿件路径")
    ap.add_argument("--register", default="all", choices=["all", "formal", "fiction"])
    ap.add_argument("--fingerprint", metavar="基线.json", help="可选：额外跑 style_fingerprint 并对比基线")
    args = ap.parse_args()

    py = sys.executable
    checks = [
        ("check_prose（负向：AI 味/表演）", [py, str(HERE / "check_prose.py"), args.path, "--register", args.register]),
        ("craft_check（正向：文章质量）", [py, str(HERE / "craft_check.py"), args.path]),
    ]
    if args.fingerprint:
        checks.append(("fingerprint（人味/风格）", [py, str(HERE / "style_fingerprint.py"), args.path, "--baseline", args.fingerprint]))

    print(f"========== 一键全检：{args.path} ==========")
    overall = 0
    for label, cmd in checks:
        print(f"\n----- {label} -----")
        rc, out = run(cmd)
        print(out)
        if rc != 0:
            overall = rc
    print(f"\n========== 汇总：{'有 hard 失败或体检异常，见上' if overall else '全部通过'} ==========")
    return overall


if __name__ == "__main__":
    raise SystemExit(main())
