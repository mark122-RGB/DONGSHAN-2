#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""semantic_check.py — L3 语义层：TF-IDF 段落相似度（v2.3）。

解决历史 4 次语义检测失败（LW-SEMVAR-001/002、LW-CHAIN-001、LW-AI-INDEX 的 Jaccard 方案）：
Jaccard 只看「有没有相同的词」——「这个技术很重要」和「这项创新具有关键意义」零共享词，
Jaccard=0 但说的是一回事；TF-IDF 看词频分布模式，余弦相似度能抓到「换词重复」。

三级判定：
  - sim > 0.75          → 语义重复（engine 直接报）
  - 0.50 < sim <= 0.75  → 灰区，交 LLM 二次确认（agent）
  - sim <= 0.50         → 放行

用法：
  python scripts/semantic_check.py 稿件.md            # 文本报告
  python scripts/semantic_check.py 稿件.md --json     # JSON
  python scripts/semantic_check.py 稿件.md --verify   # 在 golden 上验证标定
"""
from __future__ import annotations

import argparse
import json
import math
import re
import sys
from collections import Counter
from pathlib import Path
from itertools import combinations

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import check_prose as cp  # noqa: E402

SIM_ENGINE = 0.75
SIM_AGENT = 0.50


def segment(text: str) -> list[str]:
    """jieba 分词；无 jieba 时退化 2-gram。复用 check_prose 的停用词表。"""
    if cp.HAS_JIEBA:
        words = [w for w in cp._content_words(text)]
        if words:
            return words
    clean = re.sub(r"[^\u4e00-\u9fff a-zA-Z0-9]", "", text)
    return [clean[i:i + 2] for i in range(len(clean) - 1)] if len(clean) > 1 else [clean]


def split_paragraphs(text: str) -> list[str]:
    """按空行分段，过滤 <20 字段（过短无比较价值）与噪声段。

    真人语料里反复出现的元数据（作者署名/时间戳/标题重复）会造成假相似，
    这里过滤：纯日期时间、作者行、与相邻段高度重复的标题段。
    """
    raw = [p.strip() for p in re.split(r"\n\s*\n", text.strip()) if len(p.strip()) >= 20]
    out = []
    for p in raw:
        # 纯时间戳/署名行（协和手足外科陈江海 2026-08-07 09:00:00）
        if re.fullmatch(r"[\u4e00-\u9fffA-Za-z0-9·\s]{0,20}\d{4}[-/年]\d{1,2}[-/月]\d{1,2}\s*\d{0,2}:?\d{0,2}", p):
            continue
        # 开头就是时间戳的元数据行
        if re.match(r"^[\u4e00-\u9fffA-Za-z0-9·\s]{0,15}\d{4}[-/年]\d{1,2}", p) and len(p) < 40:
            continue
        out.append(p)
    return out


def _norm(vec: dict[str, float]) -> float:
    return math.sqrt(sum(v * v for v in vec.values()))


def compute_tfidf(paragraphs: list[str]) -> list[dict[str, float]]:
    """每段 TF-IDF 向量。idf 用语料内段频。"""
    segs = [segment(p) for p in paragraphs]
    df: Counter[str] = Counter()
    for s in segs:
        for w in set(s):
            df[w] += 1
    n = max(1, len(segs))
    vecs = []
    for s in segs:
        tf = Counter(s)
        vec = {}
        for w, c in tf.items():
            idf = math.log((n + 1) / (df[w] + 1)) + 1.0
            vec[w] = c * idf
        vecs.append(vec)
    return vecs


def cosine(a: dict[str, float], b: dict[str, float]) -> float:
    na, nb = _norm(a), _norm(b)
    if na == 0 or nb == 0:
        return 0.0
    dot = sum(v * b.get(k, 0) for k, v in a.items())
    return dot / (na * nb)


def check(text: str) -> list[dict]:
    """主入口：只比相邻段（论证绕圈检测），返回 sim>SIM_AGENT 的相邻段对。

    设计修正（v2.3 实测教训）：全段对比较对真人长文误伤高——真人写作
    天然复用开头句（首尾呼应）、标题句、主题词。只有「相邻两段说同一件事」
    才是论证绕圈的信号（AI 换词重复 = 相邻段重复），本版只比相邻段。
    """
    paras = split_paragraphs(text)
    if len(paras) < 2:
        return []
    vecs = compute_tfidf(paras)
    hits = []
    for i in range(len(vecs) - 1):
        sim = cosine(vecs[i], vecs[i + 1])
        if sim > SIM_AGENT:
            hits.append({
                "para_a": i + 1,
                "para_b": i + 2,
                "sim": round(sim, 3),
                "band": "engine" if sim > SIM_ENGINE else "agent",
                "snippet_a": paras[i][:40],
                "snippet_b": paras[i + 1][:40],
            })
    hits.sort(key=lambda h: -h["sim"])
    return hits[:10]  # 封顶 10 条


def verify() -> int:
    """在 48 真人 + 15 AI 上验证区分度（min_han=400 门槛一致）。"""
    root = HERE.parent
    humans = sorted((root / "evals" / "corpus").glob("*.md"))
    ais = sorted((root / "evals" / "corpus_ai").glob("*.md"))

    def max_sim(files):
        vals = []
        for f in files:
            t = f.read_text(encoding="utf-8")
            if cp.han_count(cp.mask_non_prose(t)) < 400:
                continue
            hits = check(t)
            vals.append(hits[0]["sim"] if hits else 0.0)
        return vals

    hv = max_sim(humans)
    av = max_sim(ais)

    def pct(v, p):
        v = sorted(v)
        return v[min(len(v) - 1, int(len(v) * p))]

    print(f"真人 {len(hv)} 篇最大段相似度: P50={pct(hv, .5):.2f} P90={pct(hv, .9):.2f}")
    print(f"AI   {len(av)} 篇最大段相似度: P50={pct(av, .5):.2f} P90={pct(av, .9):.2f}")
    fp = sum(1 for v in hv if v > SIM_AGENT)
    tp = sum(1 for v in av if v > SIM_AGENT)
    print(f"阈值 {SIM_AGENT}: 真人误伤 {fp}/{len(hv)} | AI 抓力 {tp}/{len(av)}")
    fp2 = sum(1 for v in hv if v > SIM_ENGINE)
    print(f"阈值 {SIM_ENGINE}: 真人误伤 {fp2}/{len(hv)}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="L3 语义层：TF-IDF 段落相似度")
    ap.add_argument("input", nargs="?", help="稿件路径")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--verify", action="store_true", help="在语料上验证区分度")
    args = ap.parse_args()

    if args.verify:
        return verify()
    if not args.input:
        ap.print_help()
        return 1
    hits = check(Path(args.input).read_text(encoding="utf-8"))
    if args.json:
        print(json.dumps(hits, ensure_ascii=False, indent=2))
    else:
        if not hits:
            print("L3 语义层：无重复段落对（全部 sim<=0.50）")
            return 0
        for h in hits:
            band = "engine 重复" if h["band"] == "engine" else "agent 灰区"
            print(f"[{band}] 段{h['para_a']} ↔ 段{h['para_b']} sim={h['sim']}")
            print(f"    {h['snippet_a']}…")
            print(f"    {h['snippet_b']}…")
    return 0


if __name__ == "__main__":
    sys.exit(main())
