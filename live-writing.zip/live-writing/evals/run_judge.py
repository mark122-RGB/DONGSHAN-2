#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""双评委盲评协议执行器。

"偷"自 shuorenhua 的双模型交叉判分思路，适配 live-writing：
每个样本含 A/B 两版文本（不标活人版），由两个独立评委（不同模型实例）
盲评：自然度(1-5) / 保真度(1-5) / 可直接发(1-5)，并判断哪版更像真人写。

用法：
  1. 编辑 evals/judge_samples.json 加样本
  2. 运行本脚本生成"评委提示词"（一个样本一段）
  3. 把提示词分别交给两个不同模型实例（如 default + reasoning），收集 JSON 判分
  4. 运行 --aggregate 汇总一致性

简版（单机无外部模型 API 时）：本脚本直接打印每个样本 A/B 两版，
由主模型自己扮演两个视角分别判分，然后 --aggregate 汇总。
"""
from __future__ import annotations

import argparse
import json
import statistics
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SAMPLES = HERE / "judge_samples.json"

SCORES = ("naturalness", "fidelity", "publishable")  # 自然度 / 保真度 / 可直接发


def load_samples() -> dict:
    d = json.loads(SAMPLES.read_text(encoding="utf-8"))
    return d


def gen_prompt(sample: dict, judge_name: str = "评委") -> str:
    return f"""你是{judge_name}，一位苛刻的中文写作编辑。下面是同一内容的两版写法（A/B），
你不知道哪版是真人写的、哪版是 AI 写的。请独立评判：

样本 {sample['id']} · {sample['topic']}

【A 版】
{sample['A']}

【B 版】
{sample['B']}

请输出 JSON（不要其他文字）：
{{
  "A": {{"naturalness": 1-5, "fidelity": 1-5, "publishable": 1-5}},
  "B": {{"naturalness": 1-5, "fidelity": 1-5, "publishable": 1-5}},
  "more_human": "A 或 B",
  "reason": "一句话理由"
}}

评分标准：
- naturalness 自然度：读起来像一个具体的人在说话/写作，有语气、有节奏、有细节
- fidelity 保真度：信息、事实、观点是否都保留（只论信息量，不论文笔）
- publishable 可直接发：作为一篇能直接发布的文字，够不够格
"""


def main() -> int:
    ap = argparse.ArgumentParser(description="双评委盲评协议")
    ap.add_argument("--gen", action="store_true", help="生成评委提示词")
    ap.add_argument("--aggregate", metavar="结果.json", help="汇总多个评委的判分 JSON")
    ap.add_argument("--sample", metavar="id", help="只看某个样本（配合 --gen）")
    args = ap.parse_args()

    data = load_samples()

    if args.aggregate:
        results = json.loads(Path(args.aggregate).read_text(encoding="utf-8"))
        # results = {"评委1": {"judge-01": {...}}, "评委2": {...}}
        print(f"{'样本':<10}{'维度':<12}{'A均值':<8}{'B均值':<8}{'Δ(人味)':<8}{'评委一致':<10}")
        judges = list(results.keys())
        for s in data["samples"]:
            sid = s["id"]
            for dim in SCORES:
                av, bv = [], []
                for j in judges:
                    r = results[j].get(sid, {})
                    if "A" in r and "B" in r:
                        av.append(r["A"].get(dim, 0))
                        bv.append(r["B"].get(dim, 0))
                if not av:
                    continue
                delta = statistics.mean(bv) - statistics.mean(av)
                agree = "—"
                if dim == "naturalness":
                    choices = [results[j][sid]["more_human"] for j in judges if sid in results[j] and results[j][sid].get("more_human")]
                    agree = f"{choices.count('B')}/{len(choices)} 选B" if choices else "—"
                print(f"{sid:<10}{dim:<12}{statistics.mean(av):<8.1f}{statistics.mean(bv):<8.1f}{delta:+.1f}{agree:<10}")
        return 0

    # 默认：打印提示词
    for s in data["samples"]:
        if args.sample and s["id"] != args.sample:
            continue
        print(gen_prompt(s))
        print("=" * 60)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
