# SELFCHECK-2026-08-12 · live-writing v1.10.0 逻辑与内容自检

> 用户要求：做完全部后，进行一轮逻辑和内容自检。

## 一、逻辑自检（客观数据，全绿）

| 检查项 | 结果 | 判定 |
|---|---|---|
| run_eval 回归 | 召回 23/23、误伤 0/60、warn 26/26 | ✅ |
| health_check | 9/9（含新增 jieba 可用性检查） | ✅ |
| punct_exempt 对抗 | 19/19 | ✅ |
| verify_ai_index 复跑 | AI-AI 簇内 14.0 < 真人-AI 33.9，比 0.41，成立 | ✅ |
| LW-INFODEN-001 真人误伤 | 4/48（阈值 0.06） | ✅ 达标 |
| LW-INFODEN-001 AI 抓力 | 15/15 | ✅ |
| 交付稿三篇 | 韩杰 v5 0 hard/5 warn、同济 v9 0 hard/3 warn、教育稿 0 hard/4 warn | ✅ |
| 无 jieba 降级 | HAS_JIEBA=False 时 INFODEN 静默跳过，其余 24 引擎照常 | ✅ |
| 死代码清理 | eng_chain/eng_semvar_para/eng_ai_index/AI_CENTER 全部删除，注册同步 | ✅ |

## 二、内容自检（研究出处与引擎决策核对）

### 研究出处真实性
- IJAIED 2025（Lohmann et al.，作文评分特征 vs 嵌入）— 检索自 Fachportal/Unpaywall ✅
- 清华话题链体系（TCT 语料验证 76%）— 检索自软件学报 ✅
- StyleDecipher arXiv 2025（风格稳定性）— 检索自 arXiv 摘要 ✅
- DivEye arXiv 2509.18880（surprisal 波动）— 检索自 paper summary ✅
- SAE-XAI arXiv 2503.03601（低信息密度/话语噪声风格三特征）— 检索自两篇报道 ✅
- Potter et al. Assessing Writing 2025（学术语言衔接 8% 方差）— 检索自 ERIC/ASU ✅

### 与既有引擎无重复（逐条核对）
- INFODEN-001（抽象壳词）vs EXPLICIT-001（连接词显化）：EXPLICIT 抓连接层、INFODEN 抓内容层空泛，词表不重叠 ✅
- INFODEN vs MATERIAL-002（实体密度）：MATERIAL 抓实体不足（正信号低），INFODEN 抓壳词过多（负信号高），互补 ✅
- LW-CHAIN-001（agent）vs LW-SEMVAR-001/002（agent）：CHAIN 抓话题不延续、SEMVAR 抓话题重复不推进，定义区分已在 note 写明 ✅

### 关键实验结论（本轮新增认知）
1. 词汇级特征对中文 AI 味区分度普遍不足——三连失败（相邻句/话题链/段落重叠）
2. 抽象词占比是意外有效信号（真人 P50 1.4% vs AI 22%）
3. AI-INDEX 的 T-index 思路有效但 12 维字符特征分不开「AI 模板文 vs 散文」
4. 特征工程路线获 IJAIED 学术背书，语义能力升级路径已文档化

## 三、遗留（非阻断）
- AI-INDEX 待语义特征（嵌入）升级后重试——verify_ai_index.py 常驻
- requirements.txt 与 SKILL.md 依赖说明待发布阶段落地（jieba>=0.42.1）
