#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AI-INDEX 可行性验证：AI 文本是否自成一簇？

方法论来源：翻译学 T-index（2025）——「翻译 vs 翻译」的簇内比较比「翻译 vs 原文」
更鲁棒。迁移到 AI 味检测：不拿稿子跟真人比，而是测它「离 AI 簇多近」。

方法：
1. 提取每篇文本的多维特征向量（不依赖新引擎，用可计算的现有特征）
2. 算三组欧氏距离：真人-真人 / 真人-AI / AI-AI
3. 判定：AI-AI 簇内距离显著小于 真人-AI 距离 → AI 自成一簇 → AI-INDEX 成立

AI 文本来源：outputs/对照-AI味整稿-法考.md（纯 AI 味）+ golden set 里的
expect=fail 样本（AI 模板）拼接，避免样本量不足。

用法：python verify_ai_index.py
"""
from __future__ import annotations

import json
import math
import re
import statistics
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / "scripts"))
import check_prose as cp  # noqa: E402

HAN = cp.HAN_RE
SENTS = re.compile(r"[^。！？!?\n]+[。！？!?]")


def feats(text: str) -> dict:
    """提取 12 维特征（全部可计算、零第三方依赖）。"""
    prose = cp.mask_non_prose(text)
    han = len(HAN.findall(prose))
    if han < 200:
        return None
    sents = [s for s in SENTS.findall(prose) if len(HAN.findall(s)) >= 4]
    sents = sents[:80]
    # 1 句长均值 2 句长CV
    lens = [len(HAN.findall(s)) for s in sents]
    mean = sum(lens) / max(1, len(lens))
    cv = statistics.pstdev(lens) / mean if mean else 0
    # 3 词汇多样性 TTR
    words = re.findall(r"[\u4e00-\u9fff]{2,4}", prose)
    ttr = len(set(words)) / max(1, len(words)) if words else 0
    # 4 连接副词密度（per 千字）
    conj = sum(prose.count(w) for w in
               ["此外", "然而", "与此同时", "值得注意的是", "总而言之", "因此", "所以",
                "同时", "进而", "从而", "不仅", "而且", "一方面", "另一方面", "首先", "其次", "再次"])
    conj_k = conj * 1000 / han
    # 5 名物化近似（动词虚化：进行/实施/作出/给予/加以 + 双音动词）
    nomin = sum(prose.count(w) for w in
                ["进行", "实施", "作出", "给予", "加以", "予以", "得以", "实现", "开展"])
    nomin_k = nomin * 1000 / han
    # 6 人称代词密度（翻译学 simplification：AI 少用有生代词）
    pron = sum(prose.count(w) for w in ["我", "你", "他", "她", "我们", "他们", "她们", "自己"])
    pron_k = pron * 1000 / han
    # 7 自我质疑信号数
    doubt = sum(prose.count(w) for w in
                ["我一度以为", "后来想想", "其实不对", "说不上来", "可能是我", "让我矛盾",
                 "说不清", "我犹豫", "我不确定", "坦白说", "老实说", "回头看", "现在想来"])
    # 8 冒号密度 9 破折号密度
    colon_k = prose.count("：") * 1000 / han
    dash_k = prose.count("—") * 1000 / han
    # 10 段落长度 CV
    paras = cp.prose_paragraphs(prose)
    plens = [p.han for p in paras if p.han >= 8]
    pmean = statistics.mean(plens) if plens else 0
    pcv = statistics.pstdev(plens) / pmean if pmean else 0
    # 11 实体密度（数字/机构/人名）
    entity_k = len(re.findall(r"\d+|[A-Z][A-Za-z]+|[\u4e00-\u9fff]{2,4}(?:大学|法院|公司|医院|局|部|院|中心)", prose)) * 1000 / han
    # 12 列举结构（首先/其次/再次 或 第一/第二）
    list_k = len(re.findall(r"(?:首先|其次|再次|最后|第一|第二|第三)", prose)) * 1000 / han

    return {
        "sent_len_mean": mean, "sent_len_cv": cv, "ttr": ttr,
        "conj_k": conj_k, "nomin_k": nomin_k, "pron_k": pron_k,
        "doubt": doubt, "colon_k": colon_k, "dash_k": dash_k,
        "para_cv": pcv, "entity_k": entity_k, "list_k": list_k,
    }


def dist(a: dict, b: dict) -> float:
    return math.sqrt(sum((a[k] - b[k]) ** 2 for k in a))


def main() -> int:
    # 真人语料
    human = []
    for f in sorted((ROOT / "evals" / "corpus").glob("*.md")):
        fv = feats(f.read_text(encoding="utf-8"))
        if fv:
            human.append((f.stem, fv))
    # AI 文本：corpus_ai 负样本（v1.10.0，15 篇现场生成）优先 + golden fail + 内置模板兜底
    ai = []
    ai_dir = ROOT / "evals" / "corpus_ai"
    for f in sorted(ai_dir.glob("*.md")):
        fv = feats(f.read_text(encoding="utf-8"))
        if fv:
            ai.append((f.stem, fv))
    for p in [ROOT / "outputs" / "对照-AI味整稿-法考.md"]:
        if p.exists() and p.name not in {n for n, _ in ai}:
            fv = feats(p.read_text(encoding="utf-8"))
            if fv:
                ai.append((p.stem, fv))
    golden = json.loads((HERE / "golden_set.json").read_text(encoding="utf-8"))
    for s in golden.get("samples", []):
        if s.get("expect") == "fail":
            fv = feats(s["text"])
            if fv:
                ai.append((s["id"], fv))

    # 补充：典型 AI 味长文本（覆盖<200字 golden 样本的量不足）
    AI_SAMPLES = [
        ("ai_demo_digital", """# 为什么数字化转型势在必行

在当今这个日新月异的时代，数字化转型已经成为企业发展的必然趋势。它不仅是技术升级的简单叠加，更是一场深刻的思维革命。

值得注意的是，数据正成为新的生产要素。通过人工智能技术的赋能，企业能够实现从经验驱动到数据驱动的华丽转身。这个过程不是一蹴而就的，而是需要循序渐进。

首先，数字化转型能够显著提升运营效率。通过流程再造，打通信息孤岛，企业可以大幅降低沟通成本，实现精细化管理。其次，它能够增强客户体验。以用户为中心，提供个性化、定制化的服务，从而提升用户粘性。最后，它还能赋能业务创新，让企业在激烈的市场竞争中抢占先机，立于不败之地。

总而言之，数字化转型既是挑战，也是机遇。企业唯有拥抱变化，才能在未来竞争中赢得主动权。这是每个企业都无法回避的时代命题，值得我们深思。"""),
        ("ai_demo_education", """# 论大学生心理健康教育的重要性

随着社会竞争的日益激烈，大学生心理健康问题已经成为一个不容忽视的社会议题。近年来，多所高校发生的心理健康事件引发了全社会的广泛关注与深入思考。

首先，大学生正处于心理发展的关键期。从高中到大学的跨越，不仅是学习环境的改变，更是生活方式和人际关系的全面重构。许多学生在离开父母庇护后，第一次面临独立生活的挑战，难免会产生孤独感和迷茫感。

其次，学业压力与就业压力相互叠加。一方面，课程难度和学业要求不断提升，考试和论文的密度持续增加；另一方面，就业市场的不确定性也让许多学生感到焦虑和不安。这种双重压力如果得不到及时疏导，很容易演变成心理问题。

最后，家庭和社会支持体系亟待完善。虽然各高校都建立了心理咨询中心，但专业人员的配比仍然不足，心理健康的科普教育也往往流于形式。

综上所述，加强大学生心理健康教育刻不容缓。我们需要从制度建设、专业人才培养、社会认知提升等多个维度协同发力，为青年一代的成长保驾护航。"""),
        ("ai_demo_workplace", """# 高效沟通的艺术

在职场中，沟通能力是决定职业发展高度的核心要素之一。一个善于沟通的人，往往能够事半功倍；反之，沟通不畅则可能导致团队效率低下，甚至引发不必要的误解和冲突。

首先，倾听是有效沟通的基础。很多人习惯于表达自己的观点，却忽略了倾听他人的声音。真正的倾听不是被动地接收信息，而是主动地理解对方的需求和情绪。

其次，表达要清晰且有条理。无论是口头汇报还是书面邮件，都应该遵循"结论先行、要点分层"的原则，让接收方能够快速抓住重点。值得注意的是，过多的修饰词和冗长的铺垫往往会稀释信息的核心价值。

再次，及时反馈是沟通闭环的关键。当接收到任务或信息时，主动确认理解是否准确，并在执行过程中定期同步进展，能够有效避免信息断层。

总而言之，高效沟通不是天赋，而是一系列可习得的技能组合。只有不断练习和反思，才能在复杂多变的职场环境中游刃有余，实现个人与团队的双赢。"""),
    ]
    for name, txt in AI_SAMPLES:
        fv = feats(txt)
        if fv:
            ai.append((name, fv))

    if len(ai) < 3:
        print(f"AI 样本不足：{len(ai)} 个，需要 ≥3。请补充 AI 文本。")
        return 1

    # 三组距离（抽样计算避免 O(n²) 爆炸：真人组上限 20）
    import random
    random.seed(42)
    hh, ha, aa = [], [], []
    hsample = human[:20] if len(human) > 20 else human
    for i in range(len(hsample)):
        for j in range(i + 1, len(hsample)):
            hh.append(dist(hsample[i][1], hsample[j][1]))
    for h in hsample:
        for a in ai:
            ha.append(dist(h[1], a[1]))
    for i in range(len(ai)):
        for j in range(i + 1, len(ai)):
            aa.append(dist(ai[i][1], ai[j][1]))

    m = lambda xs: statistics.mean(xs) if xs else float("nan")  # noqa: E731
    print(f"样本：真人 {len(human)} 篇 / AI {len(ai)} 篇\n")
    print(f"特征维度：{len(human[0][1])} 个")
    print(f"  真人-真人 距离均值：{m(hh):.3f}  (n={len(hh)})")
    print(f"  真人-AI   距离均值：{m(ha):.3f}  (n={len(ha)})")
    print(f"  AI-AI     距离均值：{m(aa):.3f}  (n={len(aa)})")
    print()
    ok = m(aa) < m(ha)
    print(f"判定：AI-AI 簇内距离 {'<' if ok else '>='} 真人-AI 距离 → "
          f"{'AI 自成一簇，AI-INDEX 成立 ✓' if ok else 'AI 未自成一簇，AI-INDEX 需换特征或搁置 ✗'}")
    print(f"簇内/簇间比：{m(aa)/m(ha):.2f}（<1 说明 AI 簇比跨群更紧凑）")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
