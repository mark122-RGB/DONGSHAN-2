# -*- coding: utf-8 -*-
"""verify_gate.py — gate_check 三裁判在 48 真人 + 15 AI 上的区分度标定（v2.5：加 register=keyzheng 低在场放宽扫描）

纪律：先标定再进字典（误伤 ≤4/48 才作硬门 FAIL，否则降提示级）。
输出每裁判的误伤/抓力报告 + 阈值扫描。
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))

import gate_check as gc
import check_prose as cp


def collect(files):
    out = []
    for f in sorted(files):
        text = f.read_text(encoding="utf-8")
        prose = cp.mask_non_prose(text)
        han = cp.han_count(prose)
        if han < 400:
            continue
        out.append((f.stem, text, prose, han))
    return out


def main() -> int:
    humans = collect((ROOT / "evals" / "corpus").glob("*.md"))
    ais = collect((ROOT / "evals" / "corpus_ai").glob("*.md"))
    print(f"语料：真人 {len(humans)} 篇 / AI {len(ais)} 篇\n")

    # ---- 裁判 1 · 起手式 ----
    # 标定结论：八式匹配真人仅 19%（词表覆盖不了互联网长文）→ 不作硬门；
    # 平铺禁用词直测 真人 0/48 vs AI 14/15（绝对空白）→ 硬门 FAIL
    h_flat = 0
    a_flat = 0
    h_hit = 0
    a_hit = 0
    for _, t, _, _ in humans:
        first = t.split("\n\n")[0].strip()[:60]
        r = gc._check_opener(first)
        if r["flat_fail"]:
            h_flat += 1
        if r["pass"]:
            h_hit += 1
    for _, t, _, _ in ais:
        first = t.split("\n\n")[0].strip()[:60]
        r = gc._check_opener(first)
        if r["flat_fail"]:
            a_flat += 1
        if r["pass"]:
            a_hit += 1
    print(f"[裁判1 起手式] 八式命中: 真人 {h_hit}/{len(humans)} ({h_hit/len(humans)*100:.0f}%) | AI {a_hit}/{len(ais)}（不作硬门）")
    print(f"[裁判1 起手式] 平铺禁用词: 真人 {h_flat}/{len(humans)} | AI {a_flat}/{len(ais)} | "
          f"判定: {'✓硬门(误伤0且抓力>=10)' if h_flat <= 4 and a_flat >= 10 else '△提示级'}")

    # ---- 裁判 2 · 在场的人（多档阈值扫描）----
    print("\n[裁判2 在场的人] 阈值扫描（FAIL = 触发，register=all 路径·回归守卫）:")
    for label, fn in (
        ("强: 言说=0 且 场景=0", lambda p, h: p["say_per_k"] == 0 and p["scene_per_k"] == 0 and h >= 400),
        ("中: 场景<0.5 且 动作<10", lambda p, h: p["scene_per_k"] < 0.5 and p["act_per_k"] < 10 and h >= 400),
        ("弱: 场景=0 或 动作<4", lambda p, h: (p["scene_per_k"] == 0 or p["act_per_k"] < 4) and h >= 400),
    ):
        h_fail = sum(1 for _, t, p, h in humans if fn(gc._check_presence(p, h), h))
        a_fail = sum(1 for _, t, p, h in ais if fn(gc._check_presence(p, h), h))
        verdict = "✓过线" if h_fail <= 4 and a_fail >= 10 else ("△可作提示" if h_fail <= 8 else "✗误伤高")
        print(f"  {label}: 误伤 {h_fail}/{len(humans)} | 抓力 {a_fail}/{len(ais)} | {verdict}")

    # ---- 裁判 2 · register=keyzheng 路径（v2.5 低在场语域放宽）----
    print("\n[裁判2 在场的人 · register=keyzheng] 低在场语域放宽扫描（FAIL→HINT，不阻断）:")
    h_fire = sum(1 for _, t, p, h in humans if gc._check_presence(p, h, "keyzheng")["fail"])
    a_fire = sum(1 for _, t, p, h in ais if gc._check_presence(p, h, "keyzheng")["fail"])
    print(f"  register=keyzheng 时，强/中档触发: 真人 {h_fire}/{len(humans)} | AI {a_fire}/{len(ais)} —— 全部降为 HINT（不阻断），redirect 到主观印记载体。")
    print("  ⚠ caveat：evals/corpus 48 篇叙事/散文偏斜，无 评论/分析/科普/教程/历史叙事 标注子集；")
    print("    keyzheng 路径按 SELFDOUBT-001/SEMVAR-001 先例作 agent 级（通读+双评委判），非新标定阈值。")
    print("    待补 ≥15 篇低在场语料后可升脚本标定级（CHANGELOG TODO）。")

    # ---- 裁判 3 · 骨架同构（HINT 级）----
    print("\n[裁判3 骨架同构] 连续4段同类型收尾触发率（已降 HINT 级）:")
    h_run = 0
    a_run = 0
    for _, t, _, _ in humans:
        sk = gc._check_skeleton([p for p in t.split("\n\n") if len(p.strip()) >= 10])
        if not sk.get("skip") and sk["runs"]:
            h_run += 1
    for _, t, _, _ in ais:
        sk = gc._check_skeleton([p for p in t.split("\n\n") if len(p.strip()) >= 10])
        if not sk.get("skip") and sk["runs"]:
            a_run += 1
    print(f"  真人触发 {h_run}/{len(humans)} ({h_run/len(humans)*100:.0f}%) | "
          f"AI 触发 {a_run}/{len(ais)} ({a_run/len(ais)*100:.0f}%) | "
          f"判定: 无区分度 → HINT（骨架匀速靠通读+双评委）")

    # ---- 弱信号 · 感官密度 ----
    print("\n[弱信号 感官密度] 每800字<1处身体感触发率:")
    h_hint = sum(1 for _, t, p, h in humans if gc._sensory_hint(p, h)["hint"])
    a_hint = sum(1 for _, t, p, h in ais if gc._sensory_hint(p, h)["hint"])
    print(f"  真人 {h_hint}/{len(humans)} | AI {a_hint}/{len(ais)}（提示级，不 FAIL）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
