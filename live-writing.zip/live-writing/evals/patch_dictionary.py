#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把 move-dictionary.json 的标定相关字段改为真人语料实测分位数。

容错：先去掉对象/数组的尾随逗号（trailing comma），避免原文件非法 JSON 导致解析失败。
"""
import json
import re
from pathlib import Path

P = Path(r"C:/Users/31905/.workbuddy/skills/live-writing/rules/move-dictionary.json")
raw = P.read_text(encoding="utf-8")
raw = re.sub(r",(\s*[}\]])", r"\1", raw)  # 去掉尾随逗号
d = json.loads(raw)

d["calibration"]["method"] = ("阈值基于 2026-08 对 10 篇互联网真人中文语料（非虚构报道 / 技术随笔 / "
    "生活叙事混合，约 4.1 万字，存 evals/corpus/）实测分位数标定：entity 密度 P10≈17.7、"
    "median 32.4；hedge 密度真人上限 0.32、P90 0.25。据此 entity 8→15、hedge 3.0→1.0。"
    "样本量小（N=10），后续随语料扩张可多次重标定。")
d["calibration"]["note"] = ("换文体（科技评测/个人随笔/历史叙事）可能显著改变分布。样本量小（N=10），"
    "分位数仅供首轮标定；语料扩至 30+ 篇后建议二次标定收紧。遇到系统性误报/漏报，"
    "优先调整对应 engine 的 params，不动 severity。")
d["calibration"]["todo"] = ("已用 10 篇真人语料首轮标定：entity 8→15、hedge 3.0→1.0。"
    "待语料扩至 30+ 篇后二次标定（按 P10/P90 收紧）；并补全其他 engine"
    "（sentence_length_cv / conjunction_density / short_streak / heavy_de / left_branch 等）的语料标定。")

OLD_NOTE = "阈值标定：经验初值，见字典顶部 calibration。"
NEW_NOTE = "阈值标定：基于真人语料实测分位数（见字典顶部 calibration）。"

for rule in d["rules"]:
    if rule["id"] == "LW-MATERIAL-002":
        rule["params"]["per_thousand"] = 15
        if "note" in rule:
            rule["note"] = rule["note"].replace(OLD_NOTE, NEW_NOTE)
    if rule["id"] == "LW-HEDGE-001":
        rule["params"]["per_thousand"] = 1.0
        if "note" in rule:
            rule["note"] = rule["note"].replace(OLD_NOTE, NEW_NOTE)

P.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
print("patched OK")
for r in d["rules"]:
    if r["id"] in ("LW-MATERIAL-002", "LW-HEDGE-001"):
        print(" ", r["id"], "per_thousand =", r["params"].get("per_thousand"))
