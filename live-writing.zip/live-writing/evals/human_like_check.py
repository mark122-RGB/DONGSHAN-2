#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""稿件「像不像真人」检测：把稿件指纹逐维度丢进真人语料分布里比。

用法：
  python human_like_check.py <稿件.md> [--corpus evals/corpus] [--engine]

输出：
  1) 5 个句法标量 + 虚词/标点距离在真人 min/median/max 中的位置（出界=红）
  2) 若 --engine，复用 check_prose 的 engine（entity/hedge/cv/…）对比真人分布
"""
from __future__ import annotations

import argparse
import glob
import json
import math
import os
import re
import statistics
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "scripts"))
import check_prose as cp  # noqa: E402
import style_fingerprint as sf  # noqa: E402

SCALARS = ["sent_len_mean", "sent_len_cv", "ttr", "conj_per_1000", "para_len_mean", "epigram_stack"]


def load_corpus(paths):
    docs = []
    for p in paths:
        text = Path(p).read_text(encoding="utf-8")
        try:
            fp = sf.fingerprint(text)
        except ValueError:
            continue
        docs.append((Path(p).stem, fp))
    return docs


def dist_stats(values):
    return min(values), statistics.median(values), max(values)


def locate(v, lo, med, hi):
    if v < lo:
        return f"{v}  ↓低于真人最低 {lo}"
    if v > hi:
        return f"{v}  ↑高于真人最高 {hi}"
    if v <= med:
        return f"{v}  中位以下（{lo}~{med}）"
    return f"{v}  中位以上（{med}~{hi}）"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("target", help="要检测的稿件")
    ap.add_argument("--corpus", default=str(HERE / "corpus"), help="真人语料目录")
    ap.add_argument("--engine", action="store_true", help="追加 check_prose engine 对比")
    args = ap.parse_args()

    target_text = Path(args.target).read_text(encoding="utf-8")
    target_fp = sf.fingerprint(target_text)
    docs = load_corpus(glob.glob(os.path.join(args.corpus, "*.md")))
    print(f"真人语料 {len(docs)} 篇，稿件汉字 {target_fp['han']}\n")

    # 1) 标量维度：稿件 vs 真人分布
    print("== 句法标量（真人分布 vs 稿件）==")
    for k in SCALARS:
        vals = [d[1][k] for d in docs]
        lo, med, hi = dist_stats(vals)
        print(f"  {k:<16} 真人[{lo:.2f}~{hi:.2f}] 中位{med:.2f} | 稿件: {locate(target_fp[k], lo, med, hi)}")

    # 2) 虚词 / 标点余弦距离：稿件 vs 每篇真人两两距离的分布
    print("\n== 虚词·标点距离（稿件 vs 每篇真人，越低越像）==")
    func_ds, punct_ds = [], []
    for _, f in docs:
        func_ds.append(sf.cosine_dist(target_fp["func"], f["func"]))
        punct_ds.append(sf.cosine_dist(target_fp["punct"], f["punct"]))
    for label, vals in (("虚词距离", func_ds), ("标点距离", punct_ds)):
        lo, med, hi = dist_stats(vals)
        print(f"  {label}: {lo:.2f}~{hi:.2f}（中位{med:.2f}）")

    # 3) 综合偏离度：稿件 vs 每篇真人（平均基线），看稿件与「真人群体」的距离分布
    print("\n== 综合偏离度（稿件 vs 真人群体）==")
    base = sf.average_fps([f for _, f in docs])
    d = sf.distance(target_fp, base)
    print(f"  综合 {d['偏离度']} / 100（<25 贴合，<15 很贴合）")
    for k, v in d["句法标量偏离"].items():
        print(f"    {k}: {v}%")

    # 4) engine 对比（标定过的关键引擎）
    if args.engine:
        sys.path.insert(0, str(HERE))  # 供 import calibrate
        import calibrate as cal

        print("\n== check_prose engine（真人分布 vs 稿件）==")
        for label, fn in (("实体密度 entity/千字", cal.entity_per_k),
                          ("hedge 密度 /千字", cal.hedge_per_k)):
            vals = []
            for p in glob.glob(os.path.join(args.corpus, "*.md")):
                t = Path(p).read_text(encoding="utf-8")
                prose = cal.mask_non_prose(t)
                if cal.han_count(prose) < 400:
                    continue
                r = fn(prose)
                if r is not None:
                    vals.append(r[0])
            if vals:
                lo, med, hi = dist_stats(vals)
                tv = fn(cal.mask_non_prose(target_text))[0]
                status = "出界（偏AI或偏极端）" if not (lo <= tv <= hi) else "分布内"
                print(f"  {label}: 真人 {lo:.2f}~{hi:.2f} 中位{med:.2f} | 稿件 {tv:.2f} → {status}")


def compute_engine_value(eng, text):
    return None


if __name__ == "__main__":
    raise SystemExit(main())
