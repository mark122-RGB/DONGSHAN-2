#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""深度一致性检查：references 死链 / 文档数字 vs 实际 / CHANGELOG 覆盖。"""
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent  # live-writing/
issues = []

# 1. references 互相引用死链
refs = list((ROOT / "references").glob("*.md"))
names = {r.name for r in refs}
broken = []
for r in refs:
    t = r.read_text(encoding="utf-8")
    for m in re.findall(r"`?references/([a-z0-9_\-]+\.md)`?", t):
        if m not in names:
            broken.append((r.name, m))
print(f"[{'OK' if not broken else 'FAIL'}] references 互相引用死链: {broken if broken else '无'}")

# 2. 文档数字 vs 实际
d = json.loads((ROOT / "rules" / "move-dictionary.json").read_text(encoding="utf-8"))
corpus_n = len(list((ROOT / "evals" / "corpus").glob("*.md")))
golden_n = len(json.loads((ROOT / "evals" / "golden_set.json").read_text(encoding="utf-8"))["samples"])
rules_n = len(d["rules"])

cal = d["calibration"]["method"]
cal_note = d["calibration"]["note"]
cal_todo = d["calibration"]["todo"]
print(f"corpus 实际 {corpus_n} 篇 | golden 实际 {golden_n} 条 | 规则实际 {rules_n} 条")
print(f"[{'OK' if '30 篇' in cal_note or '30篇' in cal_note or f'{corpus_n} 篇' in cal_note else 'WARN'}] calibration.note 语料数声称 vs 实际: {corpus_n} 篇")
print(f"[{'OK' if '40 条' in cal_note or f'{rules_n} 条' in cal_note else 'WARN'}] calibration.note 规则数声称 vs 实际: {rules_n} 条")

# 3. SKILL.md 中声称的 golden/语料数字
sk = (ROOT / "SKILL.md").read_text(encoding="utf-8")
for label, actual, pats in [
    ("golden set 条数", golden_n, [r"golden set (\d+) 条", r"golden(\d+)"]),
    ("corpus 篇数", corpus_n, [r"(\d+) 篇真人语料", r"(\d+)篇真人语料"]),
]:
    found = None
    for p in pats:
        m = re.search(p, sk)
        if m:
            found = int(m.group(1))
            break
    if found is None:
        print(f"[WARN] SKILL.md 未找到 {label} 的声称数字（实际 {actual}）")
    elif found != actual:
        print(f"[FAIL] SKILL.md 声称 {label}={found}，实际 {actual}")
    else:
        print(f"[OK ] SKILL.md {label}={found} 与一致")

# 4. CHANGELOG 覆盖今天的关键改动
ch = (ROOT / "CHANGELOG.md").read_text(encoding="utf-8")
key_items = ["craft", "feature-writing", "judge", "双评委", "density", "角度收敛", "单点衍生", "不给解法", "fiction", "material-gate", "触觉", "health_check", "full_check", "craft_check"]
missing = [k for k in key_items if k.lower() not in ch.lower()]
print(f"[{'OK' if not missing else 'WARN'}] CHANGELOG 未覆盖的关键词: {missing if missing else '全部覆盖'}")
print(f"CHANGELOG 当前版本块: {[l for l in ch.splitlines() if l.startswith('## ')]}")
