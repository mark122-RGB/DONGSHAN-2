#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""第 4 轮标定：散文/小说子集 vs 其余，分布型 engine 分位数对比。

用法：python evals/calibrate4.py
只读分析，不改任何文件。输出每个分布型 engine 在两组的分位数，供人工判断是否漂移。
"""
import glob
import json
import statistics
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / "scripts"))
import check_prose as cp  # noqa: E402

DICT = json.loads((ROOT / "rules" / "move-dictionary.json").read_text(encoding="utf-8"))
RULES = {r["id"]: r for r in DICT["rules"] if r.get("kind") == "engine"}


def pct(vals, p):
    """线性插值分位数，与 calibrate2 一致。"""
    if not vals:
        return None
    vals = sorted(vals)
    k = (len(vals) - 1) * p
    lo = int(k)
    hi = min(lo + 1, len(vals) - 1)
    w = k - lo
    return vals[lo] * (1 - w) + vals[hi] * w


def han(t):
    return len(cp.HAN_RE.findall(t))


def group_stats(files):
    """返回 {engine_id: [每篇的标量/触发值]}，按规则语义取标量。"""
    out = {}
    for f in files:
        text = Path(f).read_text(encoding="utf-8")
        prose = cp.mask_non_prose(text)
        h = han(prose)
        if h < 300:
            continue
        for rid, rule in RULES.items():
            engine = cp.ENGINES.get(rule.get("engine", ""))
            if not engine:
                continue
            # 标量型引擎：直接跑，取其数字语义
            val = scalar_from(engine, prose, rule, h)
            if val is not None:
                out.setdefault(rid, []).append(val)
    return out


def scalar_from(engine, prose, rule, h):
    """把 engine 的返回（failures/warnings 消息）转成标量；失败返回 None。"""
    params = rule.get("params", {})
    try:
        result = engine(prose, rule, params)
    except Exception:
        return None
    if not result:
        return 0.0
    msg = result[0]
    # 提取第一处数字（命中数/密度）
    import re
    m = re.search(r"(\d+(?:\.\d+)?)", msg)
    return float(m.group(1)) if m else 1.0


def per_thousand_scalar(engine, prose, rule, h):
    """对密度类引擎，转成 每千字 触发数。"""
    import re
    params = rule.get("params", {})
    try:
        result = engine(prose, rule, params)
    except Exception:
        return None
    if not result:
        return 0.0
    m = re.search(r"(\d+(?:\.\d+)?)", result[0])
    return float(m.group(1)) * 1000 / h if m else 0.0


def main():
    all_files = sorted(glob.glob(str(ROOT / "evals/corpus" / "*.md")))
    fic_essay = [f for f in all_files if Path(f).stem.startswith(("essay_", "fic_"))]
    rest = [f for f in all_files if f not in fic_essay]
    print(f"散文/小说 {len(fic_essay)} 篇 | 其余 {len(rest)} 篇 | 共 {len(all_files)} 篇\n")

    # 每个分布型 engine 分别取标量（触发数/千字）看分布
    for rid, rule in RULES.items():
        eng_name = rule.get("engine", "")
        if eng_name not in cp.ENGINES:
            continue
        # 收集两组标量
        vals_a, vals_b = [], []
        for f in fic_essay:
            text = Path(f).read_text(encoding="utf-8")
            prose = cp.mask_non_prose(text)
            h = han(prose)
            if h < 300:
                continue
            v = per_thousand_scalar(cp.ENGINES[eng_name], prose, rule, h)
            if v is not None:
                vals_a.append(v)
        for f in rest:
            text = Path(f).read_text(encoding="utf-8")
            prose = cp.mask_non_prose(text)
            h = han(prose)
            if h < 300:
                continue
            v = per_thousand_scalar(cp.ENGINES[eng_name], prose, rule, h)
            if v is not None:
                vals_b.append(v)
        if not vals_a or not vals_b:
            continue
        pa = [pct(vals_a, p) for p in (0.5, 0.9)]
        pb = [pct(vals_b, p) for p in (0.5, 0.9)]
        drift = "⚠️ 漂移" if abs(pa[0] - pb[0]) > max(0.5, pb[0] * 0.5) else "—"
        print(f"{rid:<22} {eng_name:<24} 散文/小说 中位{pct(vals_a,0.5):>6.2f} P90{pct(vals_a,0.9):>6.2f} | 其余 中位{pct(vals_b,0.5):>6.2f} P90{pct(vals_b,0.9):>6.2f}  {drift}")


if __name__ == "__main__":
    main()
