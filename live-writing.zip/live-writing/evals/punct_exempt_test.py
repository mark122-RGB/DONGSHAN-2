#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""LW-PUNCT-001 冒号豁免的对抗测试。

golden_set.json 只能表达「hard 触发 / 不触发」与「某条 warn 在不在」，
表达不了本规则真正关心的东西：**同一条 warn，是逐条刷屏还是聚合成一行**。
所以豁免逻辑用这个脚本单独守。

两类断言：
- hard：AI 的「提示词 + 断言」式冒号（一句话总结：／更重要的是：），
        放宽豁免后必须仍被 LW-PUNCT-002 等硬规则抓住，一条都不许放跑。
- quiet：真人高频用法（转述、列举、元数据、书名、编号标签），
        允许出现在末尾的聚合豁免行里，但不许逐条刷屏。

改了 check_prose.py 的 punct 分支或 SPEECH_LEAD_RE/META_LABEL_RE/
NUM_LABEL_RE/ENUM_HEAD_RE 之后，跑这个 + run_eval.py。
用法：python punct_exempt_test.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "scripts"))
import check_prose as cp  # noqa: E402

DICT = json.loads((HERE.parent / "rules" / "move-dictionary.json").read_text(encoding="utf-8"))

CASES = [
    # --- AI 提示性冒号／宣言破折号：必须仍被硬规则抓住 ---
    ("一句话总结：这件事很关键——它改变了走向。", "hard"),
    ("我们必须承认：制度本身有问题。", "hard"),
    ("更重要的是：他其实没有别的选择。", "hard"),
    ("值得注意的是：数据在下滑。", "hard"),
    ("可以说这是唯一解释：机制失灵了。", "hard"),
    ("这件事很关键——它改变了整个走向。", "hard"),
    ("很多人觉得他做错了：其实不然。", "hard"),
    # --- 真人高频用法：不许逐条刷屏 ---
    ("妻告诉我：那年大年三十晚上，岳父又开始发烧。", "quiet"),          # 言说动词隔宾语
    ("父亲又发来短信：消息看完记得删了。", "quiet"),                    # 转述载体
    ("我可以明确告诉你：会写作的人不会过得差。", "quiet"),              # 动词隔补语
    ("我终于越来越懂得：日子是熬出来的。", "quiet"),                    # 心理动词
    ("医生开了一系列检查：肿瘤标志物、甲状腺功能、内分泌六项。", "quiet"),  # 顿号列举
    ("系统一个零件都没改：值班还是没人，会诊还是不记得，转诊还是靠家属。", "quiet"),  # 逗号并列
    ("核心就两个观点：第一，电商砍掉中间商；第二，价格战反噬供应链。", "quiet"),  # 枚举引导
    ("本文来源：学习强国。", "quiet"),                                  # 元数据标签
    ("从《倩女幽魂3：道道道》到《犯罪都市》，韩国电影占比不低。", "quiet"),  # 书名内冒号
    ("1.身份性质：编外合同制人员，不占行政编制。", "quiet"),            # 编号小标题
    ("他说：“我提醒过了。”", "quiet"),                                  # 引出原话
    ("会议定在 9:30，地点没变。", "quiet"),                             # 时间格式
]


def run_all(text: str):
    prose = cp.mask_non_prose(text)
    fails, warns = [], []
    for rule in DICT["rules"]:
        if rule.get("kind") == "agent":
            continue
        f, w = cp.run_rule(rule, prose, text, "all")
        fails.extend(f)
        warns.extend(w)
    return fails, warns


def main() -> int:
    ok = bad = 0
    lines = []
    for text, exp in CASES:
        fails, warns = run_all(text)
        loud = [m for m in fails + warns if "LW-PUNCT-001" in m and "已自动豁免" not in m]
        good = bool(fails) if exp == "hard" else not loud
        ok, bad = (ok + 1, bad) if good else (ok, bad + 1)
        lines.append(f"[{'OK ' if good else 'MISS'}] exp={exp:<5} hard={len(fails)} "
                     f"逐条PUNCT={len(loud)}  {text[:32]}")
    print("逐样本：")
    for l in lines:
        print("  " + l)
    print(f"\n豁免对抗测试：{ok}/{len(CASES)} 通过")
    if bad:
        print("有 MISS：要么放跑了 AI 提示性冒号，要么真人用法又开始逐条刷屏。")
        return 1
    print("全部通过。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
