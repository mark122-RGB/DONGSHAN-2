#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""临时验证：实体密度人名识别。"""
import re
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
import check_prose as cp

t = Path("outputs/韩杰医生案时评-第四版-树靶打法.md").read_text(encoding="utf-8")
prose = cp.mask_non_prose(t)
h = cp.han_count(prose)
strong = "韩杜邓曹郑冯吕袁蒋蔡潘谭廖龚邢沈钟姜董史陶贺孔邵贾魏卢薛罗姚苏叶程谢梁宋许赵吴周徐孙马朱胡黄杨陈刘张李王"
stop = "不一的是在有了可为也还都这对那"
pat = re.compile(rf"(?:[{strong}])[^{stop}][\u4e00-\u9fff]?(?=[，。；：！？\s\"'\"']|$|的|说|道|认为|医生|主任|案|某|先生|女士)")
names = pat.findall(prose)
for w, c in Counter(names).most_common(15):
    print(f"{w} ×{c}")
print("总计", len(names))
nums = len(re.findall(r"[0-9]+", prose))
units = len(re.findall(r"(?:年|月|日|岁|万|亿|元|%)", prose))
orgs = len(re.findall(r"(?:大学|医院|公司|集团|中心|局|委|省|市|县|法院|学校)", prose))
en = len(re.findall(r"[A-Za-z]{2,}", prose))
signals = nums + units + orgs + en + len(names)
print(f"数字{nums} 单位{units} 机构{orgs} 英文{en} 人名{len(names)} = {signals}，密度 {signals*1000/h:.1f}/千字")
