# -*- coding: utf-8 -*-
"""实测 LW-PUNCT-001 / LW-STOP-001 在 17 篇真人语料上的误报率。"""
import sys, os, glob, json, re
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
import check_prose

DICT = json.load(open(os.path.join(os.path.dirname(__file__), "..", "rules", "move-dictionary.json"), encoding="utf-8"))
rules = {r["id"]: r for r in DICT["rules"]}

def load_corpus():
    docs = []
    for p in glob.glob(os.path.join(os.path.dirname(__file__), "corpus", "*.md")):
        text = open(p, encoding="utf-8").read()
        han = len(re.findall(r"[\u4e00-\u9fff]", text))
        docs.append((os.path.basename(p), text, han))
    return docs

docs = load_corpus()
print(f"语料 {len(docs)} 篇，共 {sum(d[2] for d in docs):,} 汉字\n")

for rid in ["LW-PUNCT-001", "LW-STOP-001"]:
    rule = rules[rid]
    hits = hard_hits = warn_hits = 0
    hard_docs = warn_docs = 0
    per_doc = []
    for name, text, han in docs:
        f, w = check_prose.run_rule(rule, text, text, "all")
        n = len(f) + len(w)
        if f:
            hard_docs += 1
        if w:
            warn_docs += 1
        per_doc.append((name, len(f), len(w), han))
        hits += n
        hard_hits += len(f)
        warn_hits += len(w)
    total_han = sum(d[2] for d in docs)
    print(f"== {rid} {rule['name']} ==")
    print(f"   总计 {hits}（hard {hard_hits} / warn {warn_hits}），hard 文章 {hard_docs}/{len(docs)}，warn 文章 {warn_docs}/{len(docs)}")
    print(f"   hard 每千字 {hard_hits/total_han*1000:.2f}；warn 每千字 {warn_hits/total_han*1000:.2f}")
    for name, f, w, han in sorted(per_doc, key=lambda x: -(x[1] + x[2]))[:6]:
        print(f"   {name}: hard {f} / warn {w} ({han:,}字)")
    print()

# 统计「说白了」在语料中是否出现
print("== 「说白了」在真人语料中 ==")
for name, text, han in docs:
    c = text.count("说白了")
    if c:
        print(f"   {name}: {c} 次")
print("   (以上为出现过的文章；未列出=0)")
