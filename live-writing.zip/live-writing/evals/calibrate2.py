#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""第 2 轮标定：对 corpus/ 下 17 篇真人中文语料，复用 check_prose.py 真实引擎，
计算 5 个待标定 engine 的真人分布 / 触发率，用于把其经验初值阈值替换为实测分位数。

复用的逻辑与 scripts/check_prose.py 完全一致（直接 import 其 engine 函数与 helper），
确保标定出的阈值与实际 linter 行为对齐。
"""
import sys, json, re, statistics
from pathlib import Path

SKILL = Path(r"C:/Users/31905/.workbuddy/skills/live-writing")
sys.path.insert(0, str(SKILL / "scripts"))
import check_prose as cp  # noqa: E402


def load_dict(p):
    raw = re.sub(r",(\s*[}\]])", r"\1", p.read_text(encoding="utf-8"))
    return json.loads(raw)


dic = load_dict(SKILL / "rules" / "move-dictionary.json")
rules = {r["id"]: r for r in dic["rules"]}

TARGETS = {
    "LW-RHYTHM-001": "sentence_length_cv",
    "LW-RHYTHM-002": "conjunction_density",
    "LW-RHYTHM-003": "short_streak",
    "LW-SYNTAX-001": "left_branch",
    "LW-SYNTAX-002": "heavy_de",
}

corpus = SKILL / "evals" / "corpus"
cvs, conjs = [], []
fire = {tid: 0 for tid in TARGETS}
n = 0
for f in sorted(corpus.glob("*.md")):
    text = f.read_text(encoding="utf-8")
    prose = cp.mask_non_prose(text)
    if cp.han_count(prose) < 400:
        continue
    n += 1
    # --- cv scalar (flag when cv < thr) ---
    L = [cp.han_count(m.group()) for m in re.finditer(r"[^。！？!?\n]+[。！？!?]", prose)
         if cp.han_count(m.group()) >= 4]
    if len(L) >= 12:
        mean = sum(L) / len(L)
        if mean:
            var = sum((v - mean) ** 2 for v in L) / len(L)
            cvs.append((var ** 0.5) / mean)
    # --- conjunction scalar (flag when per_k > thr) ---
    r2 = rules["LW-RHYTHM-002"]
    total = cp.han_count(prose)
    if total >= 600:
        hits = cp.non_overlapping_terms(prose, r2["terms"])
        conjs.append(len(hits) * 1000 / total)
    # --- structural engines: 是否触发 ---
    for tid, eng in TARGETS.items():
        rule = rules[tid]
        if cp.ENGINES[eng](prose, rule, rule["params"]):
            fire[tid] += 1


def pct(data, p):
    s = sorted(data)
    k = (len(s) - 1) * p
    f = int(k)
    c = min(f + 1, len(s) - 1)
    return s[f] + (s[c] - s[f]) * (k - f)


print(f"有效文章数 (han>=400): {n}")
print(f"\n=== RHYTHM-001 sentence_length_cv （规则：cv < 阈值 才报警）===")
print(f"可计算文章 (>=12 句): {len(cvs)}  最小={min(cvs):.2f}  最大={max(cvs):.2f}  中位={statistics.median(cvs):.2f}")
for p in (0.05, 0.1, 0.25, 0.5):
    print(f"  P{int(p*100):>2} = {pct(cvs, p):.2f}")
print(f"  >> 当前阈值 0.42；若真人最小={min(cvs):.2f}，则 {(sum(1 for x in cvs if x < 0.42)/len(cvs)):.0%} 真人会被误伤")

print(f"\n=== RHYTHM-002 conjunction per_1k （规则：per_k > 阈值 才报警）===")
print(f"可计算文章 (han>=600): {len(conjs)}  最小={min(conjs):.2f}  最大={max(conjs):.2f}  中位={statistics.median(conjs):.2f}")
for p in (0.5, 0.75, 0.9, 0.95):
    print(f"  P{int(p*100):>2} = {pct(conjs, p):.2f}")
print(f"  >> 当前阈值 7；真人超过 7 的占比 = {sum(1 for x in conjs if x > 7)/len(conjs):.0%}")

print(f"\n=== 结构类 engine 在真人语料上的触发率（warn 容忍 ~10%）===")
for tid in TARGETS:
    if tid in ("LW-RHYTHM-001", "LW-RHYTHM-002"):
        continue
    rate = fire[tid] / n if n else 0
    print(f"  {tid} ({TARGETS[tid]}): 触发 {fire[tid]}/{n} = {rate:.0%}")
