#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""解析知乎回答 JSON 并提取正文（用于语料筛选）。"""
import json
import re
import sys
from pathlib import Path


def clean(html):
    html = re.sub(r"<[^>]+>", "", html)
    html = html.replace("&quot;", '"').replace("&amp;", "&").replace("&#39;", "'")
    html = html.replace("&lt;", "<").replace("&gt;", ">").replace("&nbsp;", " ")
    return html.strip()


def main():
    f = Path(sys.argv[1])
    d = json.loads(f.read_text(encoding="utf-8"))
    inner = d.get("data", {}).get("data", {})
    # TikHub 返回嵌套：data.data 是 dict，其 'data' 键才是回答列表
    if isinstance(inner, dict):
        inner = inner.get("data", [])
    cards = [c for c in inner if isinstance(c, dict)]
    print(f"回答数: {len(cards)}")
    for i, card in enumerate(cards, 1):
        tgt = card.get("target", {}) or {}
        author = (tgt.get("author") or {}).get("name", "匿名")
        votes = tgt.get("voteup_count", 0)
        content = clean(tgt.get("content", ""))
        print(f"--- [{i}] {author} 赞{votes} 字数{len(content)} ---")
        print(content[:400])
        print()


if __name__ == "__main__":
    main()
