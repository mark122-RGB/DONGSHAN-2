#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""第 2 轮标定落地：把 5 个 engine 的 params 与 calibration 头更新为 17 篇真人语料实测值。"""
import json, re
from pathlib import Path

DIC = Path(r"C:/Users/31905/.workbuddy/skills/live-writing/rules/move-dictionary.json")

raw = DIC.read_text(encoding="utf-8")
raw = re.sub(r",(\s*[}\]])", r"\1", raw)  # 容忍历史遗留尾逗号
dic = json.loads(raw)
rules = {r["id"]: r for r in dic["rules"]}

# --- 1. 改 5 条规则的 params / note ---
updates = {
    "LW-RHYTHM-001": {
        "params": {"cv_threshold": 0.39, "min_sentences": 12},
        "note": "人写的段落里十个字的句子会挨着四十个字的句子。变异系数过低说明是机器匀速。2026-08 对 17 篇真人语料实测：cv 中位 0.51、P10 0.39、最小 0.36；阈值由 0.42 降至 0.39（P10），真人误伤由 35% 降到约 10%。",
    },
    "LW-RHYTHM-002": {
        "params": {"per_thousand": 7, "min_han": 600},
        "note": "中文小句靠语序和事理相接，连接词堆叠是英语式机器节奏。2026-08 对 17 篇真人语料实测：连词密度中位 3.19、P95 5.72、上限 6.32/千字；阈值 7 真人零误伤，保留。",
    },
    "LW-RHYTHM-003": {
        "params": {"limit": 7, "para_min": 14, "ratio": 0.85},
        "note": "短段鼓点 / 连续单句段。2026-08 标定：原 limit4/ratio0.75/para_min10 在真人语料触发率 41%（过严）；改为 limit7/ratio0.85/para_min14 后降到 12%，只抓真正排队喊结论的段落。",
        "fix": "检查是否在排队喊结论，把能顺着读的合并。",
    },
    "LW-SYNTAX-001": {
        "params": {"divisor": 1200, "min": 2},
        "note": "长前置成分（在…之后/那些…的/让…的，是）。2026-08 标定：17 篇真人语料触发率 0%，阈值保留；AI 长定语更易命中。",
        "fix": "主干早点来。先让人和动作出现，再补时间、原因、条件。",
    },
    "LW-SYNTAX-002": {
        "params": {"min_han": 45, "min_de": 6, "divisor": 3000, "min": 2},
        "note": "多「的」长句。2026-08 标定：原 min_de4/min_han38/divisor1500/min1 在真人语料触发率 65%（严重过严）；改为 min_de6/min_han45/divisor3000/min2 后降到 18%（语料下限——部分真人确有重定语长句，warn 级可接受，系统性误报走漏网闭环）。",
        "fix": "长定语拆开，先让人和东西出现，再补来历和条件。",
    },
}
for rid, u in updates.items():
    rules[rid]["params"] = u["params"]
    rules[rid]["note"] = u["note"]
    if "fix" in u:
        rules[rid]["fix"] = u["fix"]

# --- 2. 改 calibration 头 ---
dic["calibration"]["method"] = (
    "阈值分两轮基于互联网真人中文语料实测分位数标定。"
    "第 1 轮（2026-08，10 篇 ~4.1 万字）：entity 密度 8→15、hedge 密度 3.0→1.0。"
    "第 2 轮（2026-08，扩至 17 篇 ~6.7 万字，存 evals/corpus/）："
    "sentence_length_cv 由 0.42→0.39（P10，真人误伤 35%→10%）；"
    "conjunction_density 实测上限 6.32/千字、阈值 7 零误伤，保留；"
    "short_streak 由 limit4/ratio0.75/para_min10 改为 limit7/ratio0.85/para_min14（触发率 41%→12%）；"
    "heavy_de 由 min_de4/min_han38/divisor1500/min1 改为 min_de6/min_han45/divisor3000/min2（触发率 65%→18%，语料下限）；"
    "left_branch 实测 0% 误伤，保留。"
)
dic["calibration"]["note"] = (
    "换文体（科技评测/个人随笔/历史叙事）可能显著改变分布。样本量仍偏小（N=17），分位数供当前标定；"
    "语料扩至 30+ 篇后可做第 3 轮收紧。剩余未标定 engine（anaphora_runs / lyric_density / metaphor_cluster / "
    "bracket_highlights / soft_marker_density / repeated_opener / numbered_list / tail_density）仍为经验初值，"
    "系统性误报/漏报优先调对应 engine 的 params，不动 severity；漏网样本进 evals/false_negatives.txt 闭环。"
)
dic["calibration"]["todo"] = (
    "第 1 轮（entity/hedge）与第 2 轮（cv/conjunction/short_streak/heavy_de/left_branch）已用 17 篇真人语料标定完成。"
    "下一步：① 语料扩至 30+ 篇做第 3 轮收紧（尤其 heavy_de 的 18% 下限）；"
    "② 标定剩余 8 个 engine；③ 用真实稿件喂 evals/false_negatives.txt 漏网闭环。"
)

DIC.write_text(json.dumps(dic, ensure_ascii=False, indent=2), encoding="utf-8")
print("patched. 校验关键 params：")
for rid in ("LW-RHYTHM-001", "LW-RHYTHM-002", "LW-RHYTHM-003", "LW-SYNTAX-001", "LW-SYNTAX-002"):
    print(f"  {rid}: {rules[rid]['params']}")
