#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""语义层指标探索：金句率 / 断言密度 / 感官密度。

目标：验证这三类「味道层」指标能否区分 AI 味稿与活人感稿（统计层实测区分度有限）。
流程：17 篇真人语料算分布 → 原稿 vs 重写稿定位 → 若 AI 稿显著出界则固化为 engine。
"""
from __future__ import annotations

import re
import statistics
import sys
from pathlib import Path

BASE = Path(r"C:/Users/31905/.workbuddy/skills/live-writing")
sys.path.insert(0, str(BASE / "scripts"))
import check_prose as cp  # noqa: E402

HAN = re.compile(r"[\u4e00-\u9fff]")

# ---- 断言标记（高断言性，排除真人高频的「其实/确实/真的」低断言词）----
ASSERT_MARKS = [
    "意味着", "说明了", "体现了", "决定了", "证明了", "显示出", "表明", "正是在于",
    "本质上", "根本上", "说到底", "事实上", "换句话说", "也就是说", "关键在于",
    "重点在于", "重要在于", "恰恰是", "无非是", "终究是",
]
# ---- 感官词（视觉/听觉/触觉/嗅觉/味觉）----
SENSORY = {
    "视觉": ["看见", "看到", "望着", "看", "目光", "眼前", "红", "白", "黑", "蓝", "黄", "绿", "粉", "金", "银", "灰", "光", "影", "亮", "暗", "明", "颜色", "画面", "样子"],
    "听觉": ["听见", "听到", "声音", "声响", "响声", "吵", "静", "喊", "吼", "尖叫", "哭", "笑", "铃声", "脚步声", "说话声", "喊着", "唱着"],
    "触觉": ["冰凉", "发烫", "烫", "冷", "暖", "疼", "痛", "粗糙", "滑", "黏", "刺骨", "热乎", "温热", "冷飕飕", "汗"],
    "嗅觉": ["闻到", "香味", "香气", "气味", "臭味", "腥", "芬芳", "香水", "饭菜香"],
    "味觉": ["甜", "酸", "苦", "辣", "咸", "涩", "味道", "尝", "腻"],
}


def paras(text):
    return [p for p in re.split(r"\n\s*\n", text) if len(HAN.findall(p)) >= 8]


def last_sentence(p):
    sents = re.findall(r"[^。！？!?\n]+[。！？!?]", p)
    return sents[-1] if sents else ""


def is_epigram(s):
    """段末金句候选：短句 + 判断/强调结构。"""
    h = len(HAN.findall(s))
    if not (4 <= h <= 16):
        return False
    if re.search(r"(不是|是|就是|才是|不过是|无非是|意味着|在于|不过是|都)", s):
        return True
    if re.search(r"[：—]", s):
        return True
    if re.search(r"[^，。！？]{2,6}，[^，。！？]{2,8}。$", s):
        return True
    return False


def metrics(text):
    prose = cp.mask_non_prose(text)
    han = len(HAN.findall(prose))
    if han < 400:
        return None
    # 金句率：段末金句段 / 总段数
    ps = paras(prose)
    epi = sum(1 for p in ps if is_epigram(last_sentence(p)))
    epi_rate = epi / len(ps) if ps else 0.0
    # 断言密度 /千字
    assert_hits = sum(prose.count(w) for w in ASSERT_MARKS)
    # 感官密度 /千字（按汉字计数，避免重叠词多次计数：用 finditer 去重位置）
    sensory_hits = 0
    for cat, words in SENSORY.items():
        pat = re.compile("|".join(re.escape(w) for w in words))
        sensory_hits += len(pat.findall(prose))
    return {
        "han": han,
        "epigram_per_para": round(epi_rate, 3),
        "assert_per_1000": round(assert_hits * 1000 / han, 3),
        "sensory_per_1000": round(sensory_hits * 1000 / han, 3),
        "epi_para": (epi, len(ps)),
        "assert_n": assert_hits,
        "sensory_n": sensory_hits,
    }


def main():
    targets = {
        "原稿(AI味)": Path(BASE / "evals/_compare/原稿_茉莉奶白.md"),
        "重写稿(活人感)": Path(r"C:/Users/31905/Desktop/茉莉奶白-LV-商标案.md"),
    }
    # 真人分布
    human = []
    for p in sorted((BASE / "evals/corpus").glob("*.md")):
        m = metrics(p.read_text(encoding="utf-8"))
        if m:
            human.append((p.stem, m))
    keys = ["epigram_per_para", "assert_per_1000", "sensory_per_1000"]
    print(f"真人语料 {len(human)} 篇\n")
    for k in keys:
        vals = [h[1][k] for h in human]
        lo, med, hi = min(vals), statistics.median(vals), max(vals)
        print(f"== {k} ==")
        print(f"  真人: min {lo:.3f} / 中位 {med:.3f} / max {hi:.3f}")
        for name, p in targets.items():
            m = metrics(p.read_text(encoding="utf-8"))
            v = m[k]
            status = "出界!" if not (lo <= v <= hi) else "分布内"
            print(f"  {name}: {v:.3f}  [{status}]")
        print()

    # 逐篇真人值排序展示（看分布形态）
    print("== 逐篇真人（按金句率排序）==")
    for stem, m in sorted(human, key=lambda x: x[1]["epigram_per_para"], reverse=True):
        print(f"  {stem:<28} 金句{m['epigram_per_para']:.2f}/段  断言{m['assert_per_1000']:.2f}/千字  感官{m['sensory_per_1000']:.2f}/千字")


if __name__ == "__main__":
    main()
