#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成 live-writing skill 的小红书发布包：5 张竖版信息图（1080x1440, 3:4）+ 文案。"""
import os
from PIL import Image, ImageDraw, ImageFont

W, H = 1080, 1440
BG = (8, 33, 30)
BG2 = (11, 47, 42)
TEAL = (29, 158, 117)
TEAL_L = (93, 202, 165)
INK = (225, 245, 238)
MUT = (180, 205, 197)
AMBER = (239, 159, 39)
CORAL = (216, 90, 48)
OUT = r"C:/Users/31905/Desktop/live-writing-小红书"
os.makedirs(OUT, exist_ok=True)

F_REG = r"C:/Windows/Fonts/msyh.ttc"
F_BOLD = r"C:/Windows/Fonts/msyhbd.ttc"


def font(size, bold=False):
    return ImageFont.truetype(F_BOLD if bold else F_REG, size)


def text_w(draw, s, f, max_w):
    lines, cur = [], ""
    for ch in s:
        if draw.textlength(cur + ch, font=f) <= max_w:
            cur += ch
        else:
            lines.append(cur)
            cur = ch
    if cur:
        lines.append(cur)
    return lines


def draw_wrap(draw, xy, s, f, fill, max_w, lh):
    x, y = xy
    for ln in text_w(draw, s, f, max_w):
        draw.text((x, y), ln, font=f, fill=fill)
        y += lh
    return y


def card(draw, x, y, w, h, fill=BG2, r=28):
    draw.rounded_rectangle([x, y, x + w, y + h], radius=r, fill=fill)


def tag(draw, x, y, s, fg=BG, bg=TEAL, size=26, pad=16):
    f = font(size, True)
    w = draw.textlength(s, font=f) + pad * 2
    h = size + pad
    draw.rounded_rectangle([x, y, x + w, y + h], radius=h // 2, fill=bg)
    draw.text((x + pad, y + (h - size) / 2 + 1), s, font=f, fill=fg)
    return x + w


def new_canvas():
    img = Image.new("RGB", (W, H), BG)
    return img, ImageDraw.Draw(img)


def footer(d, y, text):
    draw_wrap(d, (70, y), text, font(30), MUT, W - 140, 44)


def header(d, kicker, title, sub, y=80):
    tag(d, 70, y, kicker, bg=TEAL_L, fg=BG)
    tl = text_w(d, title, font(72, True), W - 140)
    draw_wrap(d, (70, y + 64), title, font(72, True), INK, W - 140, 96)
    if sub:
        draw_wrap(d, (70, y + 64 + len(tl) * 96), sub, font(34), MUT, W - 140, 50)


# ---------- 图1 封面 ----------
img, d = new_canvas()
d.rectangle([0, 0, W, 10], fill=TEAL)
d.rectangle([0, H - 10, W, H], fill=TEAL)
tag(d, 70, 120, "AI 写作 · 活人感系列", bg=TEAL_L, fg=BG)
draw_wrap(d, (70, 210), "把「去 AI 味」", font(96, True), INK, W - 140, 120)
draw_wrap(d, (70, 330), "做成会自省的 skill", font(96, True), INK, W - 140, 120)
draw_wrap(d, (70, 470), "活人写作 · 从两个 skill 融合到三层检测的进化", font(40), TEAL_L, W - 140, 56)
card(d, 70, 620, W - 70, 330, BG2)
draw_wrap(d, (110, 670), "它不是新的 AI 写作工具，", font(40), INK, W - 220, 58)
draw_wrap(d, (110, 728), "是一套会自己迭代的方法：", font(40), INK, W - 220, 58)
draw_wrap(d, (110, 786), "生成时当护栏，交付时当质检，", font(40), INK, W - 220, 58)
draw_wrap(d, (110, 844), "改一次规则，跑一次回归。", font(40), INK, W - 220, 58)
yb = 1010
for i, (num, lab) in enumerate([("46", "条规则"), ("35", "篇语料"), ("27/27", "回归全绿")]):
    x0 = 70 + i * 320
    card(d, x0, yb, 290, 190, BG2)
    draw_wrap(d, (x0 + 30, yb + 38), num, font(72, True), TEAL_L, 230, 80)
    draw_wrap(d, (x0 + 30, yb + 140), lab, font(30), MUT, 230, 44)
footer(d, 1260, "设计理念 + 融合过程，都在后面几张图")
img.save(os.path.join(OUT, "01-封面.png"))

# ---------- 图2 设计理念 ----------
img, d = new_canvas()
header(d, "PART 1 · 设计理念", "写人话，靠三根柱子", "AI 味的本质不是写得差，是写得太干净", y=80)
cols = [(70, TEAL, "① 格莱斯归因"), (70 + 340, TEAL, "② 保真红线"), (70 + 680, CORAL, "③ 毛边配额")]
tips = [
    ["AI 味 = 系统性违规：", "注水(量)、绕弯(方式)", "关系准则已收窄：", "只判机械填充，", "不禁人类通感离题"],
    ["earned 离题该留：", "带感官/真记忆的荡开", "空飘假闲笔该杀：", "无锚点的抽象填充", "判断：带了就留，", "没带就砍"],
    ["主动造可控瑕疵：", "对仗写完破一个", "金句不堆、结尾不升华", "段落像肺不像节拍器", "毛边才是人味"],
]
for (x, c, t), tip in zip(cols, tips):
    card(d, x, 330, 310, 640, BG2)
    tag(d, x + 24, 356, t, bg=c, fg=BG)
    yy = 430
    for ln in tip:
        yy = draw_wrap(d, (x + 24, yy), ln, font(34), INK if ln.endswith("：") else MUT, 262, 50)
footer(d, 1030, "判断口诀：离题带没带感官或真记忆？带了就留，没带就砍。")
footer(d, 1086, "写到最后：留一处「按规矩不该出现、但它活了」的瑕疵。")
card(d, 70, 1160, W - 70, 150, BG2)
draw_wrap(d, (110, 1192), "一句话：去的是表演性的完整，留的是有分寸的诚实。", font(38), TEAL_L, W - 220, 52)
img.save(os.path.join(OUT, "02-设计理念.png"))

# ---------- 图3 融合过程 ----------
img, d = new_canvas()
header(d, "PART 2 · 融合过程", "两个 skill，怎么融成一个", "一个管造人，一个管擦干净", y=80)
card(d, 70, 320, 470, 380, BG2)
tag(d, 94, 346, "来源 A · 创作侧", bg=TEAL, fg=BG)
draw_wrap(d, (94, 410), "数字卡兹克活人感写作", font(38, True), INK, 420, 52)
draw_wrap(d, (94, 468), "先造出「一个在说话的人」：材料、立场、感官细节、真实观点。靠原则驱动，不逐句检查。", font(32), MUT, 420, 46)
card(d, 540, 320, 470, 380, BG2)
tag(d, 564, 346, "来源 B · 交付侧", bg=TEAL, fg=BG)
draw_wrap(d, (564, 410), "公众号 De AI Polish", font(38, True), INK, 420, 52)
draw_wrap(d, (564, 468), "对照清单改稿：句式黑名单、标点规范、删套话、拆翻案腔。静态词表，换说法就漏。", font(32), MUT, 420, 46)
d.line([540, 510, 540, 540], fill=TEAL_L, width=6)
d.polygon([(525, 540), (555, 540), (540, 566)], fill=TEAL_L)
draw_wrap(d, (70, 760), "融合 → 生成期护栏 + 交付期质检 + 数据闭环", font(44, True), TEAL_L, W - 140, 60)
card(d, 70, 850, W - 140, 380, BG2)
items = [
    ("统一字典", "44 条规则，生成/质检共用一套，不许各写一套"),
    ("三层检测", "规则层(句式) → 语义层(换皮/节奏) → 通读层(肌肉记忆)"),
    ("数据闭环", "35 篇真人语料实测标定，改规则先跑 27/27 回归"),
    ("保真红线", "关系准则收窄，人类通感离题该留；毛边清单主动造瑕疵"),
]
yy = 892
for t, s in items:
    tag(d, 110, yy, t, bg=TEAL_L, fg=BG, size=28)
    yy = draw_wrap(d, (300, yy + 4), s, font(32), INK, 620, 44) + 30
img.save(os.path.join(OUT, "03-融合过程.png"))

# ---------- 图4 三层检测 ----------
img, d = new_canvas()
header(d, "PART 3 · 怎么检测", "检测 AI 味，分三层", "单句没问题 ≠ 连起来没问题", y=80)
layers = [
    ("① 规则层 · 44 条", "句式词表 + 正则 + 引擎，hard 一票否决",
     ["翻案腔「不是X而是Y」", "硬停词 · 套话 · 提示性冒号", "禁用标点 · 黑话 · 编号当结构"]),
    ("② 语义层 · 抓换皮与节奏", "新长出的能力，全部真人语料实测误报率",
     ["段末金句堆砌 · 结尾金句收束(真人仅3%)", "段落节拍器(真人P25=0.47) · 排比密度", "元认知标注 · 防御性自审(真人0次)"]),
    ("③ 通读层 · agent 六问", "对仗洁癖 · 排比堆叠 · 情感曲线按计划",
     ["说理抒情分层 · 万能反问模板", "结尾过度升华", "→ 主动破坏：对称/均匀/完整各破一处"]),
]
yy = 300
for t, sub, lines in layers:
    card(d, 70, yy, W - 140, 300, BG2)
    tag(d, 94, yy + 26, t, bg=TEAL if "规则" in t or "通读" in t else CORAL, fg=BG, size=28)
    draw_wrap(d, (94, yy + 86), sub, font(32), MUT, 850, 44)
    yy2 = yy + 150
    for ln in lines:
        yy2 = draw_wrap(d, (94, yy2), "· " + ln, font(32), INK, 850, 44)
    yy += 340
card(d, 70, yy, W - 140, 120, BG2)
draw_wrap(d, (94, yy + 30), "数据底座：35 篇真人语料 13.5 万字 · 18 个引擎实测标定 · golden 55 条 · 27/27 回归", font(32), TEAL_L, 850, 46)
img.save(os.path.join(OUT, "04-三层检测.png"))

# ---------- 图5 实战验证 ----------
img, d = new_canvas()
header(d, "PART 4 · 实战验证", "跑过真稿，才有这些数", "不是纸面设计，是三轮对抗迭代逼出来的", y=80)
cases = [
    ("《十五块钱的LV》", "茉莉奶白主题 · 一次写对",
     "统计偏离度 11.7/100（<15 很贴合）· 实体密度分布内 · hedge 0"),
    ("《贫困生瑞幸》", "三轮对抗迭代：温和 → 犀利 → 定版",
     "8 条批评 6 清 2 边界 · 6 个语义层引擎全清 · 偏离度 13.8"),
]
yy = 320
for t, sub, s in cases:
    card(d, 70, yy, W - 140, 250, BG2)
    tag(d, 94, yy + 30, t, bg=TEAL_L, fg=BG, size=28)
    draw_wrap(d, (94, yy + 90), sub, font(34, True), INK, 850, 46)
    draw_wrap(d, (94, yy + 142), s, font(32), MUT, 850, 46)
    yy += 290
card(d, 70, yy, W - 140, 250, BG2)
draw_wrap(d, (110, yy + 36), "最狠的迭代：用户人工对抗测试", font(36, True), INK, 800, 50)
draw_wrap(d, (110, yy + 92), "初稿 → 人眼找痕迹 → 修改 → 再诊断 → 再改。", font(32), MUT, 800, 46)
draw_wrap(d, (110, yy + 138), "把 AI 的写作肌肉记忆（段落节拍/排比/对仗）逐条规则化。", font(32), MUT, 800, 46)
yy += 290
draw_wrap(d, (70, yy + 10), "最后一句：AI 写得不够好，不是质量不够高，是太干净了。毛边才是人味。", font(40, True), TEAL_L, W - 140, 54)
img.save(os.path.join(OUT, "05-实战验证.png"))

print("5 张图已生成 →", OUT)
for f in sorted(os.listdir(OUT)):
    print(" ", f)
