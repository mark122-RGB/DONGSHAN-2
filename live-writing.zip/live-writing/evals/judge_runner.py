#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""双评委持续回归 runner：人味判分历史曲线 + 出戏句标注（v1.9.0）。

用法：
  1. python evals/judge_runner.py --gen [--sample id]          生成评委提示词（给两个模型实例）
  2. 把提示词交给两个独立模型，收集 JSON 判分
  3. python evals/judge_runner.py --record v1.5.0 结果A.json 结果B.json   归档本轮 + 更新历史
  4. python evals/judge_runner.py --history                    打印人味判分历史曲线
  5. python evals/judge_runner.py --annotate 稿件.md [--judge 评委名]  出戏句标注模式（v1.9.0）
     —— 评委逐句指出「出戏」的句子 + 六类原因，输出喂回 false_negatives.txt

出戏七类（v2.5 加「判断平均化」——低在场语域的「在场感缺失」对位，对应 references/variability-profile.md 认知科学层）：
  1. 在场感缺失  2. 判断平均化  3. 细节可编造  4. 转折必达  5. 顺滑无卡壳
  6. 情感服务性  7. 论证绕圈

历史存 evals/judge_history.jsonl（每轮一行：version / date / 各样本 A/B 三维度均值 / Δ / more_human 一致性）。
"""
from __future__ import annotations

import argparse
import json
import statistics
import sys
from datetime import date
from pathlib import Path

HERE = Path(__file__).resolve().parent
SAMPLES = HERE / "judge_samples.json"
HISTORY = HERE / "judge_history.jsonl"
FALSE_NEG = HERE / "false_negatives.txt"

SCORES = ("naturalness", "fidelity", "publishable")

# 出戏原因七类（v2.5 加「判断平均化」——低在场语域的「在场感缺失」对位）
EXIT_CATEGORIES = (
    "在场感缺失", "判断平均化", "细节可编造", "转折必达", "顺滑无卡壳", "情感服务性", "论证绕圈",
)

ANNOTATE_TEMPLATE = """你是{judge}，一位苛刻的中文写作编辑。下面是一篇完整文稿。
你的任务：找出所有让你「出戏」的句子——读到那里突然觉得「这不是真人在写」的地方。
这是认知代价检测（眼动研究证实：AI 文本让读者回读更多、停顿更长），相信你的第一反应。

【文稿】
{text}

请输出 JSON（不要其他文字）：
{{
  "exits": [
    {{"quote": "出戏句子的原文（照抄，别改）", "category": "七类之一", "why": "一句话说明为什么出戏"}}
  ],
  "overall": {{
    "verdict": "human / borderline / ai",
    "dominant_category": "七类之一（或 无）",
    "note": "一句话总评"
  }}
}}

出戏七类定义（v2.5：人味三载体 A 在场 / B 离场 / C 纪实，任一落地即人味，三类皆无才出戏）：
- 在场感缺失：读不出有一个具体的人在思考/犹豫/冒险，也没有离场判断或纪实特异性的主观印记，像机器在陈述（高在场语域的主信号）
- 判断平均化：通篇「一方面/另一方面」「既…又…」平均用力，没有非对称判断——低在场语域（评论/分析）的「在场感缺失」对位
- 细节可编造：举例/细节是通用配件（一位受访者/数据显示），换任何稿都能用
- 转折必达：每个转折都精确服务论点，从不跑题，像写好的讲稿
- 顺滑无卡壳：论证一路顺滑，没有真人的推翻/犹豫/自我纠正
- 情感服务性：情感出现在「该出现」的位置，为论点服务，不是作者真的绷不住
- 论证绕圈：同一观点换几种说法反复说，没有推进

要求：只标真正让你出戏的句子，宁可少标不要滥标；每类最多标 2 句。
"""


def load_samples() -> dict:
    return json.loads(SAMPLES.read_text(encoding="utf-8"))


def gen_annotate_prompt(text: str, judge_name: str = "评委") -> str:
    return ANNOTATE_TEMPLATE.format(judge=judge_name, text=text)


def append_false_negatives(source: str, results: dict) -> None:
    """把出戏标注的「论证绕圈/细节可编造」等可规则化类别喂回 false_negatives。"""
    lines = []
    for judge_name, payload in results.items():
        for e in payload.get("exits", []):
            q = e.get("quote", "").strip()
            if not q:
                continue
            cat = e.get("category", "")
            why = e.get("why", "").strip()
            lines.append(f"[{cat}] {q}（{source} · {judge_name}：{why}）")
    if not lines:
        return
    existing = FALSE_NEG.read_text(encoding="utf-8") if FALSE_NEG.exists() else ""
    new_block = "\n".join(lines)
    if existing and not existing.endswith("\n"):
        existing += "\n"
    FALSE_NEG.write_text(existing + new_block + "\n", encoding="utf-8")
    print(f"已追加 {len(lines)} 条出戏句到 false_negatives.txt")


def gen_prompt(sample: dict, judge_name: str = "评委") -> str:
    return f"""你是{judge_name}，一位苛刻的中文写作编辑。下面是同一内容的两版写法（A/B），
你不知道哪版是真人写的、哪版是 AI 写的。请独立评判：

样本 {sample['id']} · {sample['topic']}

【A 版】
{sample['A']}

【B 版】
{sample['B']}

请输出 JSON（不要其他文字）：
{{
  "A": {{"naturalness": 1-5, "fidelity": 1-5, "publishable": 1-5}},
  "B": {{"naturalness": 1-5, "fidelity": 1-5, "publishable": 1-5}},
  "more_human": "A 或 B",
  "reason": "一句话理由"
}}

评分标准：
- naturalness 自然度：读起来像一个具体的人在说话/写作/判断/如实记述，有语气、有节奏、有细节或特异性判断
- fidelity 保真度：信息、事实、观点是否都保留（只论信息量，不论文笔）
- publishable 可直接发：作为一篇能直接发布的文字，够不够格
"""


def summarize(results: dict, samples: list) -> dict:
    """从 {评委名: {样本id: {A/B: {...}, more_human}}} 汇总本轮指标。

    只统计结果文件中实际出现的样本（旧结果可能是部分样本，如 v3 只含 20 个）。
    """
    judges = list(results.keys())
    present_ids = set()
    for j in judges:
        present_ids |= set(results[j].keys())
    used = [s for s in samples if s["id"] in present_ids]
    n = len(used)
    row = {"samples": n, "judges": len(judges)}
    # 每维度 A/B 均值、Δ
    for dim in SCORES:
        av, bv = [], []
        for s in used:
            sid = s["id"]
            for j in judges:
                r = results[j].get(sid, {})
                if "A" in r and "B" in r:
                    av.append(r["A"].get(dim, 0))
                    bv.append(r["B"].get(dim, 0))
        if av:
            row[f"{dim}_A"] = round(statistics.mean(av), 2)
            row[f"{dim}_B"] = round(statistics.mean(bv), 2)
            row[f"{dim}_delta"] = round(statistics.mean(bv) - statistics.mean(av), 2)
    # more_human 一致性
    votes = {}
    for s in used:
        sid = s["id"]
        choices = [results[j][sid]["more_human"] for j in judges if sid in results[j] and results[j][sid].get("more_human")]
        votes[sid] = choices
    agree = sum(1 for c in votes.values() if len(set(c)) == 1)
    row["more_human_一致"] = f"{agree}/{n}"
    row["B更像人票数"] = sum(1 for c in votes.values() if c and c.count("B") > len(c) / 2)
    return row


def main() -> int:
    ap = argparse.ArgumentParser(description="双评委持续回归 runner")
    ap.add_argument("--gen", action="store_true", help="生成评委提示词")
    ap.add_argument("--sample", metavar="id", help="只看某个样本（配合 --gen）")
    ap.add_argument("--annotate", metavar="稿件.md", help="出戏句标注模式：生成单稿评审提示词")
    ap.add_argument("--judge", default="评委", help="评委名（配合 --annotate）")
    ap.add_argument("--feed", metavar="结果.json", help="把出戏标注结果喂回 false_negatives（配合 --annotate）")
    ap.add_argument("--record", metavar="版本", help="归档本轮：--record v1.5.0 评委A.json 评委B.json")
    ap.add_argument("result_files", nargs="*", help="评委结果 JSON 文件（配合 --record）")
    ap.add_argument("--history", action="store_true", help="打印人味判分历史曲线")
    args = ap.parse_args()

    if args.annotate:
        text = Path(args.annotate).read_text(encoding="utf-8")
        if args.feed:
            results = json.loads(Path(args.feed).read_text(encoding="utf-8"))
            append_false_negatives(Path(args.annotate).name, results)
            return 0
        print(gen_annotate_prompt(text, args.judge))
        return 0

    data = load_samples()

    if args.record:
        paths = args.result_files
        if len(paths) < 1:
            print("用法：--record 版本 评委A.json [评委B.json ...]", file=sys.stderr)
            return 2
        results = {}
        for p in paths:
            content = json.loads(Path(p).read_text(encoding="utf-8"))
            # 结果文件形如 {评委名: {样本id: {...}}}，把每个评委展开
            for judge_name, judge_data in content.items():
                results[judge_name] = judge_data
        row = summarize(results, data["samples"])
        row["version"] = args.record
        row["date"] = date.today().isoformat()
        with HISTORY.open("a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
        print(f"已归档 {args.record}：", json.dumps({k: v for k, v in row.items() if k not in ("samples", "judges")}, ensure_ascii=False))
        return 0

    if args.history:
        if not HISTORY.exists():
            print("历史为空，先 --record 归档。")
            return 0
        print(f"{'版本':<10}{'日期':<12}{'样本':<5}{'自然度Δ':<8}{'保真Δ':<8}{'可发Δ':<8}{'评委一致':<10}{'B更像人'}")
        for line in HISTORY.read_text(encoding="utf-8").splitlines():
            r = json.loads(line)
            print(f"{r.get('version','?'):<10}{r.get('date','?'):<12}{r.get('samples','?'):<5}"
                  f"{r.get('naturalness_delta','?'):<8}{r.get('fidelity_delta','?'):<8}{r.get('publishable_delta','?'):<8}"
                  f"{r.get('more_human_一致','?'):<10}{r.get('B更像人票数','?')}")
        return 0

    # 默认 --gen
    for s in data["samples"]:
        if args.sample and s["id"] != args.sample:
            continue
        print(gen_prompt(s))
        print("=" * 60)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
