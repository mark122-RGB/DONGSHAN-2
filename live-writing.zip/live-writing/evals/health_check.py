#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""skill 健康度体检：引用完整性 + 字典一致性 + 版本一致性。

用法：python evals/health_check.py
"""
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent  # evals/
ROOT = HERE.parent                      # live-writing/
sys.path.insert(0, str(ROOT / "scripts"))
import check_prose as cp  # noqa: E402

ok = True

def check(name, cond, detail=""):
    global ok
    mark = "OK " if cond else "FAIL"
    if not cond:
        ok = False
    print(f"[{mark}] {name} {detail}")

# 1. SKILL.md 引用的文件都存在
t = (ROOT / "SKILL.md").read_text(encoding="utf-8")
refs = set(re.findall(r"`((?:references|rules|scripts|evals)/[a-z0-9_.\-]+\.(?:md|json|py|txt))`", t))
missing = [r for r in refs if not (ROOT / r).exists()]
check(f"SKILL.md 引用 {len(refs)} 个文件", not missing, f"缺失: {missing}")

# 2. 字典 vs 代码引擎
d = json.loads((ROOT / "rules" / "move-dictionary.json").read_text(encoding="utf-8"))
rules = d["rules"]
eng_rules = [r for r in rules if r["kind"] == "engine"]
check("字典引擎都有代码实现", not [r for r in eng_rules if r["engine"] not in cp.ENGINES])
unused = [e for e in cp.ENGINES if e not in {r["engine"] for r in eng_rules}]
check(f"字典 engine 规则数 {len(eng_rules)} ≥ 代码引擎数 {len(cp.ENGINES)}",
      len(eng_rules) >= len(cp.ENGINES), f"代码有但字典未注册: {unused}")
check("引擎参数校验", not cp.validate_engine_params(d))

# 3. 版本一致性
dict_ver = d.get("version", "?")
skill_head = (ROOT / "SKILL.md").read_text(encoding="utf-8").splitlines()
skill_ver = next((l for l in skill_head if "全链路" in l and re.search(r"\d+\.\d+\.\d+", l)), "?")
m = re.search(r"(\d+\.\d+\.\d+)", skill_ver)
check(f"字典 v{dict_ver} vs SKILL.md v{m.group(1) if m else '?'}", dict_ver == (m.group(1) if m else None))

# 4. 字典规则 ID 唯一性
ids = [r["id"] for r in rules]
dups = [i for i in set(ids) if ids.count(i) > 1]
check("规则 ID 唯一", not dups, f"重复: {dups}")

# 5. jieba 可用性（v1.10.0 语义引擎依赖）
check("jieba 可用（语义引擎）", cp.HAS_JIEBA, "无 jieba：LW-INFODEN-001 将静默跳过，其余引擎不受影响")

# 6. golden set 完整性
g = json.loads((HERE / "golden_set.json").read_text(encoding="utf-8"))
samples = g["samples"]
bad = [s["id"] for s in samples if "expect" not in s or "text" not in s]
check(f"golden set {len(samples)} 条", not bad, f"缺字段: {bad}")
warn_spec = [s["id"] for s in samples if "expect_warn" in s]
check(f"warn 回归样本 {len(warn_spec)} 条", len(warn_spec) >= 5)

print("\n" + ("全部通过。" if ok else "有 FAIL，见上。"))
sys.exit(0 if ok else 1)
