#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""活人写作 · 字典回归测试。

跑 golden_set.json，统计硬规则的召回与误伤：
- 召回：expect=fail 的样本里，有多少真的触发了 hard 失败。
- 误伤：expect=pass 的样本里，有多少误触发了 hard 失败。
- warn 回归（可选）：样本带 expect_warn 字段时，校验对应 warn 规则是否触发/未触发。

改 move-dictionary.json 之后先跑这个，别让一条新禁令误伤一百个正常句子。
用法：python run_eval.py
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "scripts"))
import check_prose as cp  # noqa: E402


def evaluate(sample, dictionary, register="all"):
    text = sample["text"]
    prose = cp.mask_non_prose(text)
    failures, warnings = [], []
    for rule in dictionary.get("rules", []):
        if rule.get("kind") == "agent":
            continue
        f, w = cp.run_rule(rule, prose, text, register)
        failures.extend(f)
        warnings.extend(w)
    return failures, warnings


def rule_ids(messages):
    """从消息里提取命中规则 ID（去重保序）。

    注意：ID 形如 LW-类别-编号，但类别本身可含连字符（如 LW-FAKE-DEPTH-001、
    LW-DIGRESS-002），正则必须允许 `LW-[A-Z]+(-[A-Z]+)*-\d+`。
    """
    ids, seen = [], set()
    for msg in messages:
        m = re.match(r"\[(LW-[A-Z]+(?:-[A-Z]+)*-\d+)", msg)
        if m and m.group(1) not in seen:
            seen.add(m.group(1))
            ids.append(m.group(1))
    return ids


def main() -> int:
    dictionary = json.loads((HERE.parent / "rules" / "move-dictionary.json").read_text(encoding="utf-8"))
    golden = json.loads((HERE / "golden_set.json").read_text(encoding="utf-8"))

    pos_total = pos_hit = 0   # 应检出（hard 召回）
    neg_total = neg_hit = 0   # 应通过（hard 误伤）
    warn_checks = warn_ok = 0  # warn 回归检查
    lines = []
    for s in golden.get("samples", []):
        register = s.get("register", "all")
        failures, warnings = evaluate(s, dictionary, register)
        failed = len(failures) > 0
        if s["expect"] == "fail":
            pos_total += 1
            pos_hit += 1 if failed else 0
            ok = failed
        else:
            neg_total += 1
            neg_hit += 1 if failed else 0
            ok = not failed
        mark = "OK " if ok else "MISS"
        rid = ",".join(rule_ids(failures)) or "-"
        warn_tag = ""
        # warn 回归：样本声明 expect_warn 时校验（该触发没触发 = 缺报才失败）
        # 2026-08-10 修正：warn 是提醒，多报无害——只有「期望的没报」算 MISS；
        # 「期望之外多报」不算（除非样本期望完全不报任何 warn）。
        if "expect_warn" in s:
            warn_checks += 1
            warn_ids = set(rule_ids(warnings))
            exp = set(s["expect_warn"])
            miss_warn = exp - warn_ids
            extra_warn = warn_ids - exp if not exp else set()  # 仅当完全不期望时才管多报
            if not miss_warn and not extra_warn:
                warn_ok += 1
                warn_tag = " WARN-OK"
            else:
                ok = False
                mark = "MISS"
                warn_tag = f" WARN-MISS(缺:{','.join(sorted(miss_warn)) or '-'} 多:{','.join(sorted(extra_warn)) or '-'})"
        lines.append(f"[{mark}] {s['id']:<20} expect={s['expect']:<4} hard={len(failures):>2} warn={len(warnings):>2} [{rid}]{warn_tag}")

    recall = pos_hit / pos_total if pos_total else 0.0
    fp = neg_hit / neg_total if neg_total else 0.0
    print("逐样本：")
    for l in lines:
        print("  " + l)
    print(f"\n召回（该抓的抓到）: {pos_hit}/{pos_total} = {recall:.0%}")
    print(f"误伤（不该抓的被抓）: {neg_hit}/{neg_total} = {fp:.0%}")
    if warn_checks:
        print(f"warn 回归（带 expect_warn 的样本）: {warn_ok}/{warn_checks}")
    if pos_hit < pos_total or neg_hit > 0 or warn_ok < warn_checks:
        print("\n有 MISS，检查字典是否漏了变体或误伤了正常句。")
        return 1
    print("\n全部通过。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
