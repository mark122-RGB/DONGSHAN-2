#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""抓取互联网真人中文长文作 live-writing 标定语料。

策略：urllib 直抓 HTML -> 去 script/style -> 优先 <p> 段落文本 -> 不足时
回退到最长中文 <div> 块。存到同目录 corpus/<name>.md，打印每篇汉字数。
仅用于本地阈值标定，不对外发布。
"""
import urllib.request
import re
import pathlib

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"

SOURCES = [
    ("csdn_code_swamp", "https://blog.csdn.net/ezreal_pan/article/details/158693675"),
    ("net163_phd", "https://dy.163.com/article/FAQQCLOF0525CGSH.html"),
    ("net163_4000to_bankrupt", "https://www.163.com/dy/article/FFCQUOMT0519DP0A.html"),
    ("sohu_zhihu_poor", "https://www.sohu.com/a/312010474_100162106"),
    ("sohu_stepmother", "https://www.sohu.com/a/739687527_652852"),
    ("qq_lencx", "https://new.qq.com/rain/a/20260711A08IMY00?refer=cp_1009"),
    ("cnblogs_ten_years", "https://www.cnblogs.com/0xc00lt3a/p/19430733"),
    ("cctv_low_desire", "https://news.cctv.com/2021/05/29/ARTIB7VjpVqRjUzG51itQesQ210529.shtml"),
    ("sohu_beipiao", "https://www.sohu.com/a/920861897_121124791"),
    ("qq_douban_20y", "https://new.qq.com/rain/a/20260525A09SWD00?refer=cp_1009"),
    # --- round 2 additions (更多真人语料，扩到 ~19 篇) ---
    ("sohu_ordinary_20y", "https://www.sohu.com/a/1036131790_122321080"),
    ("sohu_brick_2m", "https://www.sohu.com/a/887425792_121284943"),
    ("sohu_babysitter", "https://news.sohu.com/20160118/n434886614.shtml"),
    ("qq_cleaner_changhua", "https://news.qq.com/rain/a/20241022A07VD600"),
    ("cnblogs_programmer_10y", "https://www.cnblogs.com/Chary/articles/16154298.html"),
    ("csdn_programmer_growth", "https://blog.csdn.net/zhy_Learn/article/details/133078315"),
    ("qq_aunt_56", "https://new.qq.com/rain/a/20260121A033TY00?refer=cp_1009"),
    ("qq_peach_forest", "https://new.qq.com/rain/a/20260716A04NEE00?refer=cp_1009"),
    ("qq_single_mom", "https://view.inews.qq.com/a/20241203A03E5R00"),
    # --- round 3 additions (扩到 30+ 篇；sohu 个人纪实 / cnblogs·csdn 个人博客 / 网易人间非虚构) ---
    ("sohu_year_end", "https://www.sohu.com/a/971429984_121106854"),
    ("sohu_sixty_body", "https://www.sohu.com/a/968780272_100132932"),
    ("sohu_beekeeper_2025", "https://www.sohu.com/a/966009604_100132932"),
    ("cnblogs_program_10y_reflect", "https://www.cnblogs.com/fumei/p/18960283"),
    ("csdn_ten_years_oldblog", "https://blog.csdn.net/jakenli/article/details/6695553"),
    ("duidaima_tencent_10y", "https://www.duidaima.com/Group/Topic/Life/16764"),
    ("had0w_java_30y", "https://www.5had0w.com/posts/1eda1c08.html"),
    ("net163_35_unemployed", "https://www.163.com/dy/article/KHUVLB7R052188CT.html"),
    ("net163_tube_baby", "https://www.163.com/renjian/article/KU17E5K4000181MT.html"),
    ("net163_escape_father", "https://www.163.com/dy/article/KAADGTIK052188CT.html"),
    ("net163_free_noodle", "https://3g.163.com/news/article/JLA5QNKU0522TGDK.html"),
]


def fetch(url: str) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    return urllib.request.urlopen(req, timeout=30).read().decode("utf-8", "ignore")


def clean(html: str) -> str:
    for tag in ("script", "style", "noscript", "svg", "head"):
        html = re.sub(rf"<{tag}[\s\S]*?</{tag}>", " ", html, flags=re.I)
    return html


def strip_tags(s: str) -> str:
    s = re.sub(r"<[^>]+>", "", s)
    s = re.sub(r"&nbsp;", " ", s)
    s = re.sub(r"&amp;", "&", s)
    s = re.sub(r"&[a-z]+;", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def han(s: str) -> int:
    return len(re.findall(r"[一-鿿]", s))


def extract(html: str) -> str:
    html = clean(html)
    ps = [strip_tags(m) for m in re.findall(r"<p[^>]*>([\s\S]*?)</p>", html, re.I)]
    ps = [p for p in ps if han(p) >= 8]
    text = "\n\n".join(ps)
    if han(text) < 300:
        blocks = [strip_tags(m) for m in re.findall(r"<div[^>]*>([\s\S]*?)</div>", html, re.I)]
        blocks = [b for b in blocks if han(b) > 200]
        if blocks:
            blocks.sort(key=han, reverse=True)
            text = blocks[0]
    return text


def main() -> None:
    out = pathlib.Path(__file__).resolve().parent / "corpus"
    out.mkdir(exist_ok=True)
    for name, url in SOURCES:
        try:
            html = fetch(url)
            text = extract(html)
            n = han(text)
            (out / f"{name}.md").write_text(text, encoding="utf-8")
            print(f"{name}: {n} 汉字, 存 corpus/{name}.md")
        except Exception as e:
            print(f"{name}: FAIL {e}")


if __name__ == "__main__":
    main()
