#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""对 corpus/*.md 批量计算 entity_density 与 hedge_density 的每千字值，
输出每篇数值 + 汇总分位数，用于把 LW-MATERIAL-002 / LW-HEDGE-001 的经验初值
替换为真人语料的实测分位数。

计算逻辑与 scripts/check_prose.py 的 eng_entity_density / eng_hedge_density 保持
一致（正则、mask、min_han 均相同），确保标定出的阈值与实际脚本行为对齐。
"""
import re
import statistics
from pathlib import Path

HAN_RE = re.compile(r"[一-鿿]")


def han_count(text: str) -> int:
    return len(HAN_RE.findall(text))


def mask_non_prose(text: str) -> str:
    def mask(m):
        return "".join("\n" if c == "\n" else " " for c in m.group())

    patterns = (
        re.compile(r"\A---\s*\n.*?\n---\s*(?:\n|\Z)", re.DOTALL),
        re.compile(r"```.*?```", re.DOTALL),
        re.compile(r"`[^`\n]*`"),
        re.compile(r"\]\([^\n)]*\)"),
        re.compile(r"https?://[^\s)>]+"),
        re.compile(r"<[^>\n]+>"),
    )
    out = text
    for p in patterns:
        out = p.sub(mask, out)
    return out


def non_overlapping_terms(text, terms):
    matches, occupied = [], []
    for term in sorted(terms, key=len, reverse=True):
        for m in re.finditer(re.escape(term), text):
            s, e = m.span()
            if any(s < oe and e > os_ for os_, oe in occupied):
                continue
            matches.append((s, term))
            occupied.append((s, e))
    return sorted(matches)


HEDGE_TERMS = ["可以说", "某种程度上", "在一定程度上", "某种意义上", "总体而言",
               "相对而言", "从某种程度上", "大体上", "算是"]
ENTITY_RE = {
    "nums": re.compile(r"[0-9]+(?:[.．][0-9]+)?"),
    "units": re.compile(r"(?:年|月|日|岁|万|亿|元|%)"),
    "orgs": re.compile(r"(?:大学|医院|公司|集团|研究院|研究所|中心|局|委|省|市|县|镇|银行|法院|学校|工厂|部队)"),
    "en": re.compile(r"[A-Za-z]{2,}"),
}


def entity_per_k(prose):
    total = han_count(prose)
    if total < 400:
        return None
    nums = len(ENTITY_RE["nums"].findall(prose))
    units = len(ENTITY_RE["units"].findall(prose))
    orgs = len(ENTITY_RE["orgs"].findall(prose))
    en = len(ENTITY_RE["en"].findall(prose))
    signals = nums + units + orgs + en
    return signals * 1000 / total, total, (nums, units, orgs, en)


def hedge_per_k(prose):
    total = han_count(prose)
    if total < 400:
        return None
    hits = non_overlapping_terms(prose, HEDGE_TERMS)
    return len(hits) * 1000 / total, total, len(hits)


def pct(data, p):
    if not data:
        return None
    s = sorted(data)
    k = (len(s) - 1) * p
    f = int(k)
    c = min(f + 1, len(s) - 1)
    return s[f] + (s[c] - s[f]) * (k - f)


def main() -> None:
    corpus = Path(__file__).resolve().parent / "corpus"
    rows = []
    for f in sorted(corpus.glob("*.md")):
        text = f.read_text(encoding="utf-8")
        prose = mask_non_prose(text)
        e = entity_per_k(prose)
        h = hedge_per_k(prose)
        er = e[0] if e else None
        hr = h[0] if h else None
        rows.append((f.stem, e[1] if e else 0, er, h[2] if h else 0, hr))
        ent_s = "—" if er is None else f"{er:5.1f}"
        hed_s = "—" if hr is None else f"{hr:5.2f}"
        print(f"{f.stem:26s} han={ (e[1] if e else 0):6d}  entity/1k={ent_s}  hedge_hits={h[2] if h else 0:3d}  hedge/1k={hed_s}")

    ents = [r[2] for r in rows if r[2] is not None]
    hedg = [r[4] for r in rows if r[4] is not None]

    print("\n=== ENTITY density (signals / 1000 han) — 当前阈值 8.0 ===")
    print(f"n={len(ents)} min={min(ents):.1f} max={max(ents):.1f} "
          f"mean={statistics.mean(ents):.1f} median={statistics.median(ents):.1f}")
    for p in (0.1, 0.25, 0.5, 0.75, 0.9):
        print(f"  P{int(p*100):>2} = {pct(ents, p):.1f}")

    print("\n=== HEDGE density (hits / 1000 han) — 当前阈值 3.0 ===")
    print(f"n={len(hedg)} min={min(hedg):.2f} max={max(hedg):.2f} "
          f"mean={statistics.mean(hedg):.2f} median={statistics.median(hedg):.2f}")
    for p in (0.1, 0.25, 0.5, 0.75, 0.9):
        print(f"  P{int(p*100):>2} = {pct(hedg, p):.2f}")


if __name__ == "__main__":
    main()
