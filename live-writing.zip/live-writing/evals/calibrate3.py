#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""第 3 轮标定：30 篇语料上实测剩余 8 个 engine 的真人触发率。

经验初值 engine（anaphora_runs / lyric_density / metaphor_cluster /
bracket_highlights / soft_marker_density / repeated_opener / numbered_list /
tail_density）之前未标定。目标：真人触发率降到 warn 容忍线（~10-15%）内，
超标则做参数 sweep，找到新阈值后由 patch3.py 落地。
"""
import json
import re
import sys
from pathlib import Path

BASE = Path(r"C:/Users/31905/.workbuddy/skills/live-writing")
sys.path.insert(0, str(BASE / "scripts"))
import check_prose as cp  # noqa: E402

DICT = json.load(open(BASE / "rules" / "move-dictionary.json", encoding="utf-8"))
RULES = {r["id"]: r for r in DICT["rules"]}

TARGETS = [
    "LW-ANAPHORA-001", "LW-LYRIC-001", "LW-METAPHOR-001", "LW-STYLE-001",
    "LW-SOFTMARK-001", "LW-STYLE-002", "LW-NUMERATE-001", "LW-TAIL-001",
]

docs = []
for f in sorted((BASE / "evals/corpus").glob("*.md")):
    t = f.read_text(encoding="utf-8")
    prose = cp.mask_non_prose(t)
    if cp.han_count(prose) >= 400:
        docs.append((f.stem, prose, t))
print(f"语料 {len(docs)} 篇\n")


def fire(rule, text):
    return len(cp.run_rule(rule, text, text, "all")[0]) + len(cp.run_rule(rule, text, text, "all")[1])


def rate(rid, params_override=None):
    rule = dict(RULES[rid])
    if params_override:
        rule["params"] = dict(rule.get("params", {}), **params_override)
    n = sum(1 for _, p, t in docs if cp.ENGINES[rule["engine"]](p, rule, rule["params"]))
    return n / len(docs)


print("== 8 个 engine 当前阈值在真人语料的触发率 ==")
for rid in TARGETS:
    r = RULES[rid]
    n = sum(1 for _, p, t in docs if cp.ENGINES[r["engine"]](p, r, r["params"]))
    flag = "  <== 超标(>15%)" if n / len(docs) > 0.15 else ""
    print(f"  {rid} {r['name']:<14} params={json.dumps(r['params'], ensure_ascii=False)} → {n}/{len(docs)} = {n/len(docs):.0%}{flag}")

print("\n== 超标的做参数 sweep（候选值→触发率）==")
sweeps = {
    "LW-STYLE-001": [
        ("min=3,divisor=700", {"min": 3, "divisor": 700}),
        ("min=4,divisor=700", {"min": 4, "divisor": 700}),
        ("min=4,divisor=500", {"min": 4, "divisor": 500}),
        ("min=5,divisor=500", {"min": 5, "divisor": 500}),
    ],
    "LW-SOFTMARK-001": [
        ("min=2,divisor=900", {"min": 2, "divisor": 900}),
        ("min=3,divisor=900", {"min": 3, "divisor": 900}),
        ("min=3,divisor=700", {"min": 3, "divisor": 700}),
        ("min=4,divisor=600", {"min": 4, "divisor": 600}),
    ],
    "LW-ANAPHORA-001": [
        ("min=3", {"minimum": 3}),
        ("min=4", {"minimum": 4}),
    ],
    "LW-METAPHOR-001": [
        ("dist=800,fields=3", {"distance": 800, "min_fields": 3}),
        ("dist=600,fields=3", {"distance": 600, "min_fields": 3}),
        ("dist=500,fields=4", {"distance": 500, "min_fields": 4}),
    ],
    "LW-LYRIC-001": [
        ("min=2", {"min_hits": 2}),
        ("min=3", {"min_hits": 3}),
    ],
    "LW-STYLE-002": [
        ("min=4", {"min_count": 4}),
        ("min=5", {"min_count": 5}),
    ],
    "LW-NUMERATE-001": [
        ("min=3", {"min": 3}),
        ("min=4", {"min": 4}),
    ],
    "LW-TAIL-001": [
        ("per_k=2.0", {"per_thousand": 2.0}),
        ("per_k=2.5", {"per_thousand": 2.5}),
        ("per_k=3.0", {"per_thousand": 3.0}),
    ],
}
for rid, opts in sweeps.items():
    print(f"\n  {rid} {RULES[rid]['name']}:")
    for label, ov in opts:
        print(f"    {label:<20} → {rate(rid, ov):.0%}")
