#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""verify_discourse.py — 话语特征可行性验证（v2.0 决策 1：先验证后落地）。

跑 evals/corpus/（48 真人）+ evals/corpus_ai/（15 AI），对 8 个话语特征的
每个数值维度输出两组分布 + 区分度三档结论：

  STRONG : 阈值窗口 0 误伤 + ≥13/15 抓力 → 升引擎
  WEAK   : 误伤 ≤4/48 + 抓力 ≥10/15 → 调阈值后升引擎候选
  NONE   : 分布重叠 → 画像项 + agent 规则（决策 2 兜底）

用法：python evals/verify_discourse.py
"""
from __future__ import annotations

import statistics
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / "scripts"))
import discourse_profile as dp  # noqa: E402


def pct(vals, p):
    vals = sorted(v for v in vals if v is not None)
    if not vals:
        return float("nan")
    return vals[min(len(vals) - 1, int(len(vals) * p))]


def collect(files):
    """对每篇提取所有特征，返回 {feature: {key: [values]}}。"""
    out = {}
    for f in files:
        text = f.read_text(encoding="utf-8")
        prose = dp.cp.mask_non_prose(text)
        han = dp.cp.han_count(prose)
        sents = dp._sentences(text)
        if han < 400:  # 与引擎 min_han 门槛一致
            continue
        for name, fn in dp.FEATURE_FUNCS.items():
            try:
                res = fn(sents, prose, han)
            except Exception:
                continue
            if not isinstance(res, dict):
                continue
            for key, val in res.items():
                if isinstance(val, (int, float)) and not isinstance(val, bool):
                    out.setdefault((name, key), []).append(val)
    return out


def verdict(h_vals, a_vals, ai_direction):
    """判定区分度：ai_direction='high' → AI 该维度偏高（h 低 a 高）。"""
    h = [v for v in h_vals if v is not None]
    a = [v for v in a_vals if v is not None]
    if len(h) < 30 or len(a) < 10:
        return "NONE", "样本不足"
    h_p90, h_p25 = pct(h, 0.90), pct(h, 0.25)
    a_p10 = pct(a, 0.10)
    a_p90 = pct(a, 0.90)
    # 判断方向
    if ai_direction == "high":
        # AI 应该高于真人：真人 P90 < AI P10 → STRONG
        if h_p90 < a_p10:
            return "STRONG", f"真人 P90={h_p90:.3f} < AI P10={a_p10:.3f}，绝对空白"
        if h_p90 < a_p90 and h_p90 < a_p10 + (a_p90 - a_p10) * 0.5:
            return "WEAK", f"真人 P90={h_p90:.3f} vs AI 区间 [{a_p10:.3f},{a_p90:.3f}]，部分重叠"
        return "NONE", f"重叠：真人 P90={h_p90:.3f} vs AI P10={a_p10:.3f}"
    else:
        # AI 应该低于真人：真人 P25 > AI P90 → STRONG
        if h_p25 > a_p90:
            return "STRONG", f"真人 P25={h_p25:.3f} > AI P90={a_p90:.3f}，绝对空白"
        if h_p25 > a_p10:
            return "WEAK", f"真人 P25={h_p25:.3f} vs AI 区间 [{a_p10:.3f},{a_p90:.3f}]，部分重叠"
        return "NONE", f"重叠：真人 P25={h_p25:.3f} vs AI P90={a_p90:.3f}"


# 各维度预期 AI 方向（high=AI 偏高 / low=AI 偏低）
AI_DIRECTION = {
    ("thematic_progression", "constant"): "low",    # AI 主语贯穿少
    ("thematic_progression", "new"): "high",        # AI 每句新话题
    ("zero_anaphora_rate", "value"): "low",         # AI 每句重写主语 → 零形低 ★
    ("zero_anaphora_rate", "conj_opener_rate"): "high",  # v2.1 新增：AI 连词开头多 ★
    ("topic_chain_length", "mean"): "low",          # AI 话题链短
    ("centering_transitions", "ROUGH_SHIFT"): "high",  # AI 粗糙转移多
    ("centering_transitions", "CONTINUE"): "low",
    ("stance_profile", "hedge"): "high",            # AI 模糊语多
    ("stance_profile", "booster"): "high",          # AI 强化语多
    ("stance_profile", "self_mention"): "low",      # AI 少自我（除非伪装）
    ("stance_profile", "reader_pronoun"): "high",   # AI 拉近距离
    ("stance_profile", "attitude"): "high",
    ("register_dimensions", "narrativity"): "low",  # AI 少叙事
    ("register_dimensions", "involvedness"): "low", # AI 少投入
    ("register_dimensions", "abstractness"): "high",# AI 抽象高
    ("register_dimensions", "persuasiveness"): "high",
    ("register_dimensions", "informativity"): "low",# AI 信息密度低
    ("referential_form_sequence", "value"): "high", # AI 全名重复高
    ("referential_form_sequence", "degrade_rate"): "low",  # v2.1 新增：AI 指称不降级 ★
    ("subject_repetition_rate", "value"): "high",   # AI 主语明写率高 ★
    ("subject_repetition_rate", "noun_repeat_rate"): "high",  # v2.1 新增：AI 名词主语反复明写 ★
}


def main() -> int:
    human_files = sorted((ROOT / "evals" / "corpus").glob("*.md"))
    ai_files = sorted((ROOT / "evals" / "corpus_ai").glob("*.md"))
    human = collect(human_files)
    ai = collect(ai_files)

    print("=" * 78)
    print("话语特征可行性验证（48 真人 vs 15 AI，min_han=400）")
    print("=" * 78)
    rows = []
    for (fname, key), direction in AI_DIRECTION.items():
        h_vals = human.get((fname, key), [])
        a_vals = ai.get((fname, key), [])
        if not h_vals or not a_vals:
            rows.append((fname, key, "NONE", "无数据"))
            continue
        v, reason = verdict(h_vals, a_vals, direction)
        rows.append((fname, key, v, reason))
        print(f"[{v:6s}] {fname}.{key:<28s} 真人 P25/P50/P90={pct(h_vals,.25):.3f}/{pct(h_vals,.50):.3f}/{pct(h_vals,.90):.3f}  AI P10/P50/P90={pct(a_vals,.10):.3f}/{pct(a_vals,.50):.3f}/{pct(a_vals,.90):.3f}  {reason}")

    print()
    print("=" * 78)
    strong = [r for r in rows if r[2] == "STRONG"]
    weak = [r for r in rows if r[2] == "WEAK"]
    none = [r for r in rows if r[2] == "NONE"]
    print(f"STRONG（升引擎候选）: {len(strong)} 个维度")
    for r in strong:
        print(f"  ✓ {r[0]}.{r[1]}")
    print(f"WEAK（调阈值后候选）: {len(weak)} 个维度")
    for r in weak:
        print(f"  ~ {r[0]}.{r[1]}")
    print(f"NONE（画像项+agent）: {len(none)} 个维度")
    for r in none:
        print(f"  - {r[0]}.{r[1]} {r[3][:30]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
